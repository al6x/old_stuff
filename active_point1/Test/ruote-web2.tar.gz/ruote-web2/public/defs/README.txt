
[local] process definitions go here

