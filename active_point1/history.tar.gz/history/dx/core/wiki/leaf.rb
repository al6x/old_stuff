require 'wgui'

module Dx
	class Leaf
end