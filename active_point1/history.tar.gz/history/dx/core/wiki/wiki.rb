require 'wgui'

include WGUI
module Dx	
	class 
	class Leaf
		property :name, String
		belongs_to ContainerModel
		
		Og.manage self
    end
	
	class Container
		property :name, String
		has_many :childs, LeafModel
		
		Og.manage self
    end
	
	class ContainerView < WComponent
		attr_accessors :model
    end
	
	class LeafView < WComponent
		attr_accessor :model
    end
	
	class Wiki < WComponent
		include WPortlet
		attr_accessor :label
		
		def initialize
			build do
				c.label = Label :text => 'Hello'
			end
        end
		
		def render ss
			label.text = state.to_s
        end
		
		def state_conversion_strategy; TreePathStateConversionStrategy end
    end
end

if __FILE__.to_s == $0
  Runner.start Dx::Wiki
  Runner.join
end