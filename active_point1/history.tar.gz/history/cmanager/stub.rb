# Stub for components test

module ManagedComponent		
	module ClassMethods; end		
	def self.included(klass) klass.extend(ClassMethods) end				
	
	module ClassMethods					
		def register id, scope; end
			
		def attr_accessor *attrs
			if attrs.size == 1 && attrs[0] && attrs[0].kind_of?(Hash)
				super(*attrs[0].collect{|name, reference| name})
			else	
				super(*attrs)
			end									
		end				
	end		
end