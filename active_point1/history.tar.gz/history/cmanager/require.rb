require 'cmanager/components_manager'
require 'cmanager/managed_component'