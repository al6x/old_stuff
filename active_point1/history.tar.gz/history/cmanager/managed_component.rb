require 'cmanager/components_manager'
# === Predefined components
# :ObjectManager - ObjectManager 
# :SessionManager - ObjectManager for :session scope
# 
# === Scopes
# :service - singleton
# :instance - always new
# :custom - custom managed scopes
# 
# === Design
# - implement different scopes as composition of different ObjectManager's
# - add :timeout attribute for component with values :low, :high
# - 
#

module ManagedComponent		
	# Reference ot IOC container
	attr_accessor :components_manager
	
	module ClassMethods; end		
	def self.included(klass) klass.extend(ClassMethods) end				
	
	module ClassMethods			
		# Register class as managed component with _id_ in _scope_
		def register id, scope			
			ComponentsManager::MetaData.register_component id, scope, self
		end
			
		# Inject component in attribute (:attr_name => component_id [, ...])
		def attr_accessor *attrs
			if attrs.size == 1 && attrs[0] && attrs[0].kind_of?(Hash)
				attrs[0].each do |name, reference|
					# Getter
					send :define_method, name do
						components_manager[reference]
                    end
					
					# Setter
					send :define_method, "#{name}=" do
						raise "Attribute '#{name}' is managed, you cannot set it manually."
                    end
				end
			else	
				super(*attrs)
			end									
		end
	end		
end