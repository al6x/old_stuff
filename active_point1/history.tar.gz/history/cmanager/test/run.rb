require 'cmanager/test/general_test'
require 'cmanager/test/reload_test'
#require 'cmanager/test/stub_test' # You can't run it with all others tests