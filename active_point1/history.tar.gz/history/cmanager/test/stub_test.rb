require 'utils/test_case'
require 'cmanager/stub'

class TestStub < TestCase
	class A
		include ManagedComponent
		
		register :A, :some_scope
		
		attr_accessor :a
		attr_accessor :b, :c
		attr_accessor :d=>:D
		attr_accessor :e=>:E, :f=>:F
    end
	
	def test_stub
		a = A.new
		a.a, a.b, a.c, a.d, a.e, a.f = 1, 2, 3, 4, 5, 6
		
		assert_equal [a.a, a.b, a.c, a.d, a.e, a.f],  [1, 2, 3, 4, 5, 6]
    end
end