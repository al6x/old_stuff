require 'utils/test_case'
require 'cmanager/managed_component'

class TestReload < TestCase
	# An addon for 'object_manager_test.rb' TestCase
	class A
		include ManagedComponent
		register :A, :service	
		attr_accessor :b=>:B
	end

	class B
		include ManagedComponent
		register :B, :service
	end
	
	def setup
		@cm = ComponentsManager.new
    end
	
	def teardown
		@cm.deinitialize
    end
	
	# Simple reloading, without references update
	def test_simple_reloading
		a = @cm[:A]
		script = %{
class TestReload::A
	include ManagedComponent
	register :A, :service	
	attr_accessor :b=>:B
end		
		}
		eval(script)
		
		a2 = @cm[:A]		
		assert_not_equal a, a2
    end	
	
	def test_reference_reloading
		a = @cm[:A]
		b1 = a.b
		script = %{
class TestReload::B
	include ManagedComponent
	register :B, :service
end
		}
		eval(script)
		
		b2 = a.b
		assert_not_equal b1, b2
    end		

	class A
		def method1 arg1; end
    end
	
	def test_method_signature_changed
		@cm[:A].method1 1
		script = %{
class TestReload::A
	def method1 arg1, arg2; end
end
		}
		eval(script)
		@cm[:A].method1 1, 2
		assert_raise {@cm[:A].method1 1}
    end
end