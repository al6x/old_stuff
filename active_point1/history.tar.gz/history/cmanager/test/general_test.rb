require 'utils/test_case'
require 'cmanager/components_manager'
require 'cmanager/managed_component'

class ComponentsManagerTest < TestCase
	
	def setup
		@cm = ComponentsManager.new
    end
	
	def teardown
		@cm.deinitialize
    end
	
	class S
		include ManagedComponent
		register :S, :service
		
		attr_accessor :name
    end
	
	class I
		include ManagedComponent
		register :I, :instance		
		
		attr_accessor :s=>:S
    end
	
	class Ses
		include ManagedComponent
		register :Ses, :session
		
		attr_accessor :s=>:S, :i=>:I
    end
	
	class SelfReference
		include ManagedComponent
		register :SelfRef, :service
		attr_accessor  :self_ref=>:SelfRef				
    end
	
	def test_self_reference		
		sr = @cm[:SelfRef]
		assert_equal sr, sr.self_ref
    end
	
	class CycleA
		include ManagedComponent
		register :CycleA, :service
		attr_accessor :b=>:CycleB
    end
	
	class CycleB
		include ManagedComponent
		register :CycleB, :service
		attr_accessor :a=>:CycleA
    end		
	
	def test_cycle_references		
		assert_equal @cm[:CycleA], @cm[:CycleB].a
		assert_equal @cm[:CycleB], @cm[:CycleA].b
    end
	
	def test_attr_accessor
		s = S.new
		s.name = 'Name'
		assert_equal 'Name', s.name
    end
   	
	def test_service		
		s1 = @cm[:S]
		s1.name = "value1"
		s12 = @cm[:S]
		assert_equal s1, s12
		assert_equal "value1", s12.name
		
		assert_equal nil, @cm[:S2]
		
		cm2 = ComponentsManager.new
		assert_not_equal s1, cm2[:S]
    end
	
	def test_manual_component_registration				
		@cm.register_object :mS, :service, 'Service'
		assert_raise {@cm.register_object :I, :instance, 'Instance'} # You cannot register Component with :instance scope		
		assert_equal 'Service', @cm[:mS]		
				
		# Test for registering the same component
		@cm.register_object :mS1, :service, 'S1'		
		@cm.register_object :mS1, :service, 'S1v2'
		assert_equal 'S1v2', @cm[:mS1]
		
		cm2 = ComponentsManager.new
		cm2.register_object :mS1, :service, 'S2'				
		assert_not_equal @cm[:mS1], cm2[:mS1]
		assert_equal 'S2', cm2[:mS1]
    end
	
	def test_scope_open_close		
		# Open
		@cm.open_scope :session, 1
		s1 = @cm[:Ses]
		assert_not_nil s1
		# Close
		@cm.close_scope :session
		assert_raise{@cm[:Ses]}
		# Reopen
		@cm.open_scope :session, 1
		assert_equal s1, @cm[:Ses]
		# Delete
		@cm.delete_scope :session
		assert_raise {@cm[:Ses]}
		@cm.open_scope :session, 1
		assert_not_nil @cm[:Ses]
		assert_not_equal s1, @cm[:Ses]		
    end
	
	def test_component_tree		
		@cm.open_scope :session, 1
		s1 = @cm[:Ses]
		
		assert_not_nil s1
		assert_not_nil s1.i
		assert_not_nil s1.i.s
		assert_not_nil s1.s
    end
	
	def test_register_with_scope_selection		
		assert_raise{@cm.register_object :mCS, :instance, ""} # Can't register objects in :instance scope
		assert_raise {@cm.register_object :mCS, :custom_scope, ""} # Scope :custom_scope is not selected
		@cm.open_scope(:custom_scope, "key")
		@cm.register_object :mCS, :custom_scope, "CS"
		assert_equal "CS", @cm[:mCS]
		@cm.open_scope(:custom_scope, "another key")
		assert_equal nil, @cm[:mCS]
    end
	
	def test_instance		
		assert_not_equal @cm[:I], @cm[:I]
		assert_not_equal nil, @cm[:I]
    end
	
	def test_custom_scope		
		assert_raise {@cm[:Ses]}
		@cm.open_scope(:session, 'key1')
		assert_not_nil @cm[:Ses]
		
		s1 = @cm[:Ses]
		@cm.open_scope(:session, 'key2')
		s2 = @cm[:Ses]
		@cm.open_scope(:session, 'key1')
		s1v2 = @cm[:Ses]
		assert_equal s1, s1v2
		assert_not_equal s1, s2
    end
	
	def test_invalid_scope_selection		
		assert_raise {@cm.open_scope :service, 1}
		assert_raise {@cm.open_scope :instance, 1}
		@cm.open_scope :custom_scope_1, 2
    end
	
	def test_different_objects_managers_have_different_objects_instances_tree
		@cm = ComponentsManager.new
		cm2 = ComponentsManager.new
		assert_not_equal @cm[:S], cm2[:S]
    end
	
	class Session
		include ManagedComponent
		register :Session, :session
		attr_accessor :request => :Request
    end
	
	class Request
		include ManagedComponent
		register :Request, :request		
    end
	
	def test_change_reference_when_scope_changes
		@cm.open_scope(:session)
		@cm.open_scope(:request)
		
		session = @cm[:Session]
		request = session.request
		assert_equal request, session.request
		
		@cm.delete_scope(:request)
		@cm.open_scope(:request)
		
		assert_not_equal request, session.request
    end
end














