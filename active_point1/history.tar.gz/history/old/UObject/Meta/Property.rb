class Property
	attr_reader :meta
	
	def initialize
		@meta ||= MetaData.new
		
		# Default values
		meta[:type] = :single
    end
	
	def type name
		method_missing :type, name
    end
	
	def method_missing m, *args, &b; 
		meta[m] = args[0]
	end
	
	def control name, &block
		c = Control.new
		c.instance_eval(&block)
		meta.controls[name] = c.meta
    end
end