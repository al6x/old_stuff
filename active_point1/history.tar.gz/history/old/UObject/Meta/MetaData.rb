class MetaData < Hash
	attr_reader :properties, :controls
	
	def initialize
		@properties, @controls = {}, {}
    end
end