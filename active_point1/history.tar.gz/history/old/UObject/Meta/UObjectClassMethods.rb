module UObjectClassMethods
	def meta; 
		@meta ||= MetaData.new
    end
	
	def property name, &block				
		p = Property.new
		p.instance_eval(&block)
		meta.properties[name] = p.meta
		
		if p.meta[:type] == :single
			class_eval "attr_accessor :#{name}"
		elsif p.meta[:type] == :list
			class_eval "def #{name}; @#{name} ||= [] end"
		end
    end		
	
	def control name, &block
		c = Control.new
		c.instance_eval(&block)
		meta.controls[name] = c.meta
    end
	
	def method_missing m, *args, &b; 
		meta[m] = args[0]
	end
end