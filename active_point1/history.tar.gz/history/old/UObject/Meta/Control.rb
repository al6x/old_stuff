class Control
	attr_reader :meta
	
	def initialize
		@meta ||= MetaData.new
    end
	
	def method_missing m, *args, &b; 
		meta[m] = args[0]
	end
	
	def action &block
		meta[:action] = block
    end
end