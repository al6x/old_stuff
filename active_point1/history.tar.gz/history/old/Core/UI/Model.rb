require 'observer'
class Model
	include Observable
	attr_accessor :object, :service
	
	class ChooseRootObject < RuntimeError; end
	
	def initialize
		@service = Service::ApplicationService.instance
    end
	
	def select path
		unless @object && @object.data.path == path
			begin
				@object = @service[path]				
				notify_observers
			rescue NotFound
				if path.empty?
					raise ChooseRootObject.new				
				else
					path = path.previous
					retry 
				end
			end
		end
		return path
    end
	
	def save
		@service.db << @object.data
    end

	alias_method :notify_observers_old, :notify_observers
	def notify_observers
		changed
		notify_observers_old @object
    end
end