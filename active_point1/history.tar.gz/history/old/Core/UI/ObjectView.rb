class ObjectView < WComponent	
	def initialize parent, model
		super parent
		@model = model
		@model.add_observer self
		template 'ObjectView'
		
		@name = Label.new self
		@edit = Button.new self, "Edit", @name do
			editor = build_editor			
			subflow editor do |answer|
				if answer
					data = @model.object.data
					data.path = (Path.new(data.path).previous + editor.path).to_s
					data.name = editor.name
					@model.save
					@model.notify_observers
                end
            end
        end
	end			
	
	def update o				
		@name.text = o.data.name
		@edit.visible = o.parent != nil
		
		childs.delete @object_view
		@object_view = o.view; @object_view.parent = self; childs << @object_view		
	end
	
	def build_editor
		Model::UI::UniversalEditor::Editor.new do|e|
				e.add_field :path, 'Path', TextField, :text, {:text => Path.new(@model.object.data.path).last_name}
				e.add_field :name, 'Name', TextField, :text, {:text => @model.object.data.name}
				e.add_control :ok, 'Ok' do
					answer e
                end
				e.add_control :cance, 'Cancel', false do
					answer nil
                end
            end		
    end
end