class MainPage < WComponent
	include WPortlet	
		
	def initialize
		super
		@model = Model.new
		@model.add_observer self
		
		@page = ObjectView.new self, @model
		@page = WContinuation.new(@page); 
		
		@menu = Menu.new self, @model
		@breadcrumb = Breadcrumb.new self, @model
		template 'MainPage'
	end
		
	def render session
		begin
			self.state = @model.select state
		rescue Model::ChooseRootObject
			choose_root_object
		end
	end
	
	def update object
		@page.cancel
		self.state = Path.new(object.data.path)
    end
	
	def state_conversion_strategy; PathStateConversionStrategy end
		
	protected
	def choose_root_object
		editor = UniversalEditor::Editor.new do |e|
			e.add_field :name, 'Name', TextField, :text
			e.add_field :object_type, 'Type', Select, :selected, {:values => @model.service.object_types}
			e.add_control :ok, 'Ok' do 
				answer
			end
		end
						
		subflow editor do
			data = eval("#{editor.object_type}::Data.new")
			data.set(editor).set(:path => '/', :parent => nil)						
			@model.service.db << data
		end
	end				
end		