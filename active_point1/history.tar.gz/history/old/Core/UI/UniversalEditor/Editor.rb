class Editor < WComponent
	def initialize &builder
		super()
		@title = Label.new self, ""
		@fields, @controls = [], []
		template 'Editor'
#		instance_eval(&builder) if builder
		builder.call self if builder
    end
	
	def each &block
		return unless block
		@fields.each do |f| 
			label = f[2]
			block.call label, send(:"#{label}")
        end
    end

	def title= title; @title.text = title end
	
	def add_field label, name, component_class, result_property, initial_values = nil
		field = component_class.new(self)
		OpenConstructor.copy initial_values, field if initial_values
		
		raise RuntimeError, "Duplicate field '#{label}'!", caller if instance_variables.include? "@#{label}"
		Editor.class_eval "def #{label}; @#{label}.#{result_property} end"
		instance_variable_set :"@#{label}", field
		
		@fields << [Label.new(self, name), field, label]
    end		
	
	def add_control label, name, submit = true, &action
		if submit
			control = Button.new self, name, self, &action
		else
			control = Button.new self, name, &action
		end
		
		raise RuntimeError, "Duplicate control '#{label}'!", caller if instance_variables.include? "@#{label}"
		Editor.class_eval "attr_reader :#{label}"
		instance_variable_set :"@#{label}", control
		
		@controls << control
    end
end