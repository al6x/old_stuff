require 'singleton'

class ApplicationService
	include Singleton

	def initialize
		@db = Db.new 'rad'		
	end
		
	def db; @db end
		
	def [] path; 				
		# TODO Use cache with WeakRef		
		parent = path.empty? ? nil : self[path.previous]
		
		data = @db.single(RADElement::Data){|d| d.path == path}						
					
		o = eval("#{data.object_type}.new")
		o.data, o.parent, o.service = data, parent, self
		o.construct		
		
		# TODO Setup inherited properties
		return o	
	end
		
	def has? path; @db.has?(RADElement::Data){|d| d.name == path} end
		
	def object_types; 
		@object_types ||= [
			Modules::WigetContainer::WigetContainer, 
			Modules::Space::Space
		].collect{|e| e.name}
    end
		
	def wiget_types; 
		@wiget_types ||= [
			Wigets::Text::Text
		].collect{|e| e.name}
    end	
end		
	
	