module RADElement
	attr_accessor :data, :service, :parent
	attr_reader :view
	
	def icon data
		Link.new nil, data.name, data.path
	end
	
	def construct; end
	
	def setup; end
	
	def teardown; end		
end

module RADElement::Data
	include Persistent, OpenConstructor
	attr_accessor :path, :object_type, :name, :parent
end