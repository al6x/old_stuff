class View < WComponent
	attr_accessor :space
	
	def initialize
		super								
		@panel = Panel.new self		
		
		@add = Button.new self, "Add" do
			add_child
        end
		template 'View'
    end		
		
	def update
		@panel.childs.clear
		space.data.childs.each do |row|
			Row.new @panel, space, row
        end
		refresh
    end
	
	protected
	def add_child
		editor = build_editor space.service.object_types
		
		subflow editor do |answer|
			if answer
				data = eval "#{editor.object_type}::Data.new"				
				data.set(editor)
				data.path = (Path.new(space.data.path) + editor.path).to_s				
				space.add data
			end
		end
    end
	
	def build_editor types
		Model::UI::UniversalEditor::Editor.new do |e|
			e.add_field :path, "Path", TextField, :text
			e.add_field :name, "Name", TextField, :text			
			e.add_field :object_type, "Type", Select, :selected, {:values => types}
			e.add_control :ok, "Ok" do
				answer self
            end
			e.add_control :cancel, "Cancel", false do
				answer nil
            end
        end
    end
end