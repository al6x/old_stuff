#class Space
#	include Core::RADElement
#	
#	class Data
#		include Core::RADElement::Data, Persistent
#		attr_accessor :childs
#		
#		def initialize
#			super
#			@childs = []
#        end
#	end	
#	
#	def construct; 
#		@view = View.new
#		@view.space = self
#		@view.update
#    end
#	
#	def delete data
#		self.data.childs.delete data
#		service.db << data
#		@view.update
#    end
#	
#	def add data
#		self.data.childs << data
#		service.db << self.data
#		@view.update
#    end
#end