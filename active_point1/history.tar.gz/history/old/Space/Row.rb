class Row < WComponent
	def initialize parent, space, data
		super parent
		
		object = eval "#{data.object_type}.new"		
		@icon = object.icon data; 
		@icon.parent = self; childs << @icon
		@delete = Button.new self, "Delete" do
			space.delete data			
        end
		
		template 'Row'
    end
end