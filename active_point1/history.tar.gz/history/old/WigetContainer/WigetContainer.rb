#class WigetContainer
#	include Core::RADElement
#	
#	class Data
#		include Core::RADElement::Data, Persistent
#		attr_accessor :component_type
#	end	
#	
#	def construct; 
#		@view = View.new
#		@view.object = self
#    end
#end