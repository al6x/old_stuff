class View < WComponent		
	attr_accessor :object
	def initialize
		super
		
		@change = Button.new self, "Change" do
			choose_component
		end
		template 'View'
	end
	
	def render session
		unless @component
			if object.data.component_type
				initialize_component
			else				
				choose_component false # Choose for the first time.
			end
		end
	end	
	
	def initialize_component		
		w = eval("#{object.data.component_type}.new")									
		w.path, w.db = object.data.path, object.service.db
		w.construct
		
		childs.delete(@component);
		@component = w.view
		childs << @component; @component.parent = self		
		@component = WContinuation.new(@component)
	end
	
	def choose_component cancel = true		
		editor = Core::UI::UniversalEditor::Editor.new do |e|
			e.add_field :component_type, "Type", Select, :selected, {:values => object.service.wiget_types}
			e.add_control :ok, "Ok" do
				answer self
            end
        end		
		editor.add_control(:cancel, "Cancel", false){answer nil} if cancel	
		
		subflow editor do |answer|
			if answer
				object.data.set(editor)
				object.service.db << object.data
				@component = nil
			end
		end
	end
end