class MailService < MPS::ServiceObject
	scope :application
	
	def send letter
		# TODO STUB
		# TODO Should correct work if message where not sended
		info "Sending: "+letter
    end
	
	def receive letter
		# TODO Stub
		info "Received: " + letter
    end
end