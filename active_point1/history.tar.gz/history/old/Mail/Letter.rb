class Letter < Model::UObject	
	attr_accessor :service
	inject :service => MailService
end