class RecievedLetter < Letter	
	initial_state :Created
	trans :Created, :delete, :Deleted
	
	property :title do
		label "Title"
		type :string 
		editable :Never	
    end
	
	property :date do
		label "Date"		
		type :date
		editable :Never
    end
	
	property :message do
		label "Message"
		type :text
		editable :Never
		# TODO show substring of first line in table
    end

	property :attachments do
		label "Attachments"
		type :file #, List
		editable :Never
		# TODO show label in Table that it has attachments
    end
end