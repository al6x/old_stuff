class SendLetter < Letter
	initial_state :Creation
	trans :Creation, :send, :Sended do
		self.date = Date.new
    end
	trans :Sended, :delete, :Deleted
		
	property :to do
		label "To"
		type :string # TODO change to attr.reference to the Contacts
		editable :Creation
    end			
	
	property :title do
		label "Title"
		type :string 
		editable :Creation
    end
	
	property :date do
		label "Date"		
		type :date
		editable :Never
    end
	
	property :message do
		label "Message"
		type :text
		editable :Creation
		# TODO show substring of first line in table
    end

	property :attachments do
		label "Attachments"
		type :file #, List Add it after
		editable :Creation
		# TODO show label in Table that it has attachments
    end		
		
	control :send do 		
		label "Send"
		active :Creation				
		action do |context|
			service.send self			
			state.send									
			context.return self
#			parent.outbox << self
#			context.object = parent
		end
    end
	
	control :cancel do
		label "Cancel"
		active :Creation
		action do |context|
			context.return
        end
    end
	
	control :delete do
		label "Delete"
		active :Sended
		action do |context|
			copy
			state.delete
			commit											
			context.object = parent
        end
    end	
end