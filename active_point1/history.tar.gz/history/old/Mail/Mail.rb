class Mail < Core::UObject		
	property :address do
		title "Address"
		editable :Never
    end
	
	control :send do
		label "Send"
		action do |context|
			context.tmp_object = UObject.instance(SendLetter)
			context.get do |letter|
				copy
				outbox << letter
				letter.add_observer(self, :delete_sent){|o| o.state == :Deleted}
				commit
			end
		end
	end
	
	property :inbox do
		#		label "Inbox" without label		
		tab "Inbox"
		type :list
		columns :to, :title, :date		
		
		control :delete do
			label "Delete"
			action do |context|
				copy
				inbox -= context.selection
				commit
			end
        end
    end
	
	property :outbox do
		#		label "Outbox" without label
		tab "Outbox"
		type :list
		columns :title, :date
		
		control :delete do
			label "Delete"
			action do |context|
				context.selection.each{|letter| delete_sent letter}
			end
        end
    end
	
	def delete_sent letter
		copy
		outbox.delete letter
		commit
    end
end