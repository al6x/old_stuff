require 'wgui/utils/test_server'
require 'RAD/scripts/require'

module RAD::Wigets::Text
#	describe "Text" do
#		it "basic" do
			w = Text.new
			w.path, w.db = "/company/about", Db.new('test', 'test')
			w.construct
start_webserver
set_wiget w.view
join_webserver

			
#        end
#		
#		it "should display Label" do
#			
#        end
#    end
end