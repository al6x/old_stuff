RAD::Wigets::Text::Data
class Text
	include RADWiget
	
	def construct
		self.view = View.new
		view.service = self
	end
	
	def text; data.text end
	
	def text= text
		data.text = text
		db << data
    end
		
	protected
	def data; 
		unless @data
			begin
				@data ||= db.single(Data){|d| d.path == path}
			rescue NotFound
				@data = Data.new.set :path => path.to_s, :text => ""
			end
		end
		@data
	end
				
#	def destroy_data; 
#		o = nil
#		begin
#			o = db.single(Data){|d| d.path == path}
#		rescue NotFound; end
#		db.delete o if o 
#	end
end