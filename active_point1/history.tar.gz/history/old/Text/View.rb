class View < WComponent			
	attr_accessor :service
	
	def initialize
		super
		@text = Label.new self, ""
		@edit = Button.new self, 'Edit' do
			subflow(Editor.new(service.text)) do |text| 
				if text
					service.text = text
					@text.text = text
				end
			end
		end
		template 'View'
	end					
	
	def render session
		@text.text = service.text
    end
end