class Editor < WComponent
	attr_writer :on_ok
		
	def initialize text
		super nil
		@text = TextArea.new self, text
		@ok = Button.new self, "Ok", self do
			answer @text.text
		end
		@cancel = Button.new self, "Cancel" do
			answer nil
		end
		template 'Editor'
	end
end