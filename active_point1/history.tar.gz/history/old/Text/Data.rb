class Data
	include Persistent
	attr_accessor :path, :text
end