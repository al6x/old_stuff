class Group < Item	
	property :groups do
		label "Groups"
		type :list
		columns :name
		
		control :add do
			label "Add"	
			action do  |context|
				context.select(parent.groups) do |selection|		# By default 'select' is multiselect
					selection.each do |o| 
						copy;  o.copy
						
						groups << o																		
						o.belongs_to << self
						o.add_observer(self, :delete_group){|o| o.state == :Deleted}
						
						og.commit
                    end
				end
			end
		end
		
		control :delete do 
			label "Delete"
			action do |context|
				context.selection.each do |ref| 
					delete_group ref				
                end
				#				context.refresh # Vill be automatically refreshed as Observer
			end
		end
	end
	
	property :users do
		label "Users"
		type :list
		
		control :add do
			label "Add"	
			action do  |context|
				context.select(parent.users) do |selection|		# By default 'select' is multiselect
					selection.each do |o| 
						copy;  o.copy
						
						users << o																		
						o.belongs_to << self
						o.add_observer(self, :delete_user){|o| o.state == :Deleted}
						
						og.commit
                    end
				end
			end
		end
		
		control :delete do 
			label "Delete"
			action do |context|
				context.selection.each do |ref| 
					delete_user ref					
                end
			end
		end
	end
	
	def delete_group group
		copy; group.copy					
		groups.delete group
		group.belongs_to.delete self
		og.commit	# View vill be automatically refreshed as Observer
    end
	
	def delete_user user
		copy; user.copy					
		users.delete user
		user.belongs_to.delete self
		og.commit
    end
end