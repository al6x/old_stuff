class Item < Core::UObject
	initial_state :Creation
	trans :Creation, :create, :View
	trans :View, :edit, :Edit
	trans :Edit, :save, :View
	trans :Edit, :cancel, :View
	trans :View, :delete, :Deleted
	# :Creation and :Deleted are mandatory states.
		
	property :name do
		label "Name"
		type :string
    end	
	
	property :belongs_to do
		label "Belongs to"
		type :list
		columns :name		
    end
	
	control :creation_create do
		label "Create"
		active :Creation
		action do |context|					
#			state.create # Not needed, will be done automatically because of 'initial_state'
			context.return self
        end
    end
	
	control :creation_cancel do
		label "Cancel"
		active :Creation
		action do |context|
			context.return
        end
    end
	
	control :edit do
		label "Edit"
		active :View
		action do |context|
			copy
			context.mode = :edit # Need this explicitly, because we need the ':edit' mode not only in ':edit' state.
			state.edit
        end
    end
	
	control :edit_save do
		label "Save"
		active :Edit
		action do |context|		
			context.mode = :view
			state.save
			commit
        end
    end
	
	control :edit_cancel do
		label "Cancel"
		active :Edit
		action do |context|
			context.mode = :view
#			state.cancel # not needed, will do it automatically because of 'rollback'
			rollback
        end
    end
	
	control :delete do
		label "Delete"
		active :View
		action do |context|			
			copy
			state.delete
			commit
			context.object = parent
        end
    end
end