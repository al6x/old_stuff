class Container < Core::UObject
	property :users do
		tab "Users"
		type :list
		columns :name, :full_name
		
		control :add do
			label "Add"
			action do |context|
				context.tmp_object = UObject.instance(User)
				context.get do |new_object|
					new_object.add_observer(self, :delete_user){|o| o.state == :Deleted}
					copy
					users << new_object
					commit
				end				
            end
        end
		
		control :delete do
			label "Delete"
			action do |context|
				context.selection.each do |user|
					delete_user user
                end
            end
        end
    end
	
	property :groups do
		tab "Groups"
		type :list
		columns :name
		
		control :add do
			label "Add"
			action do |context|
				context.tmp_object = UObject.instance(Group)
				context.get do |new_object|
					new_object.add_observer(self, :delete_group){|o| o.state == :Deleted}
					copy
					groups << new_object
					commit
				end				
            end
        end
		
		control :delete do
			label "Delete"
			action do |context|
				context.selection.each do |group|
					delete_group group
                end
            end
        end
    end
	
	def delete_user user
		copy; user.copy
		users.delete user					
		user.state.delete
		og.commit
    end
	
	def delete_group group
		copy; group.copy
		groups.delete group					
		group.state.delete
		og.commit
    end
end