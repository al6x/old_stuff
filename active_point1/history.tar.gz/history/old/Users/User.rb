class User < Item			
	property :full_name do
		label "Full Name"
		type :string
    end
	
	property :password do
		label "Password"
		type :string
    end		
end