require 'util/log'

module DxUtil
	class AutoReload
		include Log
		
		def start
			Thread.new do
				times = Hash.new
				Dir.glob('**/*.rb').each do |f|
					times[f] = File.mtime(f)
				end
				while true
					sleep(2)
					times.each do |fname, time|
						if time != File.mtime(fname)
							begin
								load fname
								info "'#{fname}' has been reloaded."
							rescue Exception => e
								error e
							end
							times[fname] = File.mtime(fname)
						end
					end
				end
			end
        end
    end
end