require 'rubygems'
gem 'log4r'
require 'log4r'

module DxUtil
	module Log
		def info(msg)        
			get_log.info msg
		end
	
		def error(msg)
			get_log.error msg
		end
    
		private
		def get_log
			unless @log
				@log = Log4r::Logger.new self.class.to_s
				@log.outputters = Log4r::Outputter.stdout        
			end
			@log
		end
	end
end