require 'util/tree_path'

class TreePathTest < TestCase
	include DxUtil
	
	def test_absolute_path
		path = TreePath.new("/a/b/c")
		assert_equal TreePath.new('/a'), path.first
		assert_equal TreePath.new('/c'), path.last
		
		str = ''
		path.each do |p|
			str << p.to_s
        end
		assert_equal '/a/b/c', str
		
		assert_equal 3, path.size
		assert_equal TreePath.new("/b/c"), path[1..2]
		assert_equal TreePath.new('/c'), path[2]
		
		assert_equal TreePath.new('/a/b'), path.previous
		assert_equal nil, path.previous.previous.previous
		
		assert_equal TreePath.new('/b/c'), path.next
		
		assert TreePath.new("/b/c") == "/b/c"		
    end
	
	def test_to
		assert_equal TreePath.new("a"), TreePath.new("/a").to_relative
    end
	
	def test_path_equals
		assert TreePath.new("a/b") != TreePath.new("a")
    end
	
	def test_path_creation
		TreePath.new("")
		TreePath.new("/")
    end
	
	def test_append
		path = TreePath.new("")
		path.add_first(TreePath.new("a"))
		assert_equal TreePath.new("a"), path
		
		path = TreePath.new("b")
		path.add_last(TreePath.new("a"))
		assert_equal TreePath.new("b/a"), path
		
		path = TreePath.new("/")
		path.add_first(TreePath.new("a"))
		assert_equal TreePath.new("/a"), path
    end
	
	def test_relative_path
		path = TreePath.new("a/b/c")
		assert_equal TreePath.new('a'), path.first
		assert_not_equal TreePath.new('/c'), path.last
		
		str = ''
		path.each do |p|
			str << p.to_s
        end
		assert_equal 'abc', str
		
		assert_equal 3, path.size
		assert_equal TreePath.new("b/c"), path[1..2]
		assert_equal TreePath.new('c'), path[2]
		
		assert_equal TreePath.new('a/b'), path.previous
		assert_equal nil, path.previous.previous.previous
		
		assert_equal TreePath.new('b/c'), path.next
		
		assert TreePath.new("b/c") == "b/c"
    end
	
end
