require 'rubygems'
gem 'mongrel'
require 'mongrel'
require 'util/tree_path'

module DxUtil
  class Registry
    def initialize 
      @items = Hash.new
    end 
  
    def register(item) 
      id = create_new_id
      @items [id] = item
      return id
    end 
  
    def find(key) 
      @items[key] 
    end 
	
    private
    def create_new_id
      require 'digest/md5'
      md5 = Digest::MD5::new
      now = Time::now
      md5.update(now.to_s)
      md5.update(String(now.usec))
      md5.update(String(rand(0)))
      md5.update(String($$))
      md5.update('foobar')
      md5.hexdigest
    end
  end
	
  class GeneralHandler < Mongrel::HttpHandler  
    include DxUtil
    @@sessions = Registry.new
		
    def initialize(servlet, context_class)
      @servlet = servlet
      @context_class = context_class
    end
	
    def get_session(req, head)
      session_cookie = parse_cookies(req.params['HTTP_COOKIE'])['dx']#.detect{|c| c.name == "dx"}
      if session_cookie
        session = @@sessions.find(session_cookie.value)
      end
    
      unless session
        session = Hash.new
        head['Set-Cookie'] = "dx=#{@@sessions.register(session)}"
      end
		
      return session
    end
    
    def parse_cookies(cookies)
      array = cookies.split('; ')
      hash = Hash.new
      array.each do |c|
        k_v = c.split('=')
        hash[k_v[0]] = k_v[1] if k_v.size > 1
      end
      return hash
    end
	
    def get_context(req, head)
      session = get_session(req, head)
      context = session[:context] 
      unless context
        context = @context_class.new
        session[:context] = context
      end
      return context
    end
	
    def process(req, res)		
      res.start do |head,out|
        context = get_context(req, head)
        @servlet.process(context, req, head, out)					
      end			
    end
  end

  module BuildMongrel
    def self.build(servlet, context_class)
      h = Mongrel::HttpServer.new("0.0.0.0", "80")
      h.register('/', GeneralHandler.new(servlet, context_class))
      return h
    end
  end
 
end