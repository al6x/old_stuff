module DxUtil
	class TreePath
		attr_accessor :path, :absolute
		protected :path, :absolute
		
		def initialize(path)			
			if(path.kind_of?(String))
				@absolute = (path =~ /^\//) == 0
				path = path[1, path.size] if @absolute
				
				@path = path.split('/')
			elsif(path.kind_of?(Array))
				@path = Array.new(path)
				@absolute = false
			else
				raise Exception.new("Invalid argumen")
			end
        end
		
		def add_first(path)
			old = @path
			@path = Array.new(path.path)
			@path.concat(old)
        end
		
		def add_last(path)
			@path.concat(path.path)
        end
		
		def previous
			return nil if @path.size < 2
			new = TreePath.new(@path[0..@path.size-2])
			new.absolute = @absolute
			return new
        end
		
		def next
			return nil if @path.size < 2
			new = TreePath.new(@path[1..@path.size-1])
			new.absolute = @absolute
			return new
        end
		
		def == (other)
			if other.kind_of?(TreePath)
				@path == other.path && @absolute == other.absolute
			elsif other.kind_of?(String)
				self == TreePath.new(other)
			else
				other == self
			end
		end 
		
		def hash() @path.hash end		
		
		def first() 
			anew = TreePath.new([@path.first])
			anew.absolute = @absolute
			anew
        end
		
		def last() 
			new = TreePath.new([@path.last])
			new.absolute = @absolute
			new
        end
		
		def to_absolute
			new = TreePath.new(@path)
			new.absolute = true
			return new
        end
		
		def to_relative
			new = TreePath.new(@path)
			new.absolute = false
			return new
        end
		
		def each
			@path.each do |e| 
				current = TreePath.new([e])
				current.absolute = @absolute
				yield(current)
            end
        end
		
		def to_s
			@path.inject(nil) do |memo, e| 
				if memo
					memo +'/'+e
				else
					if @absolute
						'/' + e
					else
						e
                    end
                end				
            end
        end
		
		def [](*args)
			r = @path[*args]
			if r.kind_of?(String)
				new = TreePath.new([r])
				new.absolute = @absolute
				return new
			elsif r.kind_of?(Array)
				new = TreePath.new(r)
				new.absolute = @absolute
				return new
			else
				raise Exception.new("Invalid argument.")
            end
		end
		
		def size() @path.size end		
    end
end