module DxWiki		
	include DxFw
	
	class WikiPage
		
	end	
	
	class WikiComponent < DxModule	
		include DxFw
	
		def show_object
			@gui = show
        end
		
		def create_object
			@gui = edit
        end
		
		private		
		def build_site			
			center = DxPage.new(@data_object.dx_id, context)
			page.data_object = @data_object
			context.site.center = page
			page
        end
		
		def edit(root)
			form = DxForm.new(root, :form)		
			DxTextField.new(form, :dx_id)
			DxTextField.new(form, :subject)
			DxTextArea.new(form, :text)
			DxFormButton.new(form, :save){
				root.update				
				@data_object.save
				@gui = show(root)
            }
			DxFormButton.new(form, :cancel){
				@gui = show(root)
            }
        end
		
		def show
			page = page()
			panel = DxPanel.new(page, :panel)		
			DxLabel.new(panel, :dx_id)
			DxLabel.new(panel, :subject)
			PageBuilder.new(panel, @data_object.text)
			DxButton.new(panel, :edit){				
				@gui = edit
            }			
			page
        end
    end	
	
	class PageBuilder
		include DxFw
		def initialize(panel, str)
			str.scan(/([\w\s_-]+)|(\[\[[\w_-]+\]\])/i) do |word, link|
				case
				when word
					label = DxLabel.new(panel, "label#{id_counter}")
					label.text = word
				when link
					text = link[2, link.size-4]
					l = DxLink.new(panel, "link#{id_counter}", text)					
					l.text = text
                end
            end
        end
		
		def id_counter
			@counter ||=0
			@counter+=1
			@counter
        end
    end
end