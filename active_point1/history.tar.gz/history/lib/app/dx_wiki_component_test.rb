require 'test/unit'
require 'import'
require 'dx_wiki_component'

class TestWikiComponent < Test::Unit::TestCase
	include DxFw
	
	def setup
		@command = TestCommand.new
		@command.dx_id = "dx_id"		
		
		@context = DxContext.new
		@context.command = @command				
				
		@data_object = TestDataObject.new
    end
	
	def test_for_link
		wiki = %{
my first [[article]] about smt
second line with [[some_link]]
		}
				
		page = DxPage.new(:page, @context)
		PageBuilder.new(page, :panel, wiki)
		
		html = page.render
		
		assert html.include?("my first")
		assert html.include?("href=\"/article\"")
    end
end