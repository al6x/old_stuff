require 'util/webserver'
require 'util/auto_reload'
require 'fw/context'
require 'gui/servlet'

DxUtil::AutoReload.new.start
DxUtil::BuildMongrel.build(DxGui::Servlet.new, DxFw::Context).run.join

