require 'util/tree_path'
require 'erb'

module DxGui			
	class Visual	
		include DxUtil
		attr_accessor :component_id, :parent
		
		class Visitor 
			def accept(visual) raise NotImplementedError.new end	
			def result() nil end
		end
	
		class VisitorUp < Visitor
		end
	
		class VisitorDown < Visitor		
			def visit_childs?() true end
		end
	
		def initialize(parent, component_id)
			@component_id = TreePath.new(component_id.to_s)
			@parent = parent
			parent.add(self) if parent
		end
		
		def component_full_id
			visit(FullIdVisitor.new)
        end
	
		def render
			raise NotImplementedError.new
		end		

		def visit(visitor)
			if visitor.kind_of?(VisitorUp)
				visitor.accept(self)
				@parent.visit(visitor) if @parent
			elsif visitor.kind_of?(VisitorDown)
				visitor.accept(self)
				if self.kind_of?(VisualContainer) && visitor.visit_childs?
					childs.each{|c| c.visit(visitor)} 
				end			
			else
				raise Exception.new("Unsupported visitor type.")
            end
			visitor.result
        end
	
		private
		def render_template(file = nil, params = Hash.new)		
			file = self.class unless file
			dir = File.dirname(__FILE__)
			return ERB.new( IO.read("#{dir}/#{file}.xhtml")).result(binding)
		end		
	
	end

	module VisualContainer
		def childs
			@dx_container_childs ||= Array.new
		end
	
		def add(child)
			childs << child
		end	
	end	
	
	class FullIdVisitor < Visual::VisitorUp		
		def accept(visual)
			@component_full_id ||= DxUtil::TreePath.new("")
			@component_full_id.add_first(visual.component_id)
        end
		
		def result() @component_full_id end
    end
	
	class GetRootVisitor < Visual::VisitorUp		
		def accept(visual) @root = visual end
		
		def result() @root end
    end
	
	class FindByIdVisitor < Visual::VisitorDown
		def initialize(path)
			@path = DxUtil::TreePath.new(path.to_s)
			@visit_childs = false
        end
		
		def accept(visual)
			if @path && @path.first == visual.component_id				
				@current = visual 
				@visit_childs = true
				@path = @path.next
			else
				@visit_childs = false
            end
        end
		
		def visit_childs?() @visit_childs  end
		
		def result() @current  end
    end
	
end