module DxGui
	class Command
		attr_accessor :path	
		
		def to_s 
			"Command : [path = '#{@path}']"
        end
	end

#	class DxPostCommand < DxCommand
#		attr_accessor :component_full_id, :form_full_id, :params
#	
#		def initialize(req)
#			super(req)
#
#			@form_full_id = req.query['component_full_id']
#			@component_full_id = @form_full_id
#			@params = req.query
#		
#			@params.each do |k, v|			
#				if k.index(DxPostCommand.button_sign)
#					button_id = k[DxPostCommand.button_sign.size..k.size-1]
#					@component_full_id += "/"+button_id
#					break
#				end
#			end	
#		end
#	
#		def self.button_sign
#			"button_"
#		end
#	end
end