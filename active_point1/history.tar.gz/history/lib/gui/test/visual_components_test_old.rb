require 'dx_components'

class TestDataObject
	attr_accessor :dx_id, :subject, :text
	def initialize
		@dx_id, @subject, @text = "dx_id", "subject", "text"
    end
end

class TestCommand < DxFw::DxPostCommand
	def initialize
		
    end
end

class DxComponentsTest < TestCase
	include DxFw		
	
	def setup
		
		
		@command = TestCommand.new
		@command.dx_id = "dx_id"		
		
		@context = DxContext.new
		@context.command = @command				
				
		@data_object = TestDataObject.new
    end	
	
	# Test for component rendering
	def test_build_gui	
		return
		# Building GUI tree
		page = DxPage.new(@data_object.dx_id, @context)
		page.data_object = @data_object
		
		form = DxForm.new(page, :form)		
		DxTextField.new(form, :dx_id)
		DxTextField.new(form, :subject)
		DxTextArea.new(form, :text)
		DxFormButton.new(form, :save){
		}			
		
		panel = DxPanel.new(page, :panel)		
		DxLabel.new(panel, :dx_id)
		DxLabel.new(panel, :subject)
		DxLabel.new(panel, :text)			
		DxLink.new(panel, :link, :my_car)
		
		# Render
		html = page.render
		
		# Some checks
		assert html.include?("dx_id")
		assert html.include?("subject")
		assert html.include?("text")
    end
	
	# Test for 'POST' action execution
	def test_post_action	
		return 
		# Building GUI tree
		page = DxPage.new(@data_object.dx_id, @context)
		page.data_object = @data_object
		
		form = DxForm.new(page, :form)		
		result = nil
		DxFormButton.new(form, :fbutton){
			result = "fbutton"
		}			
		
		DxButton.new(page, :btn){
			result = "btn"
        }
				
		# First button pressed
		@command.component_full_id = "dx_id/form/fbutton"
		@command.form_full_id = "dx_id/form"
		
		DxComponent.find_by_id(page, @command.component_full_id).execute
		assert result == "fbutton"	
		
		# Second button pressed
		@command.component_full_id = "dx_id/btn"
		@command.form_full_id = "dx_id/btn"
		
		DxComponent.find_by_id(page, @command.component_full_id).execute
		assert result == "btn"	
    end
	
	def test_form_data_update
		return
		# Building GUI tree
		page = DxPage.new(@data_object.dx_id, @context)
		page.data_object = @data_object
		
		form = DxForm.new(page, :form)		
		DxTextField.new(form, :subject)
		DxFormButton.new(form, :save){
		}
		
		# Form submit
		@command.component_full_id = "dx_id/form/save"
		@command.form_full_id = "dx_id/form"
		@command.params = {"subject" => "new subject"}
		
		# Processing
		page.update
		
		assert @data_object.subject == "new subject"
    end
end
