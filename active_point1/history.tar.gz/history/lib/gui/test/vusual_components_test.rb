require 'util/webserver'
require 'util/log'
require 'util/auto_reload'
require 'gui/visual_components'
require 'gui/command'
require 'gui/servlet'

require 'rubygems'
gem 'watir'
require 'watir'

class VisualComponentsTest < TestCase
	include DxUtil::Log	
	
	class TestContext
		include DxUtil::Log
		include DxGui
		
		def get(path)
			@command ||= Command.new
			@command.path = path
			self.send(path.to_relative.to_s)
		end
		
		def action(component_full_id, form_full_id, params)
			form = @gui.visit(FindByIdVisitor.new(form_full_id))
			form.visit(UpdateVisitor.new(params))
			
			@gui.visit(FindByIdVisitor.new(component_full_id)).execute
        end
		
		def test_button
			@gui = Button.new(nil, :button1, "Button 1") do
				@@result = :test_button_ok
				@gui.text = "Button 1 (has been pressed)"
            end
        end
		
		def test_form
			@gui = Page.new(:page1)
			form = Form.new(@gui, :form1)
			b = FormButton.new(form, :button1, "Button 1") do
				@@result=:test_form_ok
				b.text = "Button 1 (has been pressed)"
            end
			b2 = FormButton.new(form, :button2, "Button 2") do
				@@result=:test_form_ok
				b2.text = "Button 2 (has been pressed)"
            end
        end
		
		def test_label
			@gui = Label.new(nil, :label1)
			@gui.text = "Label 1"
        end
		
		def test_panel
			@gui = Panel.new(nil, :panel1)
			Label.new(@gui, :label, "Label insait the panel")
        end
		
		def test_text_field
			@gui = Form.new(nil, :form1)
			tf1 = TextField.new(@gui, :tf1, "some text")
			FormButton.new(@gui, :submit, "Submit (Text input should remember changes after submit)"){}
        end
		
		def test_link
			@gui = Link.new(nil, :link1, 'test', "test")
        end
		
		def test_text_area
			@gui = Form.new(nil, :form1)
			TextArea.new(@gui, :ta1, "some text")
			FormButton.new(@gui, :submit, "Submit (Text input should remember changes after submit)"){}
        end
		
		def render
			@gui.render(self)
        end
    end
	
	class SimpleHandler < Mongrel::HttpHandler
		def process(request, response)
			response.start do |head,out|
				head["Content-Type"] = "text/plain"
				out.write("hello!\n")
			end
		end
	end
	
	def setup		
		@h = Mongrel::HttpServer.new("0.0.0.0", "80")
		@h.register("/test", SimpleHandler.new)
		@h.run
		@ie = Watir::IE.new		
		@ie.bring_to_front
    end		
	
	def teardown		
		@h.stop
		Watir::IE.close_all
    end
	
	def test_one		
		@ie.goto 'localhost/test'
		assert @ie.text.include?('hello')
    end
	
	def test_two
		@ie = Watir::IE.new
		@ie.goto 'localhost/test'
		assert @ie.text.include?('hello')
    end
	
	#	def test_button
	#		return
	#		$ie.goto 'localhost/test_button'
	#		$ie.button(:value, "Button 1").click
	#		$ie.text.include? "Button 1 (has been pressed)"
	#		$ie.close
	#    end			
	#			
	#	def test_form	
	#		return
	#		$ie.goto 'localhost/test_form'
	#		$ie.button(:value, "Buton 1").click
	#		$ie.text.include? "Button 1 (has been pressed)"
	#		$ie.close
	#	end
	#		
	#	def test_label
	#		$ie.goto 'localhost/test_label'
	#		$ie.text.include? "Label 1"
	#		$ie.close
	#	end
	#		
	#	def test_panel
	#		return
	#		$ie.goto 'localhost/test_label'
	#		$ie.text.include? 'Label insait the panel'
	#	end
	#		
	#	def test_text_field
	#		return
	#		$ie.goto 'localhost/test_text_field'
	#		$ie.text_field(:value, 'some text').set "new value"
	#		$ie.button(:value, "Submit (Text input should remember changes after submit)").click
	#		$ie.text.include? 'new value'
	#	end
	#		
	#	def test_link
	#		$ie.goto 'localhost/test_link'
	#		$ie.text.include? 'test'
	#	end
	#		
	#	def test_text_area
	#		return
	#		@gui = Form.new(nil, :form1)
	#		TextArea.new(@gui, :ta1, "some text")
	#		FormButton.new(@gui, :submit, "Submit (Text input should remember changes after submit)"){}
	#		$ie.goto 'localhost/test_text_area'
	#		$ie.area(:name, 'form1/ta1').set "new value"
	#		$ie.button(:value, "Submit (Text input should remember changes after submit)").click
	#		$ie.text.include? 'new value'
	#	end

end
