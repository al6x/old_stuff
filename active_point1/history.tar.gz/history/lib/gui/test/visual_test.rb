require 'gui/visual'

class TestContainer < DxGui::Visual
	include DxGui::VisualContainer	
	
	def initialize(parent, component_id)
		super( parent, component_id)
	end
end

class TestWikiComponent < TestCase
	include DxGui		
	
	def setup
		@root = TestContainer.new(nil, :root)		

		@l11 = TestContainer.new(@root, :l11)
		@l12 = TestContainer.new(@root, :l12)
		
		@l21 = TestContainer.new(@l11, :l21)
		@l22 = TestContainer.new(@l11, :l22)
		@l23 = TestContainer.new(@l12, :l23)
		
		@child1 = TestContainer.new(@root, :child1)
		@child2 =Visual.new(@child1, :child2)	
    end
	
	def test_find_root
		assert @child2.visit(GetRootVisitor.new) == @root
    end
	
	def test_full_id
		assert_equal DxUtil::TreePath.new("root/child1/child2"), @child2.visit(FullIdVisitor.new)
    end
	
	def test_find_by_id
		assert_equal  @child2, @child1.visit(FindByIdVisitor.new("child1/child2"))
		assert_equal @l23.component_id, @root.visit(FindByIdVisitor.new("root/l12/l23")).component_id
    end
end
