require 'gui/visual'

module DxGui	

	class InputVisual < Visual
		
    end
	
	class Page < Visual
		include VisualContainer  	
		attr_accessor :data_object, :context     
         
      	def initialize(component_id, title='')  		
			super( nil, component_id)  		
			@title = title
        end
     
      	def render(context)
			render_template('page', {:context=>context, :title=>@title}) 
        end
	end
	
	class UpdateVisitor < Visual::VisitorDown
		def initialize(params)
			@params = params
        end
		
		def accept(visual)
			if visual.kind_of?(InputVisual)
				if @params.include?(visual.component_full_id.to_s)
					visual.text = @params[visual.component_full_id.to_s]
                end
            end
        end		
	end
		
	class FormButton < Visual	
		attr_writer :text
		def initialize(parent, component_id, text, &action)
			super(parent, component_id)
			@text = text
			@action = action
		end
		
		def execute
			@action.call
        end				
	
		def render(context)
			%{<span id="#{@component_id}" component="#{self.class}">
				<input name="#{FormButton.button_sign+@component_id.to_s}" type="submit" value="#{@text}"/>
			</span>}
		end				
		
		def self.button_sign
			'button_'
        end
	end
	
	class Button < Visual	
		attr_writer :text
		def initialize(parent, component_id, text, &action)
			super(parent, component_id)
			@text = text
			@action = action
		end
	
		def execute			
			@action.call
        end
		
		def context
			find_root.context
        end
		
		def render(context)
			%{<div id="#{@component_id}" component="#{self.class}">
	<form action="" method="post">
		<input type="hidden" name="component_full_id" value="#{component_full_id}"/>
		<input type="submit" value="#{@text}"/>
	</form>
</div>}			
		end
	end	

	class Form < Visual
		include VisualContainer
	
		def initialize(parent, component_id)
			super(parent, component_id)		
		end
	
		def render(context)
			render_template('form', {:context=>context})
		end		
	end
	
	class Panel < Visual
		include VisualContainer
		
		def initialize(parent, component_id)
			super(parent, component_id)
		end
		
		def render(context)
			render_template('panel', {:context=>context})
        end
    end

	class Label < Visual
		attr_writer :text
		def initialize(parent, component_id, text = '')
			super(parent, component_id)
			@text = text
		end
	
		def render(context)
			%{<div id="#{@component_id}" component="#{self.class}">#{@text}</div>}
		end
	end	
	
	class TextField < InputVisual
		attr_accessor :text
		def initialize(parent, component_id, text='')
			super(parent, component_id)
			@text = text
		end
	
		def render(context)
			%{<div id="#{@component_id}" component="#{self.class}">
					<input type="text" name="#{component_full_id}" value="#{@text}"/>
				</div>}
		end
	end

	class Link < Visual
		attr_accessor :reference_component_id, :text
		def initialize(parent, component_id, reference_component_id, text='')
			super(parent, component_id)
			@reference_component_id = reference_component_id
			@text = text
		end
	
		def render(context)
			%{<div id="#{@component_id}" component="#{self.class}">
				<a href="/#{@reference_component_id}">#{@text}</a>
			</div>}
		end
	end
	
	class TextArea < InputVisual
		attr_accessor :text
		def initialize(parent, component_id, text = '')
			super(parent, component_id)
			@text = text
        end
		
		def render(context)
			%{<div id="#{@component_id}" component="#{self.class}">
					<textarea name="#{component_full_id}">#{@text}</textarea>
				</div>}
        end
    end
end