require 'util/tree_path'

module DxGui
  class Servlet			
    def process(context, req, head, out)
      case
      when req.params['REQUEST_METHOD'] == 'GET'
        context.get(DxUtil::TreePath.new(req.params['REQUEST_PATH']))
      when req.params['REQUEST_METHOD'] == 'POST'				
        form_full_id=req.query['component_full_id']
        params = req.query
        component_full_id = form_full_id	
				
        params.each do |k, v|			
          if k.index(FormButton.button_sign)
            button_id = k[FormButton.button_sign.size..k.size-1]
            component_full_id += "/"+button_id
            break
          end
        end							
				
        context.action(
          DxUtil::TreePath.new(component_full_id), 
          DxUtil::TreePath.new(form_full_id), 
          params)				
      end				
			
      head['ContentType'] = "text/html"
      out.write(context.render)
    end
  end
end