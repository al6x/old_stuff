require 'rubygems'
gem 'maveric'
require 'maveric'

class MyIndex < Maveric::Controller
    def get
		
		@env[:counter] ||= 1
		@env[:counter] += 1
		"Hello, world!  "
    end
end
  
require 'maveric/mongrel'
m = Maveric.new
m.add_route(MyIndex, "/.*")

h = Mongrel::HttpServer.new('localhost', 80)
h.register '/', m
h.run.join