include Java

class Persistence	
    # # def self.attribute(name, attr_class) # 	attr_accessor name # 	attr_class_name = name.to_s+"_class"
    # 
    # # 	class_variable_set("@@#{attr_class_name}", attr_class)
    #    end
	@@simple_classes = [Bignum, Fixnum, Float, Integer, NilClass, String, Symbol, Time, FalseClass, TrueClass]

	def self.to_object(data, trace = Hash.new, virtual_id = Hash.new)
		if @@simple_classes.include?(data.class)
			return data
		else						
			obj = Kernel.const_get(data["class"]).new
			trace[data] = obj
			
			data.each do |name, value|
				next if name == "class" 

				if @@simple_classes.include?(value.class)
					obj.instance_variable_set(name, value)
				elsif value.kind_of?(java.util.ArrayList)
					array = Array.new
					obj.instance_variable_set(name, array)
					value.each do |v| 
						if trace.include?(v)
							array << trace[v]
						else
							array << Persistence.to_object(v, trace)
                        end						
					end
				elsif value.kind_of?(java.util.HashMap)
					if value.include?("class")
						if trace.include?(value)
							obj.instance_variable_set(name, trace[value])			
						else
							obj.instance_variable_set(name, Persistence.to_object(value, trace))			
						end
					else
						h = Hash.new
						obj.instance_variable_set(name, h)
						value.each do |k, v| 
							if trace.include?(v)
								h[k] = trace[v]
							else
								h[k] = Persistence.to_object(v, trace)
							end						
						end										
					end
				end
			end		
			return obj
		end
	end
	
	def self.to_hash(obj, trace = Hash.new)				
		if @@simple_classes.include?(obj.class)
			return obj
		else
			hash = java.util.TreeMap.new
			trace[obj]=hash
			
			hash["class"] = obj.class.to_s
			obj.instance_variables.each do | name |
				value = obj.instance_variable_get(name)
				if @@simple_classes.include?(value.class)
					hash[name]=value
				elsif value.kind_of?(Array)
					array = java.util.ArrayList.new					
					value.each do |v| 
						if trace.include?(v)
							array << trace[v]
						else
							array << Persistence.to_hash(v, trace) 
                        end						
                    end
					hash[name] = array
				elsif value.kind_of?(Hash)
					h = java.util.HashMap.new					
					value.each do |k, v| 
						if trace.include?(v)
							h[k] = trace[v]
						else
							h[k] = Persistence.to_hash(v, trace)
                        end						
                    end
					hash[name] = h
				else
					if trace.include?(value)
						hash[name]=	trace[value]
					else	
						hash[name]=	Persistence.to_hash(value, trace) 		
                    end
				end				
			end			
			return hash
		end		
	end
end

# #class Hashit
#  def initialize(hash)
#    hash.each do |k,v|
#      self.instance_variable_set("@#{k}", v)  ## create and initialize an instance variable for this key/value pair
#      self.class.send(:define_method, k, proc{self.instance_variable_get("@#{k}")})  ## create the getter that returns the instance variable
#      self.class.send(:define_method, "#{k}=", proc{|v| self.instance_variable_set("@#{k}", v)})  ## create the setter that sets the instance variable
#    end
#  end
# #end

class Test
	attr_accessor :astring, :aint, :ahash, :aarray, :child
end

class Child
	attr_accessor :name, :parent
end

t = Test.new
#t.astring = "aString"
#t.aint = 10
#t.ahash = Hash.new
#t.ahash["a"]="b"
#t.aarray = Array.new
#t.aarray << "v1"

c = Child.new
#c.name = "name"
c.parent = t

t.child = c

h = Persistence.to_hash(t)

import "dx.Db4oMapConvertor"

#h_ref = Db4oMapConvertor.cut_reference_cycle(h)
#t2 = Persistence.to_object(h) 
#puts h.to_s

File.delete("c:/tmp/db")
db = com.db4o.Db4o.openFile("c:/tmp/db")
## p1 = java.util.HashMap.new #p1["name"] = "Ralph" #p1["score"] = 7
db.set(h) #puts "did" #db.close 
## db = com.db4o.Db4o.openFile("c:/tmp/db"); search = java.util.HashMap.new search["a"]="a" list = db.get(java.util.HashMap.class) puts list.size while list.hasNext # puts list.next #end ##puts
## "map3="+map3["b"]
db.close