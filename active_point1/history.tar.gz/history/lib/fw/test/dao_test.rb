require 'fw/dao'

class TestToXmlClassInner	
	
  attr_accessor :string_a, :parent
  def initialize
    @string_a = "some string"
  end
	
  def == (other)
    if other.kind_of?(TestToXmlClassInner)
      @string_a == other.string_a
    else
      other == self
    end
  end
	
  def hash
    @string_a.hash
  end
		
end

class TestToXmlClass 
  attr_accessor :string_a, :int_b, :array_c, :hash_d, :object_e
  def initialize
    @string_a = "a\ns\"'\'d"
    @int_b = 26
    @array_c = ['one', 2, TestToXmlClassInner.new]
    @hash_d = {:one => "one", "two" => 2, "inner_object" => TestToXmlClassInner.new, TestToXmlClassInner.new => TestToXmlClassInner.new}
    @object_e = TestToXmlClassInner.new
    @object_e.parent = self
  end	
end

class SimpleTestClass
  attr_accessor :name, :value
end
		
class TestDao < TestCase
  include DxFw
  include DxFw::Db	
	
  def setup		
  end
	
  def test_db
    o = SimpleTestClass.new
    o.name, o.value = "name", "value"
				
    db.put("simple", o)		
    o2 = db.get("simple")
    assert_equal [o.name, o.value], [o2.name, o2.value]
		
    db.delete("simple")
    o3 = db.get("simple")
    assert_equal nil, o3
  end
	
  def test_search		
    5.times do |n|
      o = SimpleTestClass.new
      o.name, o.value = "name#{n}", "value#{n}"
      db.put("simple#{n}", o)
    end
		
    list = db.search("/*[@class='#{SimpleTestClass.to_s}']")
    assert_equal 5, list.size
		
    5.times do |n|
      o = SimpleTestClass.new
      o.name, o.value = "name#{n}", "value#{n}"
      db.delete("simple#{n}")
    end
		
    list = db.search("/*[@class='#{SimpleTestClass.to_s}']")
    assert_equal 0, list.size
  end
	
  def test_to_xml
    e = Dao.to_xml('test', TestToXmlClass.new)
    assert_equal "26", e.elements["//int_b"].text
    assert_equal e.elements['//object_e//parent'].attributes['link'], e.attributes['counter']
    assert_equal  "some string", e.elements['//hash_d//key//string_a'].text
    assert_equal "a\ns\"'\'d", e.elements['/string_a'].text
    assert_equal "2", e.elements['//array_c//item'].next_sibling.text
  end
	
  def test_prefixed_name
    Dao.clear_name(nil)
    Dao.clear_name('')
    assert 'name' == Dao.clear_name('@name')
  end
	
  def test_to_obj
    e = Dao.to_xml('test', TestToXmlClass.new)
    o = Dao.to_obj(e)
		
    assert_equal "a\ns\"'\'d", o.string_a
    assert_equal 26, o.int_b
    assert_equal ['one', 2, TestToXmlClassInner.new], o.array_c		
    # # 	assert_equal({:one => "one", "two" => 2, "inner_object" => TestToXmlClassInner.new, TestToXmlClassInner.new => TestToXmlClassInner.new}, o.hash_d) # 	failure because of
    # TestToXmlClassInner.new => TestToXmlClassInner.new
    assert_equal TestToXmlClassInner.new, o.object_e 
    assert_equal o, o.object_e.parent
    assert_equal "some string", o.object_e.string_a
  end
	
  def test_no_presence
    a  = db.get("adfadsfa")
    assert_equal nil, a
		
    assert_raise(Exception) { db.delete("adfadsfa") }
  end
	
  def test_performance	
    return
    puts
    puts '--- Performance test start ---'
				
    # Original
    from = Time.new
    1000.times do
      a = TestToXmlClass.new
      @a = a.object_id
    end
    time = Time.new - from		
    puts "Original Ruby: #{time}"
				
    # to_xml
    a = TestToXmlClass.new
    from = Time.new
    1000.times do
      xml = Dao.to_xml('test', a)
      @a = xml.object_id
    end
    time = Time.new - from		
    puts "to_xml: #{time}"
		
    # to_obj
    xml = Dao.to_xml('test', TestToXmlClass.new)
    from = Time.new
    1000.times do
      a = Dao.to_obj(xml)
      @a = a.object_id
    end
    time = Time.new - from		
    puts "to_obj: #{time}"
		
    require 'yaml'
    # to_yaml
    a = TestToXmlClass.new
    yaml = StringIO.new
    from = Time.new
    1000.times do
      YAML.dump(a, yaml)
      @a = yaml.object_id
    end
    time = Time.new - from		
    puts "to_yaml: #{time}"
		
    # to_obj
    yaml = StringIO.new
    YAML.dump(TestToXmlClass.new, yaml)
    from = Time.new
    1000.times do
      a = YAML.load(yaml)
      @a = a.object_id
    end
    time = Time.new - from		
    puts "to_obj: #{time}"
		
    puts '--- Performance test stop ---'
  end
end
