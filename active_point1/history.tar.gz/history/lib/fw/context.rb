require 'fw/dao'

module DxFw				
  class DxModule
    attr_accessor  :context, :data_object, :gui
		
    def show_object
      raise NotImplementedError.new
    end
		
    def create_object
      raise NotImplementedError.new
    end
  end
	
  class DefaultComponent
    def initialize(cmd)
      @cmd = cmd
    end
		
    def render
      "Stub for DxDefaultComponent. (cmd='#{@cmd}')"
    end
  end
	
  class Context
    include Db
    
    def render
      @component.render
    end
		
    def get(path)
      cmd = Command.new(path)
      return if @cmd && @cmd.path == cmd.path
      @cmd = cmd
			
      chain = build_chain
			
      last = nil
      chain.each do |controller|				
        next unless controller
        controller.process(cmd)
        controller.component.decorate(last) if last
        last = controller.component
      end
      @component = last
			
      unless @component
        @component = DefaultComponent.new(cmd)
      end
    end
		
    private
    def build_chain
      chain = Array.new
      path = @cmd.path
      begin
        chain << db.get("_metadata", path.to_s)
      end while path = path.previous
      chain
    end
		
    def process_get
      load 'dx_wiki_component.rb'
      unless(@current_path == command.current_path)			
        @component = DxWiki::WikiComponent.new
        @component.context = self
        data_object = DxWiki::WikiPage.find_by_dx_id(command.dx_id)			
        if(data_object)
          @component.data_object = data_object
          @component.show_object
        else
          data_object = DxWiki::WikiPage.new
          data_object.dx_id = command.current_path.sub("/","")
          @component.data_object = data_object
          @component.create_object
        end			
      end		
      @current_path = command.current_path			
    end
		
    def process_post
      load 'dx_wiki_component.rb'
      DxComponent.find_by_id(@component.gui, command.component_full_id).execute
    end	    
  end
end