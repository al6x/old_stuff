drop table if exists sodb;
drop table if exists id;
drop table if exists stored_id;

drop table if exists metadata_hierarchy;
drop table if exists metadata_attributes;

drop table if exists data_objects;
drop table if exists data_collections;
