create table sodb(just_a_marker_table);
create table id(id);
insert into id values (0);
create table stored_id(object_id, sodb_id);

create table metadata_hierarchy (class, parent);
create table metadata_attributes (class, attribute);

create table data_objects (id, class, version);
create table data_collections (id, version, key, type_key, value, type_value, rtype_value);
