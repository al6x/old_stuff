require 'sqlite3'
require 'set'
require 'sodb/script_helper'
require 'utils/log'

module SODB
	# TODO synchronize all methods (make synhronized vrapper?)
	class Adapter
		include Log
		attr_reader :filename
		
		def initialize name, dir = ''			
			@filename = Adapter.filename(name, dir)
			@db = SQLite3::Database.new @filename
			@db.results_as_hash = true
        end
		
		def prepare sql, &block
			@db.prepare sql, &block
        end
		
		def self.delete name, dir = ''
			file = Adapter.filename(name, dir)
			File.delete file if File.exists? file
        end		
		
		def execute *sql; 
#			puts *sql
			@db.execute(*sql)			
        end
		
		def execute_batch *sql; 
#			puts *sql
			@db.execute_batch(*sql)
        end
		
		def tables
			@db.execute("select name from sqlite_master where type = 'table'").map{|row| row['name']}			
        end
		
		def columns_for_table table
			@db.table_info(table).map{|row| row['name']}
        end
		
		def has_table? name; tables.include? name end
		
		def close
			@db.close
        end
		
#		def transaction &block; @db.transaction &block end
		
		def transaction &block; 
			begin
				@db.transaction
				block.call self
				@db.commit
            rescue Exception => e
				@db.rollback
				raise e
			end
        end
		
		private
		def self.filename name, dir
			(dir.empty? ? '' : dir + '/') + (name.empty? ? '' : name + '.sqlite3')
        end
	end
end