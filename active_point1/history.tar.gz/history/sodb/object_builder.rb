require 'sodb/lazy_collection'

module SODB
	class ObjectBuilder
		def initialize adapter; @adapter = adapter end
		
		def build_by_id id
			klass = nil
			begin
				klass = @adapter.execute("select class from data_objects where id = #{id}")[0]['class']
            rescue Exception
			end
			raise "There is no object with id = '#{id}'" unless klass
			return build_by_id_and_class(id, klass)
        end
		
		def build_by_id_and_class id, klass
			if (klass == Array.name) || (klass == Hash.name)
				rows = @adapter.execute(
					"select * from data_collections where id = #{id}"
				)
			
				return initialize_collection_from_rows(id, klass, rows)
			else
				row = @adapter.execute(
					"select * from #{Schema.data_table_name klass} where id = #{id}"
				)[0]
			
				return initialize_object_from_row(id, klass, row)			
            end			
        end		
	
		private
		def initialize_object_from_row id, klass, row
			o = eval "#{klass}.new"
			
			attrs = o.class.sodb_persistent_properties
			
			attrs.each_with_index do |a_name, i|
				type = row[Schema.attribute_type(a_name)]
				value = row[a_name]
				if type == Reference.name
					ref_class = row[Schema.reference_type(a_name)]
					value = Reference.new(value.to_i, ref_class)
				else
					value = create_simple_object type, value
                end
				o.send :"#{a_name}=", value
            end
			
			o.sodb_id = id
			o.sodb_version = row['version'].to_i
			return o
        end
		
		def initialize_collection_from_rows id, klass, rows
			c = eval "#{klass}.new"
			
			rows.each do |row|
				key = create_simple_object row['type_key'], row['key']
				value = row['value']
				type = row['type_value']				
				if type == Reference.name
					ref_class = row['rtype_value']
					value = Reference.new(value.to_i, ref_class)
				else
					value = create_simple_object type, value
                end
				c[key] = value
            end
			
			c = LazyCollection.new(c)
			c.sodb_id = id			
			c.sodb_version = (rows.size > 0) ? rows[0]['version'].to_i : 1 # if empty collection has been saved
			return c
        end
		
		def create_simple_object type, value
			# TODO change to if/elsif/else, and add value.is_a? Numeric condition
			case type
			when 'String' then value
			when 'NilClass' then nil
			when 'TrueClass' then true
			when 'FalseClass' then false
			when 'Symbol' then value.to_sym			
			else 
				value.to_i # Probably Numeric
            end
        end
    end
end