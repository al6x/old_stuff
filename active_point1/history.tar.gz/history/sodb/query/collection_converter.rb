module SODB
	module Query
		class CollectionConverter < AbstractConverter	
			def backlink; "l#{@level}_cns.value" end

			def build_sql			
				als = "l#{@level}_cns"
				
				if @builder.value # Simplest case, just value
					value = value_to_sql @builder.value.operator, @builder.value.value										
					@sql << %{\
( -- Collections (#{@builder.back_reference})
	(
		select count(*)
		from data_collections #{als}
		where #{@parent_id} = #{als}.id and #{als}.value #{value}
	)	
	#{quantity_clause als}
)					
                    }
				else # General case, reference or other collection					
					clause_operator = ClauseOperator.new 'and'
					
					clauses = [clause_operator.wrap("#{@parent_id} = #{als}.id")]
					if @klass_clause
						clauses << clause_operator.wrap(@klass_clause)
                    end
					
					if @attributes_clauses.size > 0
						clauses << @attributes_clauses.collect{|clause| clause_operator.wrap(clause)}.join(' ')
                    end
					
					if @collections_clauses.size > 0
						clauses << @collections_clauses.collect{|clause| clause_operator.wrap(clause)}.join(' ')
                    end
										
					if @references_clauses.size > 0
						clauses << @references_clauses.collect{|clause| clause_operator.wrap(clause)}.join(' ')
                    end
					
					@sql << %{\
( -- Collections (#{@builder.back_reference})
	(
		select count(*)
		from data_collections #{als},
			#{@query_table_clauses.join(', ') if @query_table_clauses.size > 0}
		where  
#{AbstractConverter.make_indent(clauses.join("\n"), 3)}
	)
	#{quantity_clause als}
)
					}
                end
            end			
			
			def quantity_clause als
				quantity = @builder.quantity

				if quantity == :all
					quantity_clause = "= (select count(*) from data_collections #{als} where #{@parent_id} = #{als}.id)"
				elsif quantity == :any
					quantity_clause =  "> 0"
				elsif quantity.is_a? Hash
					if quantity[:size]
						quantity_clause = "#{quantity[:size]}"
					else
						raise "Not defined 'size' paramether."
                    end
				else
					raise "Uncnown quantity clause '#{quantity}'."
				end
				
				return quantity_clause
            end
		end
    end
end