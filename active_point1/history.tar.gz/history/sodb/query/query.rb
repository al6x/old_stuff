require 'utils/log'
require 'sodb/query/sql_converter'
require 'ostruct'

module SODB
	# TODO Suround each method with begin/rescue using AOP
	module Query
		class AbstractBuilder
			['=='].each{|m| undef_method m}		
			
			def initialize
				@attributes, @references, @collections = [], [], []
				@processor = qualificator
			end

			attr_accessor :class_clause, :attributes, :references, :collections, :back_reference

			def method_missing s, *a, &b							
				@processor.call(s.to_s, a, b)
				return self
			end			
			
			def klass
				@processor = lambda{|operator, operand, block|
					@class_clause = OpenStruct.new :operator => operator, :klass => operand[0]
					@processor = qualificator
				}
				return self
			end	
			
			def attribute_processor attribute_name
				return lambda{|operator, operand, block|				
					@attributes << OpenStruct.new(
						:name => attribute_name, :operator => operator, :value => operand[0]
					)

					@processor = qualificator
				}
			end
		end
		
		class ObjectBuilder < AbstractBuilder		
			attr_accessor :order
			
			def initialize; super end
			
			def qualificator
				return lambda{|term, params, block|
					if block # array or reference
						if params.size > 0 # array
							cb = CollectionBuilder.new
							cb.quantity = params[0]
							cb.back_reference = term
							@collections << cb
							block.call cb
						else # reference
							ob = ObjectBuilder.new
							ob.back_reference = term
							@references << ob
							block.call ob
						end					
					else # simple attribute
						@processor = attribute_processor term
					end				
				}
			end											
		end
	
		class CollectionBuilder < AbstractBuilder
			attr_accessor :quantity, :value
		
			def initialize; super end
			
			def qualificator
				return lambda{|term, params, block|
					if block # array or reference
						if params.size > 0 # array
							cb = CollectionBuilder.new
							cb.quantity = params[0]
							cb.back_reference = term
							@collections << cb
							block.call cb
						else # reference
							ob = ObjectBuilder.new
							ob.back_reference = term
							@references << ob
							block.call ob
						end								
					else # simple attribute or array value
						if ['==', 'not', '<', '>', '<=', '>='].include? term # array value
							@value = OpenStruct.new(:operator => term, :value => params[0])
							@processor = lambda {
								raise "You can't define anything other if you defined 'value' clause"								
							}
						else # simple attribute
							@processor = attribute_processor term
                        end						
					end				
				}
			end
		end
	
		class Query
			def initialize adapter; @adapter = adapter end
		
			def get *params, &block
				builder = ObjectBuilder.new
				if params.size > 0					
					p = params[0]
					if p.is_a? Hash						
						builder.klass == p[:class] if p[:class] # exactly '==' not '='
						builder.order = p[:order] if p[:order]
					else
						builder.klass == p # exactly '==' not '='
					end				
				end
				
				block.call builder if block
			
				converter = SQLConverter.new builder
				begin
					return @adapter.execute(converter.get_sql)
				rescue Exception => e
					return [] if e.message =~ /no such table/
					raise e
				end
			end
		end		
	end
end