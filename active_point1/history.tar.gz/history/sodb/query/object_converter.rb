module SODB
	module Query				
		class ObjectConverter < AbstractConverter							
			protected			
			def backlink; @parent_id end												
			
			def build_sql
				clause_operator = ClauseOperator.new 'and'
					
				clauses = []
				if @klass_clause
					clauses << clause_operator.wrap(@klass_clause)
				end
					
				if @attributes_clauses.size > 0
					clauses << @attributes_clauses.collect{|clause| clause_operator.wrap(clause)}.join(' ')
				end
					
				if @collections_clauses.size > 0
					clauses << @collections_clauses.collect{|clause| clause_operator.wrap(clause)}.join(' ')
				end
										
				if @references_clauses.size > 0
					clauses << @references_clauses.collect{|clause| clause_operator.wrap(clause)}.join(' ')
				end
				
				@sql = %{\
( -- Object (#{@builder.back_reference})
	select count(*)
	from 
		#{@query_table_clauses.join(', ') if @query_table_clauses.size > 0}
	where
#{AbstractConverter.make_indent(clauses.join("\n"),2)}
) = 1}								
            end								
		end
	end
end