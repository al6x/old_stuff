module SODB
	module Query
		class ClauseOperator
			attr_accessor :operator
			def initialize operator; @first, @operator = true, operator end
			
			def wrap clause
				return unless clause
				if @first
					@first = false
					return clause
				else
					return @operator+" "+clause
				end
			end
		end
		
		class AbstractConverter
			def initialize builder, parent_id, level
				@builder, @parent_id, @level = builder, parent_id, level
				
				@query_table_clauses, @references_clauses, @collections_clauses, @attributes_clauses = [], [], [], []
				@sql, @counter = '', 1
            end
			
			def get_sql								
				prepare_class_clause
				
				prepare_attributes_clauses
				prepare_collections_clauses
				prepare_references_clauses								

				build_sql
							
				return @sql
			end
			
			protected	
			def self.make_indent sql, n = 1				
				indent = ""
				n.times{indent << "\t"}
				return indent + sql.gsub("\n", "\n"+indent)
            end
			
			def escape_value value; value.is_a?(Numeric) ? value : "'#{value}'" end
			
			def value_to_sql operator, value							
				operator = '!=' if operator == 'not'
				
				if operator == 'in'
					value = "(#{value.collect{|v| escape_value v}.join(', ')})"
        		else 
					value = escape_value value
                end
				
				return "#{operator} #{value}"
            end
			
			def prepare_class_clause
				return unless @builder.class_clause
				
				als, h_als = "l#{@level}_o", "l#{@level}_h"
				@query_table_clauses << "data_objects #{als}"	
				
				@klass_clause = %{\
#{als}.id = #{backlink} and #{als}.class in (
	select #{h_als}.class
	from metadata_hierarchy #{h_als}
	where #{h_als}.parent #{value_to_sql @builder.class_clause.operator, @builder.class_clause.klass}
)}				
            end			
			
			def prepare_attributes_clauses		
				@builder.attributes.each do |meta|
					als = "l#{@level}_a#{@counter}"
					@query_table_clauses << "#{Schema.query_table_name(meta.name)} #{als}"	
										
					@attributes_clauses << "(#{als}.id = #{backlink}"+
						" and #{als}.value #{value_to_sql meta.operator, meta.value})"
					
					@counter += 1
				end			
            end
			
			def prepare_collections_clauses				
				@builder.collections.each do |cb|
					als = "l#{@level}_c#{@counter}"
					@query_table_clauses << "#{Schema.query_table_name(cb.back_reference)} #{als}"	
										
					converter = CollectionConverter.new(cb,	"#{als}.reference", @level+1)										
					@collections_clauses << "#{als}.id = #{backlink} and \n#{converter.get_sql}"
					
					@counter += 1
				end
			end
			
			def prepare_references_clauses				
				@builder.references.each do |ob|
					als = "l#{@level}_r#{@counter}"
					@query_table_clauses << "#{Schema.query_table_name(ob.back_reference)} #{als}"	
										
					converter = ObjectConverter.new(ob,	"#{als}.reference", @level+1)										
					@references_clauses << "#{als}.id = #{backlink} and \n#{converter.get_sql}"
					
					@counter += 1
				end
            end
        end
    end
end