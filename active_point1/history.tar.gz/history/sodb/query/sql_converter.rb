require 'utils/log'
require 'sodb/query/abstract_converter'
require 'sodb/query/object_converter'
require 'sodb/query/collection_converter'

module SODB
	module Query				
		class RootConverter
			def initialize query; @query = query end
			
			def prepare_order_by
				@order_by_tables, @order_by_where, @order_by_clauses = [], [], []
				
				return unless @query.order
				@query.order.each do |attr|
					als = "order_#{attr}"
					@order_by_tables << "#{Schema.query_table_name(attr)} #{als}"
					@order_by_where << "o.id = #{als}.id"
					@order_by_clauses << "#{als}.value"
                end				
            end
				
            def get_sql
				prepare_order_by				
				converter = ObjectConverter.new(@query,	'o.id', 1)
				
				return %{
select o.id
from data_objects o#{", "+@order_by_tables.join(', ') if @order_by_tables.size > 0}	
where 
#{AbstractConverter.make_indent converter.get_sql}\
#{"\n\tand "+@order_by_where.join(' and ') if @order_by_where.size > 0}\
#{"\norder by "+@order_by_clauses.join(', ') if @order_by_clauses.size > 0}}
            end
        end
	
		class SQLConverter		
			include Log
			
			def initialize query_builder; @query_builder = query_builder end
		
			def get_sql
				sql = RootConverter.new(@query_builder).get_sql
				log.debug sql
				return sql
			end
		end
	end
end