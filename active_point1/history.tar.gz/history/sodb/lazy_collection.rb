require 'facets/basicobject'

module SODB
	class LazyCollection < BasicObject
		include PersistentCollection
		undef_method :is_a?
	
		def initialize original = []; @original = original end
			
		def method_missing s, *a, &b
			sodb_load
			@original.send(s,*a,&b)		
		end
	
		def sodb_load
			if @loaded
				return
			else
				@loaded = true
			end
					
			if @original.is_a?(Hash)
				@original.each do |key, value|
					if value.is_a? Reference												
						@original[key] = sodb_object_graph.db.get_by_reference value, sodb_object_graph
					end
				end
			else # Array
				@original.each_with_index do |value, i|
					if value.is_a? Reference												
						@original[i] = sodb_object_graph.db.get_by_reference value, sodb_object_graph
					end
				end
			end
		end
		
		def sodb_lazy_collection?
			true
        end
	end
end