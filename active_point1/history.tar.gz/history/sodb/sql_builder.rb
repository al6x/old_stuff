module SODB
	class SQLBuilder		
		def initialize adapter
			@adapter, @sql = adapter, ""
        end
		
		def self.sql_for_single_object_delete object
			%{
delete from data_objects where id = #{object.sodb_id};
delete from #{Schema.data_table_name object.class.name} where id = #{object.sodb_id};

			}
        end
		
		def self.sql_for_single_collection_delete collection
			%{
delete from data_collections where id = #{collection.sodb_id};

			}
        end
			
		def generate_id_for objects
			sql = objects.inject("") do |sql, o|
				sql << %{
update id set id = id+1;
insert into stored_id values (#{o.object_id}, (select id from id));
				}
			end
			@adapter.execute_batch sql
			
			ids = {}
			@adapter.execute("select object_id, sodb_id from stored_id").each do |row|
				ids[row['object_id'].to_i] = row['sodb_id'].to_i
			end
			return ids
		end
			
		def clear_stored_ids
			@adapter.execute "delete from stored_id"
		end		
		
		def insert_object object, simple_attributes, references, for_insert, generated_ids
			object_id = generated_ids[object.object_id]
			object_table = Schema.data_table_name object.class.name
			
			deferred_insert_into_objects object_id, object.class.name, 1
			
			attributes_tables_sql = ""
			attr_names, simple_values, placeholders, types = [], [], [], []
			simple_attributes.each do |attr_name, attr|
				attr_names << attr_name
				simple_values << attr
				placeholders << '?'
				types << "'#{attr.class.name}'"
				
				# Insert into attributes table
				attributes_tables_sql << %{
insert into #{Schema.query_table_name attr_name}
(id, value)
values (#{object_id}, (select #{attr_name} from #{object_table} where id = #{object_id}));\n
				}				
			end				
			
			ref_names, ref_values, ref_types = [], [], []
			references.each do |ref_name, ref|
				ref_names << ref_name
				ref_id = for_insert.include?(ref) ? generated_ids[ref.object_id] : ref.sodb_id					
				ref_values << ref_id
				types << "'#{Reference.name}'"
				ref_types << "'#{ref.class.name}'"
				
				# Insert into attributes table
				attributes_tables_sql << %{
insert into #{Schema.query_table_name ref_name} 
(id, reference)
values (#{object_id}, #{ref_id});\n
				}					
			end
				
			type_names = attr_names.map{|a| Schema.attribute_type a}				
			ref_type_names = ref_names.map{|a| Schema.attribute_type a}
			ref_object_type_names = ref_names.map{|a| Schema.reference_type a}

			# id, class and version columns								
			id_class_version_name = ['id', 'class', 'version']
			id_class_version_value = [object_id, "'#{object.class.name}'", '1']
				
			sql = %{
insert into #{object_table}
(#{id_class_version_name.concat(attr_names).concat(ref_names).concat(type_names).
			concat(ref_type_names).concat(ref_object_type_names).join(',')})
values
(#{id_class_version_value.concat(placeholders).concat(ref_values).concat(types).
			concat(ref_types).join(',')});\n
			}
				
			@adapter.execute sql, simple_values		
			@adapter.execute_batch attributes_tables_sql
		end
		
		def update_object object, simple_attributes, references, for_insert, generated_ids
			object_table = Schema.data_table_name object.class.name
			
			deferred_update_object_version object.sodb_id, (object.sodb_version+1)
			
			attributes_tables_sql = ""
			simple_values, set_clause = [], []
			simple_attributes.each do |attr_name, attr|
				set_clause << "#{attr_name} = ?"
				set_clause << "#{Schema.attribute_type attr_name} = '#{attr.class.name}'"
				simple_values << attr		
				
				attributes_tables_sql << %{
update #{Schema.query_table_name attr_name}
set value = (select #{attr_name} from #{object_table} where id = #{object.sodb_id})
where id = #{object.sodb_id};\n
				}			
			end
				
			references.each do |ref_name, ref|					
				ref_id = for_insert.include?(ref) ? generated_ids[ref.object_id] : ref.sodb_id					
				set_clause << "#{ref_name} = #{ref_id}"
				set_clause << "#{Schema.attribute_type ref_name} = '#{Reference.name}'"
				set_clause << "#{Schema.reference_type ref_name} = '#{ref.class.name}'"				
				
				# Update attributes table
				attributes_tables_sql << %{
update #{Schema.query_table_name ref_name}
set value = #{ref_id}
where id = #{object.sodb_id};\n
				}					
			end			
			
			# increase object version
			set_clause << "version = version+1"
				
			sql = %{
update #{object_table}
set #{set_clause.join(',')}
where id = #{object.sodb_id};\n
			}				
			@adapter.execute sql, simple_values		
			@adapter.execute_batch attributes_tables_sql			
		end
		
		def insert_collection sodb_id, helper, for_insert, generated_ids
			# Insert simple properties
			sql = %{
insert into data_collections (id, version, key, type_key, value, type_value)
values (#{sodb_id}, 1, ?, ?, ?, ?);\n
			}			
			@adapter.prepare(sql) do |stmt|				
				helper.simple_attributes.each do |name, value|
					stmt.execute [name, name.class.name, value, value.class.name]					
				end
			end
			
			# Insert references
			sql = %{
insert into data_collections (id, version, key, type_key, value, type_value, rtype_value)
values (#{sodb_id}, 1, ?, ?, ?, ?, ?);\n
			}			
			@adapter.prepare(sql) do |stmt|
				helper.references.each do |name, ref|
					stmt.execute [
						name,
						name.class.name,
						for_insert.include?(ref) ? generated_ids[ref.object_id] : ref.sodb_id,
						Reference.name,
						ref.class.name
					]										
				end
			end							
		end
		
		def delete_old_collections collections
			return if collections.size == 0
			@adapter.execute "delete from data_collections where id in (#{collections.collect{|c| c.sodb_id}.join(', ')});\n"
        end
		
		def add_to_deffered sql
			@sql << sql + "\n"
        end
		
		def execute_deferred
			@adapter.execute_batch @sql
			@sql = ""
        end
			
		private
		def deferred_insert_into_objects id, klass, version
			add_to_deffered "insert into data_objects values (#{id}, '#{klass}', #{version});\n" 				
		end
		
		def deferred_update_object_version id, version
			add_to_deffered %{
update data_objects
set version = #{version}
				where id = #{id};\n
			}
		end
	end
end