module SODB
	module ScriptHelper
		def load_script(script)		
			@loaded_scripts ||= {}
			unless @loaded_scripts.include? script				
				@loaded_scripts[script] = IO.read("#{File.dirname(__FILE__)}/#{script}")
            end			
			return @loaded_scripts[script]
		end
    end
end