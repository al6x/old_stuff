require 'sqlite3'

c = nil
while line = gets.chomp
	if line =~ /.db/
		puts "connected to '#{line}'"
		c = SQLite3::Database.new(line.to_s)
	else
		begin
			puts c.execute(line) if c
		rescue Exception => e
			puts e
		end
	end
end