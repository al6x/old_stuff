require 'utils/log'

require 'sodb/persistence'
require 'sodb/adapter'
require 'sodb/query/query'
require 'sodb/schema'
require 'sodb/marshal'


module SODB
	class NotFound < RuntimeError; end
	class Db
		include Log
		attr_reader :adapter
		
		def initialize name = '', dir = ''
			# Initialization
			@adapter = Adapter.new name, dir
			@schema = Schema.new @adapter
			@query = Query::Query.new @adapter
			@marshal = Marshal.new @adapter, @schema
			
			# Check scheme
			@schema.check_and_set_up_scheme_if_needed			
        end
		
		def cache= value; log.warn 'not implemented' end
		
		def clear 
			@schema.drop_scheme
			@schema.create_scheme
        end
		
		def << object
			raise "Object should be of type #{Persistent}" unless object.is_a? Persistent
			@marshal.save_or_update object
        end 
		
		def [] id; 
			raise "Id cannot be nil" unless id
			@marshal.get_by_id id.to_i
        end
		
		# TODO change if block -> call it sequently per each returned item
		def list *params, &block		
			result = []
			@query.get(*params, &block).each do	|row|		
				result << self[row['id']]
            end
			return result
        end
		
		def single *params, &block
			result = list(*params, &block)
			raise NotFound, "", caller if result.empty?
			raise "Found more than one Objects!" if result.size > 1
			return result[0]
        end
		
		def has? *params, &block
			list(*params, &block).size > 0 ? true : false
        end
		
#		def count *params, &block
#			TODO the same as get, but instead returns count of found objects
#        end
		
		def include? id
			raise "Id cannot be nil" unless id
			begin 
				self[id]
				return true
			rescue Exception
				return false
            end
        end
				
		# TODO change name to delete_object, and add another method 'delete' that accept Query and deletes 
        # all founded objects
		def delete object_or_id, tree = false
			raise "It cannot be nil" unless object_or_id
			begin
				object_or_id = self[object_or_id] unless object_or_id.is_a? Persistent
			rescue Exception
				return
			end
			@marshal.delete object_or_id, tree
        end
		
		def delete_all object
			delete object, true
        end
		
		def to_s
			"Database file: #{@adapter.filename}"
        end				
    end		
end