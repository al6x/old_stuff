require 'sodb/schema'
require 'sodb/object_graph'
require 'sodb/object_builder'
require 'sodb/sql_builder'

module SODB				
	class Marshal							
		def initialize adapter, schema; 
			@adapter, @schema = adapter, schema
        end
		
		def save_or_update object			
			helper = LazyGraphHelper.new(object)
			helper.examine			
			
			begin
				@adapter.transaction{_save_or_update helper}
			rescue Exception				
				update_scheme helper.objects
				@adapter.transaction{_save_or_update helper}
			end

			#			# TEMPRORARY SOLUTION, FOR DEBUG ONLY
			#			update_scheme helper.objects
			#			@adapter.transaction{_save_or_update helper}
		end
				
		def get_by_id id																
			o = ObjectBuilder.new(@adapter).build_by_id id			
			og = ObjectGraph.new self				
			o.sodb_object_graph = og			
			og.objects[id] = o
			return o				
		end				

		def get_by_reference ref, object_graph
			return object_graph.objects[ref.sodb_id] if object_graph.objects.include? ref.sodb_id

			o = ObjectBuilder.new(@adapter).build_by_id_and_class ref.sodb_id, ref.sodb_class			
			o.sodb_object_graph = object_graph
			object_graph.objects[ref.sodb_id] = o
			return o
        end
		
		def delete object, tree				
			# TODO query tables are not deleted
			sql = SQLBuilder.sql_for_single_object_delete object
			if tree
				helper = GraphHelper.new(object)
				helper.examine
				helper.objects.each do |o|
					next if o == object
					sql << SQLBuilder.sql_for_single_object_delete(o)
					# TODO collections are not deleted.
                end
				(helper.hashes + helper.arrays).each do |c|
					sql << SQLBuilder.sql_for_single_collection_delete(c)
                end
            end
			
			@adapter.execute_batch sql
        end
		
		private			
		def sorting_for_insert_and_update helper
			o_for_insert, o_for_update = [], []			
			helper.objects.each do |o|
				if o.sodb_id == nil
					o_for_insert << o
				elsif o.sodb_updated
					o_for_update << o
				end
			end		
			
			# Sorting collections for insert and update
			a_for_insert, a_for_update = [], []
			helper.arrays.each do |a|
				if a.respond_to?(:sodb_id) && a.sodb_id != nil
					a_for_update << a
				else
					a_for_insert << a
                end
            end
			
			h_for_insert, h_for_update = [], []
			helper.hashes.each do |h|
				if h.respond_to?(:sodb_id) && h.sodb_id != nil
					h_for_update << h
				else 
					h_for_insert << h
                end
            end
			
			return o_for_insert, o_for_update, a_for_insert, a_for_update, h_for_insert, h_for_update
		end
		
		def _save_or_update helper
			# Sorting objects for insert and update
			o_for_insert, o_for_update, a_for_insert, a_for_update, 
				h_for_insert, h_for_update = sorting_for_insert_and_update helper
			for_insert = [].concat(o_for_insert).concat(a_for_insert).concat(h_for_insert)

			# Check for obsolete objects		
			check_for_obsolete_objects o_for_update, a_for_update, h_for_update		
				
			# Generating ids for inserted objects and collections
			builder = SQLBuilder.new @adapter
			generated_ids = builder.generate_id_for(
				[].concat(o_for_insert).concat(helper.arrays).concat(helper.hashes)
			)
				
			# Inserting objects
			o_for_insert.each do |o|				
				h = LazyObjectHelper.new(o)		
				h.examine
				builder.insert_object o, h.simple_attributes, h.references, for_insert, generated_ids
			end						
				
			# Update objects
			o_for_update.each do |o|
				h = LazyObjectHelper.new(o)
				h.examine
				builder.update_object o, h.simple_attributes, h.references, for_insert, generated_ids	
			end
			
			# Deleting old arrays and hashes
			builder.delete_old_collections [].concat(a_for_update).concat(h_for_update)
            
			# Inserting arrays			
			a_for_insert.each do |a|
				sodb_id = generated_ids[a.object_id]
				hp = ArrayHelper.new a
				hp.examine
				builder.insert_collection sodb_id, hp, for_insert, generated_ids
            end			
			
			# Updating arrays
			a_for_update.each do |a|
				sodb_id = a.sodb_id
				hp = ArrayHelper.new a
				hp.examine
				builder.insert_collection sodb_id, hp, for_insert, generated_ids
            end			
			
			# Inserting hashes
			h_for_insert.each do |h|
				sodb_id = generated_ids[h.object_id]		
				hp = HashHelper.new h
				hp.examine
				builder.insert_collection sodb_id, hp, for_insert, generated_ids
            end			
			
			# Updating hashes
			h_for_update.each do |h|
				sodb_id = h.sodb_id
				hp = HashHelper.new h
				hp.examine
				builder.insert_collection sodb_id, hp, for_insert, generated_ids
            end			
			
			# Executing some post-SQL
			builder.execute_deferred
			
			# Extending Arrays and Hashes to Persitable form
			[].concat(a_for_insert).concat(h_for_insert).each {|c| c.extend PersistentCollection}
				
			# Assign to in-memory objects generated ids			
			[].concat(o_for_insert).concat(a_for_insert).concat(h_for_insert).each do
				|o| o.sodb_id = generated_ids[o.object_id]
            end
				
			# Set managed properties on inserted objects
			managed = o_for_update.find{|o| o.sodb_object_graph}				
			og = managed ? managed.sodb_object_graph : ObjectGraph.new(self)
			[].concat(o_for_insert).concat(a_for_insert).concat(h_for_insert).each do |o| 
				o.sodb_object_graph = og
				og.objects[o.sodb_id] = o				
            end					
				
			# Clear temporary ids
			builder.clear_stored_ids 			

			# Increase objects version and clear 'updated' flag
			o_for_insert.each do |o|
				o.sodb_updated = false
				o.sodb_version = 1
            end
			
			o_for_update.each do|o| 
				o.sodb_updated = false
				o.sodb_version += 1
            end
			
			[].concat(a_for_insert).concat(h_for_insert).each{|c| 
				c.sodb_version = 1				
			}
			[].concat(a_for_update).concat(h_for_update).each{|c| 
				c.sodb_version += 1				
            }
		end				

		def check_for_obsolete_objects o_for_update, a_for_update, h_for_update					
			collections = [].concat(a_for_update).concat(h_for_update)
			return if (o_for_update.size == 0) && (collections.size == 0)
			
			versions = @adapter.execute %{
select id, version 
from data_objects 
where id in (#{o_for_update.collect{|o| o.sodb_id}.join(', ')})
union
select distinct id, version
from data_collections
where id in (#{collections.collect{|o| o.sodb_id}.join(', ')})
			}
			id_to_version = {}
			versions.each do |row|
				id_to_version[row['id'].to_i] = row['version'].to_i
            end
			
			obsolete = []
			
			
			collections = []# TODO Error! I've disabled obsolete check fore collections. 
            #This is a temprorary solution, because current SODB doesn't works correctly with arrays
			
			
			[].concat(o_for_update).concat(collections).each do |o|
				if o.sodb_version != id_to_version[o.sodb_id]
					obsolete << o.sodb_id 
                end
            end			
			
			unless obsolete.empty?
				raise "Can't update obsolete objects (#{obsolete.join(', ')})" 
            end
        end
			
		# Collect attributes and class names
		def update_scheme objects
			klasses = {}
			objects.each do |o|				
				klasses[o.class] = o.class.sodb_persistent_properties unless klasses.include? o.class
			end
			@schema.update_scheme klasses
		end						
	end
end