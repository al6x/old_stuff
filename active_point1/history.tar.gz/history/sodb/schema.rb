module SODB
	class Schema
		include ScriptHelper			
		
		def initialize adapter; @adapter = adapter end
		
		def check_and_set_up_scheme_if_needed
			unless Set.new(@adapter.tables).include?('sodb')
				drop_scheme
				create_scheme
            end
        end
		
		def create_scheme
			@adapter.transaction{|a| a.execute_batch load_script('sql/create_scheme.sql')}
        end
		
		def drop_scheme
			@adapter.transaction do |a| 
				@adapter.tables.each {|table| a.execute "drop table #{table}"}
            end
        end
		
		def update_scheme klasses
			# Find out missing objets tables and columns
			existing_tables = @adapter.tables			
			
			missed_klasses = {}			
			klasses.each do |klass, t_attrs|
				missed_klasses[klass] = t_attrs unless existing_tables.include? klass.name
            end													
			
			# Create missed object tables
			sql = ""
			missed_klasses.each do |klass, t_attrs|
				columns = t_attrs.inject([]) do |out, attr| 
					out << attr; 
					out << Schema.attribute_type(attr)
					out << Schema.reference_type(attr)
				end
				columns = ['id', 'class', 'version'].concat(columns)
				sql << %{
create table if not exists #{Schema.data_table_name klass.name}(#{columns.join(",")});\n
				}
			end
			@adapter.transaction {@adapter.execute_batch sql} unless sql.empty?
			
			# Create missed columns in object tables							
			classes_with_missed_columns = {}
			klasses.each do |klass, t_attrs|
				table_name = Schema.data_table_name(klass.name)
				missed_columns = Set.new(t_attrs).subtract(@adapter.columns_for_table(table_name))
				classes_with_missed_columns[klass] = missed_columns unless missed_columns.empty?
            end
			
			sql = ""
			classes_with_missed_columns.each do |klass, attrs|
				table = Schema.data_table_name(klass.name)
				attrs.each do |attr|
					sql << "alter table #{table} add #{attr}; \n"
					sql << "alter table #{table} add #{Schema.attribute_type(attr)}; \n"
					sql << "alter table #{table} add #{Schema.reference_type(attr)}; \n"															
				end
            end			
			@adapter.transaction {@adapter.execute_batch sql} unless sql.empty?
			
			# Fill in hierarchy table
			sql = ''
			missed_klasses.each do |klass, t_attrs|
				sql << "delete from metadata_hierarchy where class = '#{klass.name}';\n"
				klass.ancestors.each do |parent|
					next if [Object, Kernel, ComplexType, Utils::OpenConstructor, Persistent].include?(parent)
					sql << "insert into metadata_hierarchy (class, parent) values ('#{klass.name}', '#{parent.name}');\n"
                end
            end
			@adapter.transaction {@adapter.execute_batch sql} unless sql.empty?
			
			# Fill in attributes table	
			sql = ''
			missed_klasses.merge(classes_with_missed_columns).each do |klass, attrs|
				attrs.each do |attr|
					sql << %{
delete from metadata_attributes where class = '#{klass.name}' and attribute = '#{attr}';
insert into metadata_attributes (class, attribute) values ('#{klass.name}', '#{attr}');\n
					}
				end
            end
			@adapter.transaction {@adapter.execute_batch sql} unless sql.empty?	
			
			# Create tables for atributes			
			sql = ''
			missed_klasses.merge(classes_with_missed_columns).each do |klass, attrs|
				attrs.each do |attr|
					sql << 
						"create table if not exists #{Schema.query_table_name attr}(id, value, reference);\n"
				end
            end			
			@adapter.transaction {@adapter.execute_batch sql} unless sql.empty?			
		end
				
		# Chashe these functions
		def self.data_table_name class_name; "data_"+class_name.gsub("::", '__') end		
		def self.query_table_name attr_name; "query_#{attr_name}" end
		def self.attribute_type attr_name; "type_#{attr_name}" end
		def self.reference_type attr_name; "rtype_#{attr_name}" end
	end
end