require 'sodb/db'
Persistent = SODB::Persistent
NotFound = SODB::NotFound
Db = SODB::Db