require 'spec'
require 'sodb'

module SODB			
	describe 'Adapter' do		
		it 'In memory mode' do
			a1 = SODB::Adapter.new ""
			a1.execute "create table test(a)"
			a1.tables.should include("test")
			
			a2 = SODB::Adapter.new ""
			a2.tables.should_not include('test')
        end		
		
		it 'File database' do
			Adapter.delete('file1')
			a1 = SODB::Adapter.new "file1"
			a1.execute "create table test(a)"
			a1.tables.should include("test")
			a1.close
			
			a2 = SODB::Adapter.new "file1"
			a2.tables.should include('test')
			a2.close
			Adapter.delete('file1')
        end
	end				
end