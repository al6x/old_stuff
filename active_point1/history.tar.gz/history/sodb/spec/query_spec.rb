require 'spec'
require 'sodb'

module SODB
	module QuerySpec
		# Domain classes for Forum test
		class Comment
			include SODB::Persistent
			attr_accessor :text, :user
        end
		
		class User
			include SODB::Persistent
			attr_accessor :name, :topics
        end
		
		class Topic
			include SODB::Persistent
			attr_accessor :name, :text, :user, :comments
        end
		
		# Domain classes for Inheritance test
		class Parent
			include SODB::Persistent
			attr_accessor :name
        end
		
		class Child < Parent
			include SODB::Persistent
			attr_accessor :body
        end
		
		# Domain classes for Collection's test
		class ArrayTest
			include SODB::Persistent
			attr_accessor :name, :array
        end
	
		describe 'Querying' do
			before :all do			
				@db = SODB::Db.new
				@db.clear
				
				# Forum test
				alexey = User.new.set :name => 'Alexey'
				@db << alexey
				sergey = User.new.set :name => 'Sergey'
				@db << sergey
				anna = User.new.set :name => 'Anna'
				@db << anna
				
				about_terminator = Topic.new.set :name => "Terminator", :text => "Cool film", :user => alexey
				about_terminator.comments = [
					Comment.new.set(:text => 'Yes, you are right!', :user => sergey),
					Comment.new.set(:text => 'Too cruel', :user => anna),
					Comment.new.set(:text => 'The best ever filmed!', :user => alexey),
                ]		
				@db << about_terminator
				
				about_bolein = Topic.new.set :name => 'Last from Bolein', :text => "So lovely film", :user => anna
				about_bolein.comments = [
					Comment.new.set(:text => 'yes', :user => anna),
					Comment.new.set(:text => 'stupid film', :user => alexey),
					Comment.new.set(:text => 'bullshit', :user => sergey)
                ]
				@db << about_bolein 
				
				about_fightclub = Topic.new.set :name => 'Fightclub', :text => "Cool!", :user => sergey
				about_fightclub.comments = [
					Comment.new.set(:text => 'yes', :user => alexey),
					Comment.new.set(:text => 'yes', :user => anna)
                ]
				@db << about_fightclub
				
				# Array test
				@db << ArrayTest.new.set(:name => '[one]', :array => ['one'])
				@db << ArrayTest.new.set(:name => '[one, two]', :array => ['one', 'two'])
				
				# Inheritance test
				@db << Parent.new.set(:name => 'parent')
				@db << Child.new.set(:name => 'child')
			end		
			after :all do; @db.clear end
					
			it 'simple search' do
				@db.list(Child).size.should == 1
			end
											
			it 'search with inheritance' do
				@db.list(Parent).size.should == 2
			end
														
			it 'simple native search' do
				list = @db.list(Topic){|c|
					c.name == 'Terminator'
				}
				list.size.should == 1
				list.first.text.should == 'Cool film'
			end
													
			it 'Collection with specified value and aggregate functions' do
				all = @db.list{|array_test|
					array_test.array(:all){|item|
						item == 'one'
					}
				}																
										
				any = @db.list{|array_test|
					array_test.array(:any){|item|
						item == 'one'
					}
				}
			
				size = @db.list{|array_test|
					array_test.array(:size => '= 1'){|item|
						item == 'one'
					}
				}
							
				all.size.should == 1
				any.size.should == 2
				size.size.should == 2
			end
									
			it 'Collections with specified reference and aggregate functions' do
				list = @db.list{|topic|
					topic.comments(:all){|comment|
						comment.text == 'yes'
					}
				}
				list.size.should == 1
				list.first.name.should == 'Fightclub'
										
				list = @db.list{|topic|
					topic.comments(:size => '= 1'){|comment|
						comment.text == 'yes'
					}
				}
				list.size.should == 1
				list.first.name.should == 'Last from Bolein'							
			end
									
			it 'Collections with specified element class' do
				list = @db.list{|topic|
					topic.comments(:all){|comment| # |key, value| for Arrays and Hashes
						comment.klass == Comment
					}
				}
				list.size.should == 3
			end		
						
			it 'complex native search with reference' do
				list = @db.list(Topic){|topic|
					topic.user{|user|
						user.name == 'Alexey'
					}
				}
							
				list.size.should == 1
				list.first.name.should == 'Terminator'
			end
						
			it 'Search with reference and attribute' do
				list = @db.list{|comment|
					comment.user{|user|
						user.name == 'Alexey'
					}
					comment.text == 'stupid film'
				}
				list.size.should == 1
				list.first.text.should == 'stupid film'
			end												
		end
	end
end