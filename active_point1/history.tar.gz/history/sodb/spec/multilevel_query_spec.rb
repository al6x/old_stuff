require 'spec'
require 'sodb'

module SODB
	module MultilevelQuerySpec		
		class Universal
			include SODB::Persistent
			attr_accessor :attribute, :collection, :reference
        end
		
		describe 'Querying' do
			before :all do			
				@db = SODB::Db.new
				@db.clear
				
				# Multilevel reference								
				l4 = Universal.new.set :attribute => 'R4'
				l3 = Universal.new.set :attribute => 'R3', :reference => l4
				l2 = Universal.new.set :attribute => 'R2', :reference => l3
				l1 = Universal.new.set :attribute => 'R1', :reference => l2
				@db << l1
				
				noise4 = Universal.new.set :attribute => 'Noise 4'
				noise3 = Universal.new.set :attribute => 'Noise 3', :reference => noise4
				noise2 = Universal.new.set :attribute => 'Noise 2', :reference => noise3
				noise1 = Universal.new.set :attribute => 'Noise 1', :reference => noise2
				@db << noise1
												
				# Multileve references and arrays
				l4 = Universal.new.set :attribute => 'RA4'
				l3 = Universal.new.set :attribute => 'RA3', :collection => [l4, 'ra4']
				l2 = Universal.new.set :attribute => 'RA2', :collection => [l3]
				l1 = Universal.new.set :attribute => 'RA1', :collection => [l2,]
				@db << l1
				
				noise4 = Universal.new.set :attribute => 'Noise 4'
				noise3 = Universal.new.set :attribute => 'Noise 3', :collection => [noise4, 'noise 4']
				noise2 = Universal.new.set :attribute => 'Noise 2', :collection => [noise3]
				noise1 = Universal.new.set :attribute => 'Noise 1', :collection => [noise2]
				@db << noise1
			end		
			after :all do; @db.clear end
					
			it 'Multilevel reference' do
				list = @db.list{|l1|
					l1.reference{|l2|
						l2.reference{|l3|
							l3.reference{|l4|
								l4.attribute == 'R4'
                            }
                        }
                    }
                }
				list.size.should == 1
				list[0].attribute.should == 'R1'
			end			

			it 'Multileve references and arrays' do
				list = @db.list{|ra1|
					ra1.collection(:any){|ra2|
						ra2.collection(:any){|ra3|							
							ra3.collection(:any){|ra4|
								ra4.attribute == 'RA4'
                            }
                        }						
                    }
                }
				
				list.size.should == 1
				list[0].attribute.should == 'RA1'
				
				list = @db.list{|ra1|
					ra1.collection(:any){|ra2|
						ra2.collection(:any){|ra3|							
							ra3.collection(:any){|ra4|
								ra4 == 'ra4'
                            }
                        }						
                    }
                }
				
				list.size.should == 1
				list[0].attribute.should == 'RA1'
            end
		end
	end
end