require 'spec'
require 'sodb'

module SODB		
	module OrderSpec
	class Order
		include SODB::Persistent
		attr_accessor :a, :b
    end
	
	class Noise
		include SODB::Persistent
		attr_accessor :a, :b
    end
	
	describe 'Order' do
		before :all do
			@db = SODB::Db.new()			
			@db.clear						
			
			@db <<  Order.new.set(:a => 'a2', :b => 'b3')
			@db <<  Order.new.set(:a => 'a2', :b => 'b2')
			@db <<  Order.new.set(:a => 'a1', :b => 'b1')
			
			@db <<  Noise.new.set(:a => 'a3', :b => 'b4')
		end		
		after :all do; @db.clear end
		
		it 'order with single attribute' do
			list = @db.list(:class => Order, :order => [:a])
			list.first.a.should == 'a1'
			list.last.a.should == 'a2'
        end
		
		it 'order with multiple attributes' do
			list = @db.list(:class => Order, :order => [:a, :b])
			list.first.b.should == 'b1'
			list.last.b.should == 'b3'
        end
	end
	end
end