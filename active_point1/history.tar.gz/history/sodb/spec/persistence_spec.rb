require 'spec'
require 'sodb'

module SODB
	module PersistenceSpec
		describe 'Complex object' do
			it 'parent should contains all his direct and indirect childs' do
				class A1
					include SODB::Persistent
					attr_accessor :a
                end
				
				class B1 < A1
					include SODB::Persistent
					attr_accessor :b
                end
				
				class C1 < B1
					include SODB::Persistent
					attr_accessor :c
                end
				
				descendants = A1.send('sodb_descendants')
				
				descendants.should include(B1)
				descendants.should include(C1)				
            end
			
			it "child should contains all his parents properties" do
				class A2
					include SODB::Persistent
					attr_accessor :a
                end
				
				class B2 < A2
					include SODB::Persistent
					attr_accessor :b
                end
				
				class C2 < B2
					include SODB::Persistent
					attr_accessor :c
                end
				
				C2.sodb_persistent_properties.should include('a')
				C2.sodb_persistent_properties.should include('b')
            end
			
			it 'child should update properties if parents where updated' do
				class A3
					include SODB::Persistent
					attr_accessor :a
                end
				
				class B3 < A3
					include SODB::Persistent
					attr_accessor :b
                end
				
				class C3 < B3
					include SODB::Persistent
					attr_accessor :c
                end
				
				class A3
					attr_accessor :a3
                end
				
				C3.sodb_persistent_properties.should include('a3')
            end
		end
	end
end