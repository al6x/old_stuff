require 'spec'
require 'sodb'
require 'utils/path'

include SODB
module SODB::Exceptions	
	describe 'Base operations' do
		before :all do
			@db = Db.new	
			@db.clear
		end		
		after :all do; @db.clear end
		
		class Simple
			include Persistent
			attr_accessor :name, :value
        end
		
		it "Should correct setup sodb_version on Arrays and Hashes" do
			s = Simple.new.set(:name => 'empty', :value => [])
			@db << s
			s.value.sodb_version.should == 1
			s.value << 2
			@db << s
			s.value.sodb_version.should == 2
			
			s = Simple.new.set(:name => 'not empty', :value => [1])
			@db << s
			s.value.sodb_version.should == 1
			s.value << 2
			@db << s
			s.value.sodb_version.should == 2
        end
		
		class WithInitialization
			include Persistent
			attr_accessor :simple, :array, :hash
			
			def initialize
				@simple, @array, @hash = 1, [2], {3 => 3}
            end
        end
		
		it "Should allow initialize variables" do
			o = WithInitialization.new
			@db << o
			[o.simple, o.array, o.hash].should == [1, [2], {3 => 3}]
			o = @db.single(WithInitialization){|o| o.simple == 1}
			[o.simple, o.array, o.hash].should == [1, [2], {3 => 3}]
			
			o = WithInitialization.new
			o.simple = 2
			o.array << 4
			o.hash[4] = 4
			@db << o
			o = @db.single(WithInitialization){|o| o.simple == 2}
			[o.simple, o.array, o.hash].should == [2, [2, 4], {3 => 3, 4 => 4}]
        end				
		
		it "Should correct works with 'nil' values" do
			s = Simple.new
			@db << s
			@db.single(Simple){|o| o.value == nil}
			
			s = Simple.new.set(:value => [1, 2, nil])
			@db << s
			@db.single(Simple) do |o|
				o.value(:any){|v| v == nil}
            end
        end
		
		it "Should not raise 'table not exists' exception, if querying attribute isn't yet defined" do
			lambda{
				@db.single(Data){|d| d.not_existing_attribute == 'path'} 
            }.should raise_error(NotFound)
        end
				
		it "Should correct update object after retrieval" do
			s = Simple.new.set :value => 'value'
			@db << s
			s = @db.single{|o| o.value == 'value'}
			s.value = 'value2'
			@db << s # Should not raise exception
        end
				
		it "Should raise exception if try to save Unknown object type" do
			# Save
			s = Simple.new.set :value => Utils::Path.new('/')
			lambda {@db << s}.should raise_error(UnknownObjectType)
			
			# Update
			s = Simple.new.set :value => '/'
			@db << s
			s.value = Utils::Path.new('/')
			lambda {@db << s}.should raise_error(UnknownObjectType)
			
			# For Array
			# Save
			s = Simple.new.set :value => [Utils::Path.new('/')]
			lambda {@db << s}.should raise_error(UnknownObjectType)
			
			# Update
			s = Simple.new.set :value => ['/']
			@db << s
			s.value[0] = Utils::Path.new('/')
			lambda {@db << s}.should raise_error(UnknownObjectType)
			
			# For Hash
			# Save
			s = Simple.new.set :value => {1 => Utils::Path.new('/')}
			lambda {@db << s}.should raise_error(UnknownObjectType)
			
			# Update
			s = Simple.new.set :value => {0 => '/'}
			@db << s
			s.value[0] = Utils::Path.new('/')
			lambda {@db << s}.should raise_error(UnknownObjectType)
        end
	end
end