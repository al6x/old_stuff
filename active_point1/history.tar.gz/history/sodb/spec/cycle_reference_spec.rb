require 'spec'
require 'sodb'

module SODB	
	module ReferenceCycleSpec
		class SimpleReference
			include SODB::Persistent		
			attr_accessor :name, :reference
		end
		
		describe 'Reference cycle' do
			before :all do			
				@db = SODB::Db.new
				@db.clear			
			end		
			after :all do; 	@db.clear end
		
			it 'save & read simple cycle' do
				a = SimpleReference.new.set :name => 'A'
				b = SimpleReference.new.set :name => 'B'
			
				a.reference = b; b.reference = a
			
				@db <<  a
			
				a = @db[a.sodb_id]
				b = a.reference
			
				a.name.should == 'A'
				b.name.should == 'B'
			
				b.reference.should == a
			end
		
			it 'save & read complex cycle' do
				a = SimpleReference.new.set :name => 'A'
				b = SimpleReference.new.set :name => 'B'
				c = SimpleReference.new.set :name => 'C'
			
				a.reference = b; b.reference = c; c.reference = a
			
				@db <<  a
			
#				a = @db.first(:name => 'A')
				a = @db[a.sodb_id]			
				b = a.reference
				c = b.reference
			
				a.name.should == 'A'
				b.name.should == 'B'
				c.name.should == 'C'
			
				c.reference.should == a
			end
		end
	end
end