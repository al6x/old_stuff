require 'spec'
require 'sodb'

module SODB			
	module ObjectGraphSpec
		class SO
			include SODB::Persistent		
			attr_accessor :name, :value, :value2, :value3
			def to_s; name end
		end
		
		describe 'ObjectGraph' do
			it "should return all objects" do
				o1 = SO.new.set :name => 'o1'
				o2 = SO.new.set :name => 'o2', :value => o1
				o1.value = o2
				o3 = SO.new.set(:name => 'o3')
				o1.value2 = [o3]
				o4 = SO.new.set(:name => 'o4')
				o1.value3 =[[[o4]]]
				
				h = GraphHelper.new(o1)
				h.examine				
				
				h.objects.should include(o1)
				h.objects.should include(o2)
				h.objects.should include(o3)
				h.objects.should include(o4)
				h.objects.size.should == 4
				
				h.arrays.size.should == 4
            end
			
			it "should return only loaded objects (lazy)" do
				o1 = SO.new.set :name => 'o1'
				o2 = SO.new.set :name => 'o2', :value => o1
				o1.value = o2				
				o1.value2 = [Reference.new(1, 'stub')]
				o4 = SO.new.set(:name => 'o3')
				o1.value3 =[[[o4]]]				
				
				h = LazyGraphHelper.new(o1)
				h.examine
				h.objects.should include(o1)
				h.objects.should include(o2)
				h.objects.should include(o4)
				h.objects.size.should == 3
            end
			
			it "should return only first-level arrays for objects" do
				o1 = SO.new
				a1 = ['a']
				a2 = [a1]
				a1 << a2
				o1.value = a2
					
				h = LazyObjectHelper.new(o1)
				h.examine
				h.references['value'].should == a2
				h.references.size.should == 1
            end
			
			it "should correct work with cycles" do
				o1 = SO.new
				a1 = ['a1']
				a2 = ['a2', a1]
				a1 << a2
				o1.value = a2
					
				h = GraphHelper.new(o1)
				h.examine
            end
		end		
	end
end