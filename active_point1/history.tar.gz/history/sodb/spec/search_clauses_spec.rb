require 'spec'
require 'sodb'

module SODB	
	class Simple
		include SODB::Persistent
		attr_accessor :a, :b, :int		
    end
	
	describe 'Query clauses' do
		before :all do
			@db = SODB::Db.new()			
			@db.clear
			
			@db <<  Simple.new.set(:a => 'a1', :b => 'b1', :int => 1)
			@db <<  Simple.new.set(:a => 'a2', :b => 'b2', :int => 2)
			@db <<  Simple.new.set(:a => 'a3', :b => 'b3', :int => 3)
		end		
		after :all do; @db.clear end
		
		#		it 'respond_to?' do
		#			# I doubt i ever need this.
		#			@db.list{|o| o.respond_to? 'a'}.size.should == 3
		#        end
		
		it '==' do			
			@db.list{|o| o.a == 'a1'}.size.should == 1
        end
		
		it 'in' do
			list = @db.list{|o|
				o.a.in ['a1', 'a2']
			}
			list.size.should == 2
			list.first.a.should == 'a1'
			list.last.a.should == 'a2'
		end
		
		it '!=' do			
			@db.list{|o| o.a.not 'a1'}.size.should == 2
        end
		
		it '>' do			
			@db.list{|o| o.int > 1 }.size.should == 2
        end
		
		it '<' do			
			@db.list{|o| o.int < 2 }.size.should == 1
        end
		
		it '>=' do			
			@db.list{|o| o.int >= 1}.size.should == 3
        end
		
		it '<=' do			
			@db.list{|o| o.int <= 1 }.size.should == 1
        end
		
#		it 'or' do			
#			# I doubt i ever need this.
#			@db.list{|o|
#				OR{
#					o.a == 'a1'
#					o.a == 'a2'
#                }
#			}.size.should == 2
#        end
		
#		it 'and' do			
#			# I doubt i ever need this.
#			@db.list{|o| 
#				AND{
#					o.name = 'a1'
#					o.int = 1
#                }				
#			}.size.should == 1
#        end
		
#		it 'not' do			
#			# I doubt i ever need this.
#			@db.list{|o| 
#				NOT{
#					o.name = 'a1'
#                }				
#			}.size.should == 2
#        end
	end
end