require 'spec'
require 'sodb'
require 'utils/log'

module SODB			
	module ArrayAndHashSpec
				
		class SimpleCollection
			include SODB::Persistent		
			attr_accessor :name, :collection
		end
		
		describe 'Array and Hash' do
			before :all do
				@db = SODB::Db.new
				@db.clear
			end		
			after :all do; @db.clear end
		
			it 'array save & read' do
				o = SimpleCollection.new.set :name => 'array'
				o.collection = ['a', 'b', 'c']
				@db <<  o
			
				o = @db[o.sodb_id]
				o.name.should == 'array'
				o.collection.should == ['a', 'b', 'c']
			end
			
			it 'works with empty arrays' do
				o = SimpleCollection.new.set :name => 'empty array'
				o.collection = []
				@db <<  o
							
				o = @db[o.sodb_id]
				
				o.name = 'update empty'
				@db << o
			end
		
			it 'hash save & read' do
				o = SimpleCollection.new.set :name => 'hash'
				o.collection = {'a' => 'a', 'b' => 'b'}
				@db <<  o
			
				o = @db[o.sodb_id]
				o.name.should == 'hash'
				o.collection.should == {'a' => 'a', 'b' => 'b'}
			end
			
			it "should correct save object graph" do
				# Array
				o = SimpleCollection.new.set :name => 'o1'
				o.collection = ['a']
				o2 = SimpleCollection.new.set :name => 'o2'
				o.collection << o2
				
				@db << o
				o = @db[o.sodb_id]
				
				o.collection[0].should == 'a'
				o.collection[1].name.should == 'o2'
				
				# Hash
				o = SimpleCollection.new.set :name => 'o1'
				o.collection = {0 => 'a'}
				o2 = SimpleCollection.new.set :name => 'o2'
				o.collection[1] = o2
				
				@db << o
				o = @db[o.sodb_id]
				
				o.collection[0].should == 'a'
				o.collection[1].name.should == 'o2'
            end
			
			it "should correct save and read nested arrays and hashes" do
				# Array
				o = SimpleCollection.new			
				o2 = SimpleCollection.new.set :name => 'o2'
				o.collection = [[[o2]]]
				
				@db << o
				o = @db[o.sodb_id]
				
				o.collection[0][0][0].name.should == 'o2'
				
				# Hash
				o = SimpleCollection.new				
				o2 = SimpleCollection.new.set :name => 'o2'
				o.collection = {0 => {0 => {0 => o2}}}
				
				@db << o
				o = @db[o.sodb_id]
				
				o.collection[0][0][0].name.should == 'o2'
            end
			
			it "should delete arrays" do
				@db.adapter.execute('delete from data_collections')
				o = SimpleCollection.new
				o.collection = [1, [2]]
				
				@db << o
				@db.delete_all o
				
				rows = @db.adapter.execute('select * from data_collections')
				rows.size.should == 0
            end
						
			it "should correct update arrays and not to cause memory leak" do
#				@db.adapter.execute('delete from data_collections')
#				o = SimpleCollection.new
#				o.collection = [1, [2], SimpleCollection.new.set(:name => 'o2')]								
#				
#				@db << o
#				o = @db[o.sodb_id]
#				
#				o.collection = [3, [4], SimpleCollection.new.set(:name => 'o3')]
#
#				@db << o
#				o = @db[o.sodb_id]
#				
#				o.collection[0].should == 3
#				o.collection[1][0].should == 4
#				o.collection[2].name.should == 'o3'
#				
#				rows = @db.adapter.execute('select * from data_collections')
#				rows.size.should == 4		
				Log.warn "memory leak test disabled"
            end
			
			class TwoRef
				include SODB::Persistent		
				attr_accessor :ref1, :ref2
            end
			
			it "should lay in single graph space" do
				a = ['a']
				a2 = ['a2']
				a << a2
				r = TwoRef.new
				r.ref1 = a
				r.ref2 = a2
				
				@db << r
				r = @db[r.sodb_id]
								
				r.ref1[1].object_id.should == r.ref2.object_id
            end
			
			it "obsolete update" do
				o1 = SimpleCollection.new.set :collection => ['a']
				@db << o1
				
				o1 = @db[o1.sodb_id]
				o2 = @db[o1.sodb_id]
				
				o2.collection << 'b'
				@db << o2
				
				o1.collection << 'c'
				lambda{
					@db << o1
                }.should raise_error
            end
		end		
	end
end