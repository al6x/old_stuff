require 'spec'
require 'sodb'

module SODB	
	class SimpleObject
		include Persistent		
		attr_accessor :name
    end
	
	describe 'Base operations' do
		before :all do
			@db = SODB::Db.new	
			@db.clear
		end		
		after :all do; @db.clear end
		
		it 'save & read' do
			sc = SimpleObject.new.set :name => 'a name'
			@db <<  sc
			
			sc_r = @db[sc.sodb_id]
			sc_r.name.should == 'a name'
        end
		
		it "single" do
			raise "Not implemented (Add spec for Db.single method)."
        end
        
        it 'correct setting for managed properties' do
			sc = SimpleObject.new.set :name => 'a name'
			@db <<  sc			
			sc_r = @db[sc.sodb_id]			

			sc_r.sodb_id.should_not be_nil
			sc_r.sodb_object_graph.should_not be_nil
			sc_r.sodb_version.should_not be_nil
        end
		
		it 'update' do			
			sc = SimpleObject.new.set :name => 'a name'
			@db <<  sc
			
			sc_r = @db[sc.sodb_id]
			sc_r.name.should == 'a name'
			
			sc.name = 'new name'			
			@db <<  sc
			
			sc_r = @db[sc.sodb_id]
			sc_r.name.should == 'new name'
        end			        									
		
		it 'dynamic scheme update' do
			class DynamicSchemeUpdate
				include SODB::Persistent		
				attr_accessor :name
			end
			
			d = DynamicSchemeUpdate.new
			d.name = 'a name'
			@db <<  d
			d = nil
			
			class DynamicSchemeUpdate				
				attr_accessor :new_attribute
			end
			
			d = DynamicSchemeUpdate.new
			d.name, d.new_attribute = 'name 2', 'some value'
			@db <<  d
			
			d = @db[d.sodb_id]
			d.name.should == 'name 2'
			d.new_attribute.should == 'some value'
		end

		it 'obsolete update' do			
			sc = SimpleObject.new.set :name => 'a name'
			@db <<  sc
			
			sc1 = @db[sc.sodb_id]
			sc2 = @db[sc.sodb_id]
			
			sc2.name = 'name 2'			
			@db <<  sc2
			
			sc1.name = 'name 1'
			lambda {
				@db << sc1
            }.should raise_error
        end

		it 'delete' do
			sc = SimpleObject.new.set :name => 'a name'
			@db <<  sc
			
			sc_r = @db[sc.sodb_id]
			sc_r.name.should == 'a name'
					
			@db.delete sc.sodb_id
			
			@db.should_not include(sc.sodb_id)			
        end
		
		it 'try to delete non-existent object' do
			@db.delete 1
			@db.delete 1
        end

		it 'obsolete update after delete' do
			sc = SimpleObject.new.set :name => 'a name'
			@db <<  sc
			
			sc1 = @db[sc.sodb_id]
			sc2 = @db[sc.sodb_id]
			
			@db.delete sc2.sodb_id
			
			sc1.name = 'name 1'
			lambda {
				@db << sc1
            }.should raise_error
        end
        
        it 'raise error when try to get object with id equals to nil' do
			lambda {@db[nil]}.should raise_error("Id cannot be nil")
        end

		it "should correct set 'sodb_updated' flag" do
			sc = SimpleObject.new
			sc.sodb_updated.should_not be_true
			sc.name = 'a name'
			sc.sodb_updated.should be_true
			
			@db <<  sc
			sc.sodb_updated.should be_false
        end
		
		it "shouln't update object if 'sodb_updated' is not tue" do
			sc = SimpleObject.new.set :name => 'a name'
			@db <<  sc
			version = sc.sodb_version
			
			@db <<  sc
			version.should == sc.sodb_version
        end
	end
end