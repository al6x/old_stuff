require 'spec'
require 'sodb'
require 'utils/log'

module SODB
	module ComplexObjectsSpec
		
		class SimpleReference
			include SODB::Persistent		
			attr_accessor :name, :reference
		end
	
		class Item
			include SODB::Persistent		
			attr_accessor :name, :content, :content2
		end
	
		class Content
			include SODB::Persistent		
			attr_accessor :name
		end
	
		class Article < Content
			include SODB::Persistent
			attr_accessor :text
		end
		
		class ConstructorCounter
			include SODB::Persistent
			attr_accessor :name
			
			@@counter = 0
			
			def initialize				
				@@counter += 1
            end
			
			def self.counter; @@counter end
        end
	
		describe 'Complex object' do
			before :all do			
				@db = SODB::Db.new
				@db.clear				
			end		
			after :all do; @db.clear end
		
			it 'save & read' do
				topic = Item.new.set :name => 'topic'			
				topic.content = Article.new.set :name => 'article title', :text => 'article text'
				@db <<  topic	
						
				t = @db[topic.sodb_id]
				#				t = @db.first :name=> 'topic'
				t.name.should == 'topic'
				t.content.name.should == 'article title'
				t.content.text.should == 'article text'
			end
						
			it 'should save inherited properties' do
				a = Article.new.set :name => 'article title', :text => 'article text'
				@db <<  a	
						
				a = @db[a.sodb_id]
				a.name.should == 'article title'
				a.text.should == 'article text'
			end
						
			it 'update' do
				t = Item.new.set :name => 'topic'			
				t.content = Article.new.set :name => 'article title', :text => 'article text'
				@db <<  t	
						
				t = @db[t.sodb_id]
				obsolete_t = @db[t.sodb_id]
							
				t.name = 'topic2'
				t.content.name = 'article title 2'
				t.content.text = 'article text 2'
				t.content2 = Article.new.set :name => "another article"
				@db << t
							
				t.content.name.should == 'article title 2'
				t.content2.name.should == 'another article'
							
				# Obsolete update
				obsolete_t.content.name = 'obsolete article'
				lambda{
					@db << obsolete_t
				}.should raise_error
			end
			
			it 'should not does memory leak caused by update' do
#				t = Item.new.set :name => 'topic'			
#				a = Article.new.set :name => 'article title', :text => 'article text'
#				t.content = a
#				@db <<  t	
#
#				t.content = Article.new.set :name => 'article 2', :text => 'text 2'
#				@db << t
#				
#				@db.should_not include(a.sodb_id)
				Log.warn "memory leak test disabled"
			end
									
			it 'simple delete' do
				t = Item.new.set :name => 'topic'			
				a = Article.new.set :name => 'article title', :text => 'article text'
				t.content = a
				@db <<  t	
							
				@db.delete t
							
				@db.should_not include(t.sodb_id)
				@db.should include(a.sodb_id)
			end
									
			it 'delete all tree' do
				t = Item.new.set :name => 'topic'			
				a = Article.new.set :name => 'article title', :text => 'article text'
				t.content = a
				@db <<  t	
							
				@db.delete_all t
							
				@db.should_not include(t.sodb_id)
				@db.should_not include(a.sodb_id)
			end
					
			it 'object with nil reference' do
				o = SimpleReference.new.set :name => 'a'
				@db << o
						
				o = @db[o.sodb_id]
				o.reference.should be_nil
			end
			
			it "shouldn't load lazy objects when updates tree" do			
				o = SimpleReference.new.set :name => 'a name'
				o.reference = ConstructorCounter.new.set :name => 'counter' # counter = 1
				
				@db << o
				o = @db[o.sodb_id]
				
				o.name = 'new name'
				@db << o
				
				ConstructorCounter.counter.should == 1
            end
		end
	end
end