require 'spec'
require 'sodb'

module SODB	
	module SingleObjectSpaceSpec
		class Parent
			include SODB::Persistent
			attr_accessor :a, :b
        end
		
		class A
			include SODB::Persistent
			attr_accessor :name
        end
		
		class B
			include SODB::Persistent
			attr_accessor :a, :name
        end
		
		describe 'Single object space' do
			before :all do
				@db = SODB::Db.new
				@db.clear; 
			end		
			after :all do; @db.clear end
		
			it 'single row correspond to single object (in one ObjectGraph)' do
				o = Parent.new
				o.a = A.new.set :name => 'A'
				o.b = B.new.set :name => 'B', :a => o.a
				
				@db <<  o				
				o = @db[o.sodb_id]								
			
				o.a.should == o.b.a
			end
			
			it 'object are different in different ObjectGraph' do
				a = A.new.set :name => 'A'
				@db << a
				
				a1 = @db[a.sodb_id]
				a2 = @db[a.sodb_id]
				
				a1.should_not == a2
            end
		end
	end
end