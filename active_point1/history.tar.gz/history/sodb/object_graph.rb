module SODB
	BASE_SIMPLE_TYPES = [String, Numeric, NilClass, Symbol, TrueClass, FalseClass]
	ALL_SIMPLE_TYPES = [String, Fixnum, Float, NilClass, Symbol, TrueClass, FalseClass]
	class UnknownObjectType < RuntimeError; 
		def self.check o
			unless ALL_SIMPLE_TYPES.include? o.class
				raise UnknownObjectType.new("'#{o.class}'") 
            end
        end
	end
	
	# Marker. That it isn't String, Ingeger, Symbol ...
	module ComplexType; end
	
	class ObjectGraph
		def initialize db; 
			@db, @objects = db, {}
		end
			
		attr_accessor :db, :objects
	end
		
	class Reference		
		attr_accessor :sodb_id, :sodb_class
		def initialize id, klass; 
			@sodb_id, @sodb_class = id, klass
        end
			
		def to_s; "Reference #{@sodb_id}" end
	end
	
	class LazyObjectHelper
		attr_reader :simple_attributes, :references
		
		def initialize object; @object = object end	
		
		def examine
			@simple_attributes, @references = {}, {}
			@object.class.sodb_persistent_properties.each do |name|
				value = @object.send("sodb_system_#{name}")
				
				if value.is_a?(ComplexType) || value.is_a?(Hash) || value.is_a?(Array)
					@references[name] = value
				elsif value.is_a?(Reference)
					# Then just skip it
				else
					UnknownObjectType.check value
					@simple_attributes[name] = value
				end
			end
        end
    end		
	
	class ArrayHelper
		attr_reader :simple_attributes, :references
		
		def initialize array; @array = array end	
		
		def examine
			@simple_attributes, @references = {}, {}
			@array.each_with_index do |value, name|								
				if value.is_a?(ComplexType) || value.is_a?(Hash) || value.is_a?(Array)
					@references[name] = value
				elsif value.is_a?(Reference)
					# Then just skip it
				else
					UnknownObjectType.check value
					@simple_attributes[name] = value
				end
			end
        end
    end	
	
	class HashHelper
		attr_reader :simple_attributes, :references
		
		def initialize hash; @hash = hash end	
		
		def examine
			@simple_attributes, @references = {}, {}
			@hash.each do |name, value|								
				if value.is_a?(ComplexType) || value.is_a?(Hash) || value.is_a?(Array)
					@references[name] = value
				elsif value.is_a?(Reference)
					# Then just skip it
				else
					UnknownObjectType.check value
					@simple_attributes[name] = value
				end
			end
        end
    end	
		
	class GraphHelper
		attr_reader :objects, :arrays, :hashes
		def initialize object; @object = object end	
		
		def examine
			@processed = []
			@objects, @arrays, @hashes = [], [], []
			add_object @object
		end				
		
		private
		def add_object o
			return if @processed.include? o
			@processed << o
						
			@objects << o
			o.class.sodb_persistent_properties.each do |name|
				process_value get_value(o, name)
			end			
		end
		
		def add_array array
			return if @processed.include? array
			@processed << array
			
			@arrays << array
			array.each do |o| 
				process_value o
			end
		end
		
		def add_hash hash
			return if @processed.include? hash
			@processed << hash
			
			@hashes << hash
			hash.values.each {|o| process_value o}
		end
		
		def process_value value
			if value.is_a?(ComplexType) 
				add_object value
			elsif value.is_a?(Array) 
				add_array value
			elsif value.is_a?(Hash)
				add_hash value
			end
		end
		
		def get_value o, name
			o.send name
		end
	end
	
	class LazyGraphHelper < GraphHelper
		def get_value o, name
			o.send "sodb_system_#{name}"
		end
	end
end