require 'sodb/object_graph'
require 'utils/open_constructor'

module SODB
	module ClassMethods end
	
	module PersistentCollection
		attr_accessor :sodb_id, :sodb_object_graph, :sodb_version
    end
	
	module Persistent		
		include ComplexType, Utils::OpenConstructor
		attr_accessor :sodb_id, :sodb_object_graph, :sodb_updated, :sodb_version
				
		
		# TODO Stub, becouse 'updated' does not works correctly wit arrays
		# I've temporary disabled 'updated' functional
		def sodb_updated; 
			true 
        end

		
		#		def mandatory= value;  
		#			self.sodb_updated = true unless sodb_updated
		#			@mandatory = value
		#        end
		#		
		#		def mandatory?; @mandatory ? true : false end	
		
		def self.included(klass) 
#			if klass.is_a? Class
				klass.extend(ClassMethods)
#			elsif klass.is_a? Module
#				klass.send(:include, ClassMethods)
#			else
#				raise 'Unsupported type!'
#			end
        end
	end
	
	module ClassMethods			
		def sodb_persistent_properties
			@persistent_attributes ||= []				
        end				
			
		def attr_accessor *attrs
			attrs = [attrs] if attrs.is_a? Symbol
			attrs.map!{|attr| attr.to_s}
				
			# If we updated any of Object's attribute his :sodb_updated is set to 'true'
			attrs.each do |name|
				# Lazy getter
				class_eval %{
def #{name}
	if @#{name}.is_a? Reference												
		@#{name} = sodb_object_graph.db.get_by_reference @#{name}, sodb_object_graph
	end
	@#{name}
end
				}
				
				# System getter (to get attribute without loading it)
				class_eval %{
def sodb_system_#{name}
	@#{name}
end
				}
						
				# Setter, marks Object as updated if called
				class_eval %{
def #{name}= value
	self.sodb_updated = true unless sodb_updated
	@#{name} = value
end		
				}
				
				sodb_add_persistent_properties attrs
				
				sodb_add_reference_to_parents											
				sodb_check_properties_in_parents
				sodb_propagate_properties_to_childs				
			end																			
		end
		
		# All this complex methods are to work with dynamic schema changes (
        # dynamic add methods to parent and propagate it to all childrens).
		protected
		def sodb_add_persistent_properties properties
			properties.each do |p|
				sodb_persistent_properties << p unless sodb_persistent_properties.include? p
			end
        end
		
		def sodb_check_properties_in_parents
			parents_properties = []
			ancestors.each do |parent|
				next unless parent.respond_to? :sodb_descendants				
				parents_properties.concat(parent.sodb_persistent_properties)
			end		
			sodb_add_persistent_properties parents_properties
        end
		
		def sodb_propagate_properties_to_childs
			sodb_descendants.each{|child| child.sodb_add_persistent_properties sodb_persistent_properties}				
        end
		
		def sodb_descendants; @descendants ||= [] end
		
		def sodb_add_reference_to_parents			
			ancestors.each do |parent|
				next unless parent.respond_to? :sodb_descendants
				parent.sodb_descendants << self unless parent.sodb_descendants.include? self
			end		
        end
	end
end