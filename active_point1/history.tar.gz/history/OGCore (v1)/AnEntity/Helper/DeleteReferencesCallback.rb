class DeleteReferencesCallback    	
	def initialize special_cases, process_entity, skip
		@special_cases, @process_entity, @skip, @processed = special_cases, process_entity, skip, Set.new
	end		
	
	def object_begin object;		
		back = @object
		@object = object
		return back
	end
	
	def object_end back;
		@object = back
	end
	
	def process_transient_object klass, name, object; end
	
	def process_object klass, name, object		
		return false if @skip and klass == Object and @skip.include?(name)
		if object.is_a? Entity						
			delete = @process_entity.call(object)			
			AccessorHelper.delete klass, @object, name if delete
			return false
		else 
			return false if @special_cases.include?(object.class) or @processed.include?(object.object_id)
			@processed.add object.object_id
			
			return true
		end
	end						
end