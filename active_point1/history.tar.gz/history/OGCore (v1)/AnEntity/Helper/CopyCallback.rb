class CopyCallback    		
	include Constants
	
	attr_reader :copy
	
	def object_end back
		@copy = back
	end
	
	def initialize special_cases, entity = nil
		@special_cases, @processed, @entity = special_cases, {}, entity
	end		
	
	def process_transient_object klass, name, object
		AccessorHelper.set klass, @copy, name, object
	end
	
	def process_object klass, name, object        		
		processor = @special_cases[object.class]                 
		if processor                            		
			AccessorHelper.set klass, @copy, name, processor.call(object)
			return false
		else
			if @processed.include? object.object_id
				AccessorHelper.set klass, @copy, name, @processed[object.object_id]
				return false
			elsif object.is_a?(Entity)
				AccessorHelper.set klass, @copy, name, object
				return false
			else				
				new_object = object.class.new				
				AccessorHelper.set klass, @copy, name, new_object
				@back = @copy
				@copy = new_object
				return true
			end 
		end                
	end						
	
	def object_begin object
		unless @first_entity
			@first_entity = true                        
			@copy = @entity || object.class.new
			@processed[object.object_id] = @copy
			return @copy
		else
			@processed[object.object_id] = @copy
			return @back
		end
	end
end