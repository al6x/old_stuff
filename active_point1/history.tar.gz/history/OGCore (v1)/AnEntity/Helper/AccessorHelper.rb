class AccessorHelper	
	class << self
		def set klass, object, key, value
			if klass == Hash 
				object[key] = value
			elsif klass == Array 
				object.at_set key, value
			elsif klass == Object
				object.instance_variable_set key, value
			else
				raise "Invalid class '#{klass}'!"
			end
		end
		
		def delete klass, object, key
			if klass == Hash 
				object.delete key
			elsif klass == Array 				
				object.delete_at key
			elsif klass == Object
				object.instance_variable_set key, nil
			else
				raise "Invalid class '#{klass}'!"
			end
		end
	end
end