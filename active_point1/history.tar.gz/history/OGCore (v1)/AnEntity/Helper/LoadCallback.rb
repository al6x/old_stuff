class LoadCallback	
	include Constants
	
	attr_reader :object
	
	def object_end back
		@object = back
	end
	
	def initialize entity_id, special_cases, external_entity, entity_created
		@entity_id, @special_cases, @processed, @external_entity, @entity_created = 
		entity_id, special_cases, {}, external_entity, entity_created
	end		
	
	def process_object klass, name, element
		processor = @special_cases[element.name]         
		
		name_processor = @special_cases[name.name]
		name = name_processor.call(name)
		
		if processor         
			AccessorHelper.set klass, @object, name, processor.call(element)
			#            @object.send accessor, name, processor.call(element)
			return false
		else
			case element.name
				when OBJECT_REFERENCE
				AccessorHelper.set klass, @object, name, @processed[element.text]
				#                @object.send accessor, name, @processed[element.text]
				return false
				when EXTERNAL_ENTITY            	
				entity = @external_entity ? @external_entity.call(element.text) : nil
				AccessorHelper.set klass, @object, name, entity
				#                @object.send accessor, name, entity
				return false
			else
				begin
					element_klass = eval element.attributes[CLASS], TOPLEVEL_BINDING, __FILE__, __LINE__
				rescue Exception => e
					raise "Can't eval Class (#{e.message})!"
				end
				
				begin
					object = element_klass.new
				rescue Exception => e
					puts element
					raise "Can't instantiate Object of '#{element_klass.name}' Class (#{e.message})!"					
				end
				AccessorHelper.set klass, @object, name, object
				#                @object.send accessor, name, object
				@back = @object
				@object = object
				return true
			end 
		end                
	end						
	
	def object_begin element
		object_id = element.attributes[OBJECT_ID]
		if element.name == ENTITY  
			klass = eval element.attributes[CLASS], TOPLEVEL_BINDING, __FILE__, __LINE__			
			@object = klass.new
			@processed[object_id] = @object
			@entity_created.call(@entity_id, @object)  if @entity_created
			return @object
		else
			@processed[object_id] = @object            
			return @back
		end
	end
end