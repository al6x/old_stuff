class DumpCallback		
	include REXML, Constants	        
	
	@@formatter = REXML::Formatters::Default.new
#	@@formatter.compact = true		
	
	def initialize special_cases
		@id_counter, @processed, @special_cases = 0, {}, special_cases
	end		
	
	def xml
		xml = ""		
		@@formatter.write @element, xml		
		return xml
	end
	
	def object_begin object		
		@klass = nil
		unless @first_entity
			@first_entity = true
			@element = Element.new(ENTITY)
			@element.attributes[CLASS] = object.class.name
			@processed[object.object_id] = @id_counter += 1
			@element.attributes[OBJECT_ID] = @id_counter.to_s	
			return @element
		else
			back = @element
			@element = Element.new(OBJECT)
			@element.attributes[CLASS] = object.class.name
			@processed[object.object_id] = @id_counter += 1
			@element.attributes[OBJECT_ID] = @id_counter.to_s
			back.add @element
			return back
		end      
	end
	
	def object_end back
		@element = back
	end
	
	def process_transient_object klass, name, object; end
	
	def process_object klass, name, object   		
		if klass != @klass
			@klass = klass
			if klass == Array  
				@element.add Element.new(ARRAY)
			elsif klass == Hash 
				@element.add Element.new(HASH)
			elsif klass == Object 
				@element.add Element.new(VARIABLE)
			else
				raise "Invalid class '#{klass}'!"
			end
		end
		name_processor = @special_cases[name.class]
		@element.add name_processor.call(name)
		
		processor = @special_cases[object.class]
		if processor                            							
			@element.add processor.call(object)
			return false
		else
			if @processed.include? object.object_id
				@element.add Element.new(OBJECT_REFERENCE).add_text(@processed[object.object_id].to_s)
				return false
			elsif object.is_a?(Entity)
				@element.add Element.new(EXTERNAL_ENTITY).add_text(object.og_id.to_s)
				return false
			else
				return true
			end            
		end                
	end
end