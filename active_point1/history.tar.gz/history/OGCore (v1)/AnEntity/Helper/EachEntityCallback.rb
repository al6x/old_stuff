class EachEntityCallback    
	
	def initialize special_cases, process_entity, skip
		@special_cases, @process_entity, @skip, @processed = special_cases, process_entity, skip, Set.new
	end		
	
	def object_begin object;  end
	
	def object_end back; end
	
	def process_transient_object klass, name, object; end
	
	def process_object klass, name, object    
		return false if @special_cases.include?(object.class) or @processed.include?(object.object_id) or 
		(@skip and klass == Object and @skip.include?(name))
		@processed.add object.object_id
		
		if object.is_a? Entity
			return @process_entity.call(object)
		else 
			return true
		end
	end						
end