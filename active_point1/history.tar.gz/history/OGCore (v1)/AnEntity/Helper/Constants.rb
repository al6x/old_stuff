module Constants
    ENTITY = "entity"
    OBJECT = "object"
    OBJECT_REFERENCE = "ref"
    EXTERNAL_ENTITY = "ext_e"
    CLASS = "c"
    OBJECT_ID = "id"
    HASH = "h"
    ARRAY = "a"
    VARIABLE = "v"
end