class EachObjectCallback    	
	def initialize special_cases, block, skip
		@special_cases, @block, @processed, @skip = special_cases, block, Set.new, skip
	end		
	
	def object_begin object;
		return if @processed.include?(object.object_id)
		@processed.add object.object_id
		@block.call object
	end
	
	def object_end back; end
	
	def process_transient_object klass, name, object; end
	
	def process_object klass, name, object    
		return false if @processed.include?(object.object_id)
		if ["@og_id", "@og_version", "@og_engine"].include?(name) or 
		(@skip and klass == Object and @skip.include?(name))
			return false			
		elsif @special_cases.include?(object.class)
			@block.call object
			return false
		else			
			@processed.add object.object_id
			@block.call object
			return true
		end
	end		
end