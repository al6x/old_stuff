class Helper	        			
	@dump_types = {
		Fixnum => lambda{|o| REXML::Element.new("f").add_text(o.to_s)},			
		Bignum => lambda{|o| REXML::Element.new("b").add_text(o.to_s)},			
		Float => lambda{|o| REXML::Element.new("fl").add_text(o.to_s)},			
		NilClass => lambda{|o| REXML::Element.new("nil")},			
		String => lambda{|o| REXML::Element.new("s").add_text(o)},
		Symbol => lambda{|o| REXML::Element.new("sym").add_text(o.to_s)}, 			
		FalseClass => lambda{|o| REXML::Element.new("false")},			
		TrueClass => lambda{|o| REXML::Element.new("true")},			
		Class => lambda{|o| REXML::Element.new("Class").add_text(o.name)},			
		Proc => lambda{|o| REXML::Element.new("Proc").add_text(o.to_ruby)}
	}
	
	@load_types = {
            "f" => lambda{|e| e.text.to_i},			
            "b" => lambda{|e| e.text.to_i},			
            "fl" => lambda{|e| e.text.to_f},			
            "nil" => lambda{|e| nil},			
            "s" => lambda{|e| e.text || ""},
            "sym" => lambda{|e| e.text.to_sym}, 			
            "false" => lambda{|e| false},			
            "true" => lambda{|e| true},			
            "Class" => lambda{|e| eval(e.text, TOPLEVEL_BINDING, __FILE__, __LINE__)},			
            "Proc" => lambda{|e| eval(e.text, TOPLEVEL_BINDING, __FILE__, __LINE__)}
	}
	
	@copy_types = {
		Fixnum => lambda{|o| o},			
		Bignum => lambda{|o| o},			
		Float => lambda{|o| o},			
		NilClass => lambda{|o| o},			
		String => lambda{|o| o},
		Symbol => lambda{|o| o}, 			
		FalseClass => lambda{|o| o},			
		TrueClass => lambda{|o| o},
		Class => lambda{|o| o},			
		Proc => lambda{|o| o}
	}
	
	class << self
		include REXML, Constants, Log
		
		def compare_by_content e1, e2		
			xml1 = dump e1
			xml2 = dump e2
			xml1 == xml2				
		end       
		
		def dump entity		
			callback = DumpCallback.new @dump_types
			process_object entity, callback
			return callback.xml
		end
		
		def load data, entity_id = nil, external_entity = nil, entity_created = nil
			element = Document.new(data).root
			callback = LoadCallback.new entity_id, @load_types, external_entity, entity_created
			process_element element, callback
			return callback.object
		end
		
		def copy entity
			callback = CopyCallback.new @copy_types
			process_object entity, callback
			return callback.copy
		end
		
		# Writes only to entity, it doesn"t trawerse all entity graph. 
		# It"s forbiddent for other objects to have links to inner aggregate structure.
		def write_back from, to
			to.clear if to.is_a?(Array) or to.is_a?(Hash)
			
			to.instance_variables do |name| 
				to.instance_variable_set nil
			end
			
			callback = CopyCallback.new @copy_types, to
			process_object from, callback
			return callback.copy
			
			#			if to.is_a?(Array)			
			#				to.clear
			#				from.each{|item| to << item}
			#			elsif to.is_a?(Hash)
			#				to.clear
			#				from.each{|key, value| to[key] = value}
			#			end
			#			
			#			transient = from.class.transient_get
			#			to.instance_variables do |name| 
			#				to.instance_variable_set name, nil unless transient.include? name
			#			end
			#			
			#			from.instance_variables.each do |name|		            
			#				to.instance_variable_set name, from.instance_variable_get(name) unless transient.include? name
			#			end
		end
		
		def each_object_in_graph graph, skip = nil, &process_object
			callback = EachObjectCallback.new @copy_types, process_object, skip
			process_object graph, callback
		end
		
		def each_entity entity, skip = nil, &process_entity
			callback = EachEntityCallback.new @copy_types, process_entity, skip
			process_object entity, callback
		end 
		
		def delete_references entity, skip = nil, &b
			callback = DeleteReferencesCallback.new @copy_types, b, skip
			process_object entity, callback
		end
		
		protected               
		def process_object object, callback		
			back = callback.object_begin object
			
			if object.is_a?(Array)			
				object.each_with_index do |value, index|						
					if callback.process_object Array, index, value
						process_object value, callback
					end
				end
			elsif object.is_a?(Hash)
				object.each do |key, value|						
					if callback.process_object Hash, key, value
						process_object value, callback
					end
				end
			end
			
			
			if object.is_a? Entity
				transient = object.class.transient_get
				object.instance_variables.sort.each do |name|	
					value = object.instance_variable_get name
					if transient.include? name                
						callback.process_transient_object Object, name, value
					else
						if callback.process_object Object, name, value
							process_object value, callback
						end
					end
				end
			else
				object.instance_variables.sort.each do |name|						
					value = object.instance_variable_get name
					if callback.process_object Object, name, value
						process_object value, callback
					end
				end
			end
			
			callback.object_end back
		end	
		
		def process_element e, callback
			back = callback.object_begin e
			
			i = 0
			while i < e.elements.size
				first = e.elements[i += 1]
				
				case first.name
					when ARRAY       
					current_klass = Array
					next
					when HASH
					current_klass = Hash
					next
					when VARIABLE				
					current_klass = Object
					next
				else
					name = first
					value = e.elements[i += 1]
					
					if callback.process_object current_klass, name, value
						process_element value, callback
					end
				end                                        
			end
			
			callback.object_end back
		end
	end
end
