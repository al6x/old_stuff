class Engine
	include Observable
	attr_reader :transaction_strategy, :garbage_collector, :root
	
	INITIALIZATION_SYNC = Monitor.new
	
	def initialize name, params = {}
		INITIALIZATION_SYNC.synchronize do		
			super()			        		
			
			@sync = Sync.new
			@stream_sync = Monitor.new
			
			@transaction_strategy = CONFIG[:transaction_strategy].new(self)
			
			@hash_storage = ::HashStorage::Storage.new name, CONFIG[:directory]
			@stream_storage = ::StreamStorage::Storage.new name, CONFIG[:directory], CONFIG[:buffer_size]
			
			@root = load params[:root_class] || Root
			
			activate_garbage_collector
		end
	end
	
	def isolate &b
		@sync.synchronize(:SH){b.call}
	end
	
	def transaction
		@transaction_strategy.active_transaction_for_copy
	end
	
	def copy_entity entity, user_transaction = nil
		transaction = user_transaction || @transaction_strategy.active_transaction_for_copy
		raise "There is no active transaction!" unless transaction
		
		copy = transaction.copies[entity]
		unless copy
			copy = AnEntity::Helper.copy entity
			transaction.add copy, entity
		end
		
		return copy
	end
	
	def original? entity, user_transaction = nil 
		transaction = user_transaction || @transaction_strategy.active_transaction_for_copy
		copy = transaction.copies[entity]
		return !copy.equal?(entity) # check using 'equal?', not '=='		
	end
	
	def original entity, user_transaction = nil
		transaction = user_transaction || @transaction_strategy.active_transaction_for_copy
		raise "There is no active transaction!" unless transaction
		
		return transaction.originals[entity] || entity
	end
	
	def stream_metadata_put id, metadata
		@stream_storage.metadata_put id, metadata
	end
	
	def stream_metadata_read id
		@stream_storage.metadata_read id
	end
	
	def stream_size id
		@stream_storage.stream_size id
	end
	
	def stream_put data = nil, &block; 	
		id = nil
		@stream_sync.synchronize{id = StreamID.new(@last_stream_id.increase)}
		@stream_storage.stream_put id, data, &block
		return id
	end
	
	def stream_put_each stream
		id = nil
		@stream_sync.synchronize{id = StreamID.new(@last_stream_id.increase)}
		@stream_storage.stream_put_each id, stream
		return id
	end
	
	def stream_put_from_file file_name
		File.open file_name, "r" do |f|
			stream_put_each f
		end
	end
	
	def stream_read_to_file id, file_name
		File.open file_name, "w" do |to|
			stream_read_each(id){|part| to.write part}
		end
	end
	
	def stream_read id, &block; 
		@stream_storage.stream_read id, &block
	end
	
	def stream_read_each id, &block
		@stream_storage.stream_read_each id, &block
	end
	
	def self.delete name, path = CONFIG[:directory]; 
		INITIALIZATION_SYNC.synchronize do
			::HashStorage::Storage.delete name, path
			::StreamStorage::Storage.delete name, path
		end
	end
	
	def close		
		INITIALIZATION_SYNC.synchronize do
			@sync.synchronize(:EX) do
				#				@root.clear	
				@hash_storage.close
				@garbage_collector.kill
			end
		end
	end
	
	def collect_garbage
		isolate do
			memory = [@root.og_id].to_set
			AnEntity::Helper.each_entity @root do |e|
				if memory.include? e.og_id
					false
				else
					memory.add e.og_id
					true
				end
			end
			
			@hash_storage.list_of_ids.each do |id|
				@hash_storage.delete id unless memory.include? id.to_i
			end						
		end
		stream_collect_garbage
	end
	
	def stream_collect_garbage object_space = ObjectSpace 
		@stream_sync.synchronize do			
			ObjectSpace.garbage_collect
			memory = Set.new
			object_space.each_object(StreamID){|s| memory.add s.sid.to_s}			
			@stream_storage.list_of_ids.each do |id|
				@stream_storage.delete StreamID.new(id) unless memory.include?(id)
			end
		end
	end
	
	def engine_commit user_transaction = nil	
		@sync.synchronize(:SH) do
			notify_observers :before_commit
			
			# Commit start
			transaction = user_transaction || @transaction_strategy.active_transaction_for_commit        
			return unless transaction and !transaction.copies.empty?
			
			# Check for outdated entities
			outdated = []
			transaction.copies.each do |original, copy| 
				outdated << [copy, original] if copy.og_version != original.og_version
			end
			unless outdated.empty?
				@transaction_strategy.outdated_exception(outdated) unless user_transaction
				raise OutdatedException.new(outdated)
			end
			
			new_entities = transaction.new						
			
			@sync.synchronize(:EX) do
				# Initializing new entities
				# @listener can use .hash and we need to setup og_id for new entities before it.
				new_entities.each{|ne| initialize_new_entity ne}
				
				notify_observers :before_processing, transaction.originals, transaction.copies, new_entities								
				
				# Updated entities            
				transaction.copies.each do |original, copy| 
					copy.og_version += 1
					AnEntity::Helper.write_back copy, original
					
					
				end
				
				to_write = {}
				changed_entities = transaction.copies.values + new_entities				
				changed_entities.each{|e| to_write[e.og_id] = AnEntity::Helper.dump(e)}                        
				
				@hash_storage.atomic_write to_write                                  
				
				notify_observers :after_processing, transaction.originals, transaction.copies, new_entities
			end
			
			@transaction_strategy.after_commit unless user_transaction
			
			notify_observers :after_commit, transaction.originals, new_entities
			
			return transaction
		end
	end
	
	def engine_rollback
		@transaction_strategy.after_rollback
	end
	
	# Absolutelly the same as 'commit' but with timeout, and callback when it starts.
	def engine_commit_debug timeout, user_transaction = nil, &start
		@sync.synchronize(:SH) do			
			transaction = user_transaction || @transaction_strategy.active_transaction_for_copy # not for commit!
			notify_observers :before_commit, transaction
			
			# Commit start
			transaction = user_transaction || @transaction_strategy.active_transaction_for_commit        
			return unless transaction and !transaction.copies.empty?
			
			# Check for outdated entities
			outdated = []
			transaction.copies.each do |original, copy| 
				outdated << [copy, original] if copy.og_version != original.og_version
			end
			unless outdated.empty?
				@transaction_strategy.outdated_exception(outdated) unless user_transaction
				raise OutdatedException.new(outdated)
			end
			
			new_entities = transaction.new	
			
			@sync.synchronize(:EX) do
				start.call
				# Initializing new entities
				# @listener can use .hash and we need to setup og_id for new entities before it.
				new_entities.each{|ne| initialize_new_entity ne}
				
				notify_observers :before_processing, transaction.originals, transaction.copies, new_entities								
				
				# Updated entities            
				transaction.copies.each do |original, copy| 
					copy.og_version += 1
					AnEntity::Helper.write_back copy, original
				end
				
				to_write = {}
				changed_entities = transaction.copies.values + new_entities
				changed_entities.each{|e| to_write[e.og_id] = AnEntity::Helper.dump(e)}                        
				
				@hash_storage.atomic_write to_write                                  
				
				notify_observers :after_processing, transaction.originals, transaction.copies, new_entities
				sleep timeout
			end
			
			@transaction_strategy.after_commit unless user_transaction
			
			notify_observers :after_commit, transaction.originals, new_entities
		end
	end
	
	protected
	def evaluate_last_ids
		max_id = "0"
		@hash_storage.list_of_ids.each{|id| max_id = id if id > max_id}
		@last_hash_id = Counter.new max_id.to_i
		
		max_id = "0"
		@stream_storage.list_of_ids.each{|id| max_id = id if id > max_id}
		@last_stream_id = Counter.new max_id.to_i
	end
	
	def initialize_new_entity entity
		entity.og_id = (@last_hash_id.increase)
		entity.og_version = 0
		initialize_transient_attributes entity
	end
	
	def initialize_transient_attributes entity
		entity.og_engine = self
	end
	
	def load root_class
		evaluate_last_ids
		begin
			@hash_storage[1]
		rescue HashStorage::NotFound
			root = root_class.new
			initialize_new_entity root
			@hash_storage[root.og_id] = AnEntity::Helper.dump(root)
			evaluate_last_ids
		end
		
		processed = {}        
		entity_created = lambda{|anog_id, anentity| processed[anog_id] = anentity}
		
		entity_resolver = lambda do |og_id|
			entity = processed[og_id]
			
			#			if entity
			#				entity
			#			else
			unless entity
				data = @hash_storage[og_id]
				entity = AnEntity::Helper.load data, og_id, entity_resolver, entity_created
				initialize_transient_attributes entity
				entity
			end  
			
			entity
		end
		
		repository_data = @hash_storage[1]
		repository = AnEntity::Helper.load repository_data, 1, entity_resolver, entity_created
		initialize_transient_attributes repository
		
		return repository
		#		AnEntity::Helper.write_back repository, @root
		#		initialize_transient_attributes @root # Becouse og_repository will be not copied in 'write_back'
	end
	
	def activate_garbage_collector
		@garbage_collector = GarbageCollector.new self, CONFIG[:garbage_collector_pause]
	end		
	
	class Counter
		def initialize initial; 
			@counter = initial 
		end
		
		def increase; 
			@counter += 1
		end
		
		def current; @counter end
	end
end