SPEC_DIR = File.dirname __FILE__

require "#{SPEC_DIR}/ConcurrencySpec"
require "#{SPEC_DIR}/ExtendedSpec"
require "#{SPEC_DIR}/GarbageCollectorSpec"
require "#{SPEC_DIR}/GeneralSpec"
require "#{SPEC_DIR}/StreamSpec"
require "#{SPEC_DIR}/SerializerAndEntityHelperSpec"
require "#{SPEC_DIR}/TransientSpec"