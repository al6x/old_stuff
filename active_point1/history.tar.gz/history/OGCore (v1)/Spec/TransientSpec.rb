require 'OGCore/require'
require 'spec'

module OGCore
	describe "Transient" do	
		before :all do
			OGCore::CONFIG[:directory] = "#{File.dirname __FILE__}/data"
		end
		
		class Transient
			inherit Entity
			attr_accessor :name, :transient
			transient :@transient
		end		
		
		class TransientDescendant < Transient
			attr_accessor :transient2
			transient :@transient2
		end
		
		it "Simple" do							
			Engine.delete :test
			
			om = Engine.new(:test).root						
			c = om.copy
			t = Transient.new
			t.name, t.transient =  'name', 'transient'
			c[:t] = t
			c.commit
			om.close
			
			om = Engine.new(:test).root						
			t = om[:t]
			t.name.should == 'name'
			t.transient.should be_nil
			
			om.close
			Engine.delete :test
		end
		
		it "With inheritance" do						
			Engine.delete :test
			
			om = Engine.new(:test).root						
			c = om.copy
			t = TransientDescendant.new
			t.name, t.transient, t.transient2 =  'name', 'transient', 'transient2'
			c[:t] = t
			c.commit
			om.close
			
			om = Engine.new(:test).root						
			t = om[:t]
			t.name.should == 'name'
			t.transient.should be_nil
			t.transient2.should be_nil
			
			om.close
			Engine.delete :test
		end
	end
end