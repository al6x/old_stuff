#require 'RubyExt/require'
#require 'rexml/document'
require 'OGCore/require'
require 'spec'

module OGCore
	describe "EntityMarshal & AnEntity::Helper" do
		class SimpleTypes
			inherit Entity
			attr_accessor :fixnum, :bignum, :float, :nilClass, :string,	:symbol, :falseClass, :trueClass, :klass
		end				
		
		class ValueObject
			attr_accessor :value
		end
		
		it "Simple Types" do
			s = SimpleTypes.new
			values = [10, 11111111111111111111, 4.5, nil, "string", :symbol, false, true, 
			SimpleTypes]
			
			s.fixnum, s.bignum, s.float, s.nilClass, s.string, s.symbol, s.falseClass, s.trueClass,
			s.klass= values
			
			helper = AnEntity::Helper
			xml = helper.dump s
			s = helper.load xml						
			
			[s.fixnum, s.bignum,s.float, s.nilClass, s.string, s.symbol, s.falseClass, s.trueClass,
			s.klass].should == values
			
			s = helper.copy s
			[s.fixnum, s.bignum, s.float, s.nilClass, s.string, s.symbol, s.falseClass, s.trueClass,
			s.klass].should == values
		end
		
		class CycleReference
			inherit Entity
			attr_accessor :value
		end
		
		
		it "Entity cycle references" do            
			o1, o2 = CycleReference.new, CycleReference.new
			o1.value = o2
			o2.value = o1
			
			helper = AnEntity::Helper
			xml = helper.dump o1
			o2 = helper.load xml
			
			o2 = helper.copy o1
			helper.compare_by_content(o1, o2).should be_true
			o2.object_id.should_not == o1.object_id
		end
		
		it "Aggregate inner cycle references" do
			oa = CycleReference.new			
			a = [oa]
			oa.value = a
			
			oh = CycleReference.new
			h = {:oh => oh}
			oh.value = h
			
			ov = CycleReference.new
			vo = ValueObject.new
			ov.value = vo
			vo.value = ov
			
			[oa, oh, ov].each do |object|
				helper = AnEntity::Helper
				xml = helper.dump object
				object2 = helper.load xml			
				helper.compare_by_content(object, object2).should be_true
				
				object2 = helper.copy object
				helper.compare_by_content(object, object2).should be_true
				object2.object_id.should_not == object.object_id
			end
		end		
		
		class TransientAttributes
			inherit Entity
			attr_accessor :value, :tvalue
			transient :@tvalue
		end
		
		it "Should pass by transient attributes when marshaling and comparing. And copy by reference when 
		copies." do
			o = TransientAttributes.new
			o.value, o.tvalue = :value, :tvalue
			
			helper = AnEntity::Helper
			xml = helper.dump o
			o2 = helper.load xml
			helper.compare_by_content(o, o2).should be_true												
			o2.tvalue.should be_nil
			
			o2 = helper.copy o
			helper.compare_by_content(o, o2).should be_true
			o2.tvalue.object_id.should == o.tvalue.object_id						
		end
		
		class AggregateSample
			inherit Entity
			attr_accessor :hash, :array, :entity, :value_object
		end
		
		class AnotherEntity
			inherit Entity
		end
		
		it "Should correct works with aggregates" do
			a = AggregateSample.new
			another = AnotherEntity.new
			vo = ValueObject.new
			vo.value = :value
			a.hash, a.array, a.entity, a.value_object = {:a => :b}, [:a], another, vo						
			
			helper = AnEntity::Helper
			xml = helper.dump a   			
			a2 = helper.load xml                                                
			
			helper.compare_by_content(a, a2).should be_false
			a.entity = nil
			helper.compare_by_content(a, a2).should be_true	
			
			a.entity = another
			a2 = helper.copy a
			
			helper.compare_by_content(a, a2).should be_true                                    
			a2.entity.object_id.should == a.entity.object_id
		end		
		
		class MultiSample
			inherit Entity
			attr_accessor :h, :a
		end
		
		it "Should correct works with multi array/hash" do
			m = MultiSample.new
			m.a, m.h = [:a, [:b], {:c => [:d]}], {:a => {:b => :c}}
			
			helper = AnEntity::Helper
			xml = helper.dump m
			m2 = helper.load xml
			
			helper.compare_by_content(m, m2).should be_true
			
			m2 = helper.copy m
			helper.compare_by_content(m, m2).should be_true
		end
		
		class ProcSample
			inherit Entity
			attr_accessor :proc
		end
		
		it "Should correct save proc. Copy Proc by reference. And ingnore by comparison." do
			p = ProcSample.new
			p.proc = lambda{3}
			
			helper = AnEntity::Helper
			xml = helper.dump p
			p2 = helper.load xml
			p2.proc.call.should == 3
			
			p2 = helper.copy p
			p2.proc.call.should == 3
			p2.proc.should be_equal(p.proc)
		end
		
		class EntityWithReferences
			inherit Entity
			attr_accessor :value
		end
		
		it "Should correct works with object references" do
			array = []
			e = EntityWithReferences.new
			e.value = [array, array]
			
			helper = AnEntity::Helper
			xml = helper.dump e
			e2 = helper.load xml                           			
			helper.compare_by_content(e, e2).should be_true
			e2.value[0].should be_equal(e2.value[1])                        
			
			e2 = helper.copy e
			helper.compare_by_content(e, e2).should be_true
			e2.value[0].should be_equal(e2.value[1])
		end		
		
		class EntityCopy
			inherit Entity
			attr_accessor :value
		end
		
		it "Should not copy other entities" do
			e = EntityCopy.new
			e2 = EntityCopy.new
			e.value = e2
			
			helper = AnEntity::Helper
			c = helper.copy e
			c.should_not equal(e)
			c.value.should equal(e2)
		end
		
		class ObjectArray < Array
			inherit Entity
			attr_accessor :value
		end
		
		it "Should correct save instance variables of collection" do
			oa = ObjectArray.new
			oa[0], oa.value = 2, 3
			
			helper = AnEntity::Helper
			xml = helper.dump oa
			
			oa2 = helper.load xml
			oa2[0].should == oa[0]
			oa2.value.should == oa.value
		end                
		
		class WriteBack < Array
			inherit Entity
			attr_accessor :v1, :v2, :v3, :tr
			transient :@tr
		end
		
		it "Should correct write back values" do
			o = WriteBack.new
			o << 1; o << 2
			o.v1, o.v2, o.tr = 1, 2, :tr
			
			helper = AnEntity::Helper
			c = helper.copy o
			c.clear; c << 3
			c.tr = nil
			c.v3 = 3
			c.v2 = nil
			helper.write_back c, o
			o.size.should == 1
			o[0].should == 3
			o.tr.should == nil            
			[o.v1, o.v2, o.v3].should == [1, nil, 3]
		end
		
		class EachEntity
			inherit Entity
			include OpenConstructor
			attr_accessor :name, :value
		end
		
		it "each_entity" do
			e3 = EachEntity.new
			
			e2 = EachEntity.new
			e2.value = e3
			
			e1 = EachEntity.new
			e1.name, e1.value = :name, e2
			e1.og_id = 1
			
			new = []
			AnEntity::Helper.each_entity e1 do |e|
				if e.og_engine
					false
				else
					new << e
					true
				end                
			end
			new.should == [e2, e3]
			
			visited = []
			AnEntity::Helper.each_entity e1, ["@value"] do |e|
				if e.og_engine
					false
				else
					visited << e
					true
				end                
			end
			visited.should == []
		end
		
		class EachReference < Array
			inherit Entity
			attr_accessor :reference, :inner_object
		end
		
		it "delete_references" do			
			e2 = EachEntity.new
			
			er = EachReference.new			
			er.reference = e2
			er.inner_object = [e2, er]
			er << e2			
			
			AnEntity::Helper.delete_references(er) do |ref| 
				ref == e2 ? true : false
			end
			er.reference.should == nil
			er.size.should == 0			
			er.inner_object.should == [er]
			
			e2 = EachEntity.new
			e1 = EachEntity.new.set :value => e2
			visited = []
			AnEntity::Helper.delete_references e1, ["@value"] do |ref|
				visited << ref
				false
			end
			visited.should == []
		end
		
		class EachObject
			inherit Entity
			include OpenConstructor
			attr_accessor :a, :b, :c
		end
		
		it "each_object_in_graph" do
			e1 = EachObject.new.set :a => 1
			e1.b = e1
			e2 = EachObject.new.set :a => e1
			e1.c = e2
			list = []
			AnEntity::Helper.each_object_in_graph e1 do |o|
				list << o
			end
			list.to_set.should == [1, e1, e2].to_set
			list.size.should == 3
		end
		
		class Callback 
			def initialize target = nil; @target = target end
			attr_accessor :target
		end
		class IncapsulatedCopy
			inherit Entity
			
			def callback
				@callback ||= Callback.new self
			end
		end
		
		it "Copy should be incapsulated (from error)" do
			original = IncapsulatedCopy.new
			original.callback.target.should equal(original)
			
			copy = AnEntity::Helper.copy original
			copy.callback.target.should equal(copy)
			
			AnEntity::Helper.write_back copy, original
			original.callback.target.should equal(original)
		end
	end
end
