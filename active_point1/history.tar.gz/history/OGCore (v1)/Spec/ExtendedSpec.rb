require 'OGCore/require'
require 'spec'
require "#{File.dirname(__FILE__)}/timer"

module OGCore
	describe "Repository Extended" do	
		class SimpleEntity
			inherit Entity
			attr_accessor :name, :value
			
			def initialize name = nil, value = nil
				self.name, self.value = name, value
			end
		end	                
		
		class Listener
			attr_accessor :counter
			
			def initialize engine
				@engine = engine
				@counter = 0
			end
			
			def update type, *params
				case type
					when :before_commit then					
					@engine.transaction.copies.size.should == 1
					@engine.transaction.new.size.should == 1					
					@counter += 11
					when :after_commit then
					updated, new = *params
					updated.size.should == 1
					new.size.should == 1
					@counter += 20
				end
			end
		end			
		
		it "original" do
			e = SimpleEntity.new
			e.original.should be_equal(e)
			@r.original.should be_equal(@r)
			@r.copy.original.should be_equal(@r)
		end
		
		it "Listener" do		
			Engine.delete :listener			            
			r = Engine.new(:listener).root
			l = Listener.new r.og_engine
			r.og_engine.add_observer l
			copy = r.copy
			copy[:se] = SimpleEntity.new :name, :value
			r.commit					
			l.counter.should == 31
			r.close
			Engine.delete :listener
		end
		
		it "Should save special characters" do
			Engine.delete :special_characters
			r = Engine.new(:special_characters).root
			c = r.copy
			c[1] = "<test>"
			c.commit
			
			r[1].should == "<test>"
			r.close
			
			r = Engine.new(:special_characters).root
			r[1].should == "<test>"
			
			r.close
			Engine.delete :special_characters
		end
		
		it "original?" do
			SimpleEntity.new.original?.should be_true
			@r.original?.should be_true
			c = @r.copy
			c.original?.should be_false
			@r.original?.should be_true
			c.commit
			@r.original?.should be_true
		end
		
		class Callback 
			def initialize target = nil; @target = target end
			attr_accessor :target
		end
		class IncapsulatedCopy
			inherit Entity
			attr_accessor :string
			
			def initialize
				@callback = Callback.new self
				@string = ""
			end
			
			def callback
				@callback
			end
		end
		
		it "Root elment initialization (from error)" do
			Engine.delete :test2
			r = Engine.new(:test2, :root_class => IncapsulatedCopy).root
			
			r.callback.target.should equal(r)
			r.string.should == ""
			
			r.og_engine.close
			Engine.delete :test2
		end
		
		
		class A
			attr_accessor :v
		end
		
		it "Empty String are nil after loading (from error)" do
			Engine.delete :test2
			r = Engine.new(:test2).root
			
			a = A.new
			a.v = ""
			c = r.copy
			c[:a] = a 
			c.commit
			
			r.og_engine.close
			
			r = Engine.new(:test2).root
			r[:a].v.should == ""
			
			r.og_engine.close
			Engine.delete :test2
		end
		
		before :each do
			CONFIG[:directory] = "#{File.dirname __FILE__}/data"
			Engine.delete :test
			@r = Engine.new(:test).root
		end
		
		after :each do
			@r.close
			Engine.delete :test
		end
	end
end
