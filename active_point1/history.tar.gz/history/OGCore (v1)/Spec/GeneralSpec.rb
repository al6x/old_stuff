require 'OGCore/require'
require 'spec'
require "#{File.dirname(__FILE__)}/timer"

module OGCore
	describe "General" do	
		class SimpleEntity
			inherit Entity
			attr_accessor :name, :value
			
			def initialize name = nil, value = nil
				super()
				self.name, self.value = name, value
			end
		end									
		
		it "Write & Read" do		
			@r[:key].should be_nil
			copy = @r.copy
			copy.is_a?(Entity).should be_true
			copy[:key] = :value
			@r[:key].should be_nil
			@r.commit		
			@r[:key].should == :value
		end
		
		it "Should return used transaction in commit" do			
			copy = @r.copy
			t = copy.commit
			t.copies.size.should == 1					
		end
		
		it "New entities should use object_id instead of nil (from error)" do
			e = SimpleEntity.new
			e.og_id.should == e.object_id 
		end
		
		it "Copy and Entity can be used as Hash keys (from error)" do
			a = SimpleEntity.new
			a.og_id = 1
			b = SimpleEntity.new
			b.og_id = 1
			a.should == b
			{a => 1}.should == {b => 1}
		end
		
		it "Insert two new objects" do		
			@r[:key].should be_nil
			copy = @r.copy			
			
			o2 = SimpleEntity.new :o2
			o1= SimpleEntity.new :o1, o2
			copy[:key] = o1
			copy.commit
			
			@r[:key].value.name.should == :o2
		end
		
		it "Should correct restore og_id and object_manager after loading" do			
			Engine.delete :test2
			om = Engine.new(:test2).root
			
			copy = om.copy						
			o2 = SimpleEntity.new :o2
			o1= SimpleEntity.new :o1, o2
			copy[:key] = o1
			copy.commit
			
			om.close
			
			e = Engine.new(:test2)
			om = e.root
			om[:key].value.og_id.should_not be_nil
			om[:key].value.og_engine.should equal(e)
			
			om.close
			Engine.delete :test2
		end
		
		class PCollection < Array
			inherit Entity
		end
		it "Should correct restore og_id and object_manager on Collection after loading" do			
			Engine.delete :test2
			om = Engine.new(:test2).root
			
			copy = om.copy						
			pc = PCollection.new
			pc[0] = 1
			copy[:key] = pc
			copy.commit
			
			om.close
			
			e = Engine.new(:test2)
			om = e.root
			om.og_id.should_not be_nil
			om.og_engine.should equal(e)									
			om[:key].og_id.should_not be_nil
			om[:key].og_engine.should equal(e)
			om[:key][0].should == 1
			
			om.close
			Engine.delete :test2
		end
		
		it "Should correct initialize managed object" do		
			c = @r.copy
			o = SimpleEntity.new
			c[:o] = o
			@r.commit
			o.og_engine.should_not be_nil
		end
		
		it "Rollback" do
			c = @r.copy
			c[:key] = :value
			@r.rollback
			@r.commit
			@r[:key].should be_nil
		end
		
		it "Should correct copy Inner Objects" do
			c = @r.copy
			c[:key] = SimpleEntity.new :name, []
			@r.commit
			
			c = @r[:key].copy
			c.value << 1
			c.rollback
			@r.commit
			@r[:key].value.size.should == 0
		end
		
		it "Arrays" do
			o = SimpleEntity.new('name')
			c = @r.copy
			c[:key] = ['a', o]
			@r.commit
			@r[:key].should == ['a', o]
		end
		
		it "Multiarrays" do
			o = SimpleEntity.new('name')
			c = @r.copy
			c[:key] = [['a', o]]
			@r.commit
			@r[:key].should == [['a', o]]
		end
		
		it "Hashes" do
			o = SimpleEntity.new('name')
			c = @r.copy
			c[:key] = {1 => 'a', 2 => o}
			@r.commit
			@r[:key].should == {1 => 'a', 2 => o}
		end
		
		it "Multihashes" do
			o = SimpleEntity.new('name')
			c = @r.copy
			c[:key] = {1 => {1 => 'a', 2 => o}}
			@r.commit
			@r[:key].should == {1 => {1 => 'a', 2 => o}}
		end
		
#		it "OUTDATED The 'copy' should raise Error if object isn't managed" do
#			o = SimpleEntity.new
#			lambda {
#				o.copy
#			}.should raise_error(RuntimeError, /Cannot copy Not Managed Object!/)
#		end
		
		it "The 'copy' should return self if object isn't managed" do
			o = SimpleEntity.new
			o.copy.should equal(o)
		end
		
		#		it "Shouldn't allow more than one copy per one transaction" do
		# 		Temporary disabled						
		#			@r.copy			
		#			lambda{@r.copy}.should raise_error
		#			
		#			mock = mock("Done")
		#			mock.should_receive :done
		#			t = Thread.new do
		#				@r.copy		
		#				mock.done
		#			end
		#			t.join
		#			@r.rollback
		#			@r.copy
		#		end
		
		it "Should always return the same copy per one transaction" do
			c1 = @r.copy			
			c2 = @r.copy
			c3 = c1.copy
			c1.should equal(c2)
			c1.should equal(c2)
			
			t = Thread.new{Thread.current[:c4] = @r.copy}
			t.join
			t[:c4].should_not equal(c1)
			t[:c4].should_not be_nil
			
			@r.rollback
			c5 = @r.copy
			c1.should_not equal(c5)
		end				
		
		#		it "unsynchronized_objects" do
		#            
		#			@r.unsynchronized_objects.should == {}
		#			@r[:key] = :value
		#			@r.unsynchronized_objects.keys.should == [@r]
		#		end
		
		it "Should not allow to start two the same simultaneously" do
			og = Engine.new(:same_time).root
			lambda {
				Engine.new(:same_time)
			}.should raise_error
			og.close
			Engine.delete :same_time
		end
		
		it "Should correct save cycle references" do			
			copy = @r.copy			
			copy[:key] = SimpleEntity.new :name, @r
			@r.commit		
			
			a = SimpleEntity.new :name
			b = SimpleEntity.new :name, a
			a.value = b
			
			copy = @r.copy			
			copy[:key2] = a
			@r.commit		
		end	
		
		it "collect_garbage" do		
			c = @r.copy
			e1 = SimpleEntity.new :e1
			e1.value = SimpleEntity.new :e2
			c[:key] = e1            
			@r.commit
			
			c = e1.copy
			c.value = nil
			@r.commit
			
			hstorage = @r.og_engine.instance_variable_get "@hash_storage"
			hstorage.size.should == 3
			@r.og_engine.collect_garbage		
			hstorage.size.should == 2
		end
		
		class CircularDependency
			inherit Entity
			attr_accessor :parent
		end
		
		it "Should correct save and restore circullar dependensies" do
			Engine.delete :circullar_dependencies
			r = Engine.new(:circullar_dependencies).root
			c = r.copy
			d = CircularDependency.new
			c[:d] = d
			d.parent = r
			c.commit
			r.close
			
			r = Engine.new(:circullar_dependencies).root
			r[:d].parent.og_id.should == r.og_id
			
			r.close
			Engine.delete :circullar_dependencies
		end
		
		it "Should be properly initialized (case from error)" do
			Engine.delete :initialization
			r = Engine.new(:initialization).root
			r.og_id.should == 1                        
			
			c = r.copy
			c[1] = SimpleEntity.new
			c.commit
			c[1].og_id.should == 2
			
			c = r.copy
			c[1] = SimpleEntity.new
			c.commit
			c[1].og_id.should == 3
			r.close
			Engine.delete :initialization
		end
		
		it "Repository Copy assigned to Entity.og_engine instead of Original Repository (from error)" do			
			copy = @r.copy			
			copy[:e] = SimpleEntity.new
			copy.commit # Should be processed in Original Repository not in Repository Copy!		
			@r[:e].og_engine.object_id.should == @r.og_engine.object_id
		end
		
		before :each do
			CONFIG[:directory] = "#{File.dirname __FILE__}/data"
			Engine.delete :test
			@r = Engine.new(:test).root
		end
		
		after :each do
			@r.close
			Engine.delete :test
		end		
	end
end
