require 'OGCore/require'
require 'spec'

module OGCore
	describe "GarbageCollector" do
		it "GarbageCollector" do
			og = mock("Repository")						
			Engine::GarbageCollector.new(og, 1)
			og.should_receive :collect_garbage
			sleep 2
		end
	end
end
