require 'OGCore/require'
require 'MicroContainer/require'
require 'spec'

module DeclarativeStrategy
	describe "DeclarativeStrategy" do
		Transactional = OGCore::Transaction::MicroContainerDeclarativeStrategy::Transactional
		Engine = OGCore::Engine
		
		class SimpleEntity
			inherit OGCore::Entity
			attr_accessor :value
		end
		
		before :each do            
			OGCore::CONFIG[:directory] = "#{File.dirname __FILE__}/data"
			OGCore::CONFIG[:transaction_strategy] = OGCore::Transaction::MicroContainerDeclarativeStrategy::StrategyAdapter
			Engine.delete :test
			OGCore::Transaction::MicroContainerDeclarativeStrategy::SessionTransactions.scope :session
			@r = Engine.new(:test).root
			
			t = OGCore::Transaction::Transaction.new
			c = @r.copy t
			c[:one] = SimpleEntity.new
			c[:two] = SimpleEntity.new
			c.commit t                        
		end
		
		after :each do
			@r.close
			Engine.delete :test
		end
		
		it "Shouldn't interfere with explicit transaction management" do            
			t = OGCore::Transaction::Transaction.new
			c = @r.copy t
			c[:value1] = SimpleEntity.new
			c[:value2] = SimpleEntity.new
			c.commit t
			
			@r[:value1].should_not be_nil
			@r[:value2].should_not be_nil            
		end
		
		class TransactionalMethod
			inherit Transactional
			
			def transactional_method r
				c = r.copy
				c[:value] = true
			end
			transactional :transactional_method                        
		end
		
		it "Transactional method" do                                   
			@r[:value].should be_nil
			service = TransactionalMethod.new
			MicroContainer::ScopeManager.activate_thread :session_id do                                
				service.transactional_method @r          
			end            
			@r[:value].should be_true            
		end
		
		it "Static Transactional method" do                                   
			@r[:value].should be_nil
			MicroContainer::ScopeManager.activate_thread :session_id do                                
				Transactional.transaction{@r.copy[:value] = "value"}
				Transactional.commit
			end            
			@r[:value].should == "value"
		end
		
		class LongTransaction
			inherit Transactional
			
			def transaction_begin r
				c = r[:one].copy
				c.value = "value one"
			end
			transaction :begin, :transaction_begin, :t_name
			
			def transaction_join r
				c = r[:two].copy
				c.value = "value two"
			end
			transaction :join_begin, :transaction_join, :t_name
			
			
			def transaction_commit                
			end
			transaction :commit, :transaction_commit, :t_name
		end
		
		it "Long transaction, during multiple requests" do            
			service = LongTransaction.new
			
			MicroContainer::ScopeManager.activate_thread :session_id do                                
				service.transaction_begin @r
			end            
			MicroContainer::ScopeManager.activate_thread :session_id do                
				service.transaction_join @r
			end            
			MicroContainer::ScopeManager.activate_thread :session_id do                
				service.transaction_commit
			end
			
			[@r[:one].value, @r[:two].value].should == ["value one", "value two"]                        
		end
		
		class NotTransactional                        
			def not_transactional r
				c = r[:one].copy
			end
		end
		
		it "Should raise error if transaction isn't active" do
			o = NotTransactional.new
			MicroContainer::ScopeManager.activate_thread :session_id do                                
				lambda{o.not_transactional @r}.should raise_error
			end
		end
		
		class TwoTransaction            
			inherit Transactional
			
			def transaction_a r
				r[:one].copy.value = true
			end
			transaction :begin, :transaction_a, :a
			
			def transaction_b r
				r[:two].copy.value = true
			end
			transaction :begin, :transaction_b, :b
			
			def commit_a
				
			end
			transaction :commit, :commit_a, :a
			
			def commit_b
				
			end
			transaction :commit, :commit_b, :b
		end
		
		it "Two simultaneous transactions" do
			o = TwoTransaction.new
			MicroContainer::ScopeManager.activate_thread :session_id do                                
				o.transaction_a @r
				o.transaction_b @r
				o.commit_a
				@r[:one].value.should be_true
				@r[:two].value.should be_nil
				o.commit_b
				@r[:two].value.should be_true
			end
		end
		
		class RollbackByException
			inherit Transactional
			
			def throw_exception r
				r[:one].copy.value = true
				raise
			end
			transaction :begin, :throw_exception
			
			def commit
				
			end
			transaction :commit, :commit
		end
		
		it "Exception during transaction should cause rollback" do
			o = RollbackByException.new
			MicroContainer::ScopeManager.activate_thread :session_id do                                
				lambda{o.throw_exception @r}.should raise_error
				o.commit
				@r[:one].value.should be_nil
			end
		end
		
		class ShouldClearTransaction		
			inherit Transactional
			
			def first_transaction r
				@copy = r.copy
				@copy[:a] = 1
			end
			
			def second_transaction
				@copy[:a] = 2
			end
			
			transactional :first_transaction, :second_transaction
		end
		
		it "Should clear transaction after commit" do
			o = ShouldClearTransaction.new
			MicroContainer::ScopeManager.activate_thread :session_id do
				@r[:a].should == nil
				o.first_transaction @r
				@r[:a].should == 1
				o.second_transaction 
				@r[:a].should == 1
			end						
		end
		
		class NestedTransactions
			inherit Transactional
			
			def first_transaction r
				c = r.copy
				c[:a] = :a				
				return c
			end
			transaction :join_begin, :first_transaction
			
			def second_transaction c
				c[:b] = :b 
			end
			transaction :join_begin, :second_transaction
			
			def first_commit; end
			transaction :join_commit, :first_commit
			
			def second_commit; end
			transaction :join_commit, :second_commit
		end
		
		it "Nested transactions should work as joined commit" do
			o = NestedTransactions.new
			MicroContainer::ScopeManager.activate_thread :session_id do
				c = o.first_transaction @r
				o.second_transaction c
				o.first_commit
				@r[:b].should == nil
				o.second_commit
				[@r[:a], @r[:b]].should == [:a, :b]
			end
		end
		
		class CustomScope
			inherit Transactional
			
			def m r
				r.copy[:a] = :a
			end
			transactional :m
		end
		
		it "Custom transaction scope" do
			OGCore::Transaction::MicroContainerDeclarativeStrategy::SessionTransactions.scope :object			
			MicroContainer::ScopeManager.activate_thread :session_id do
				lambda{@r.copy}.should raise_error
				
				MicroContainer::Scope.begin :object
				o = CustomScope.new
				o.m @r
				
				@r[:a].should == :a
			end
		end
	end
end