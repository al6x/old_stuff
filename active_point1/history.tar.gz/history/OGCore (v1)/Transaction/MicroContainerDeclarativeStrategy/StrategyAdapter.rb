class StrategyAdapter    
    attr_reader :engine
    
    def initialize engine
        @engine = engine
        MicroContainer::Scope.register StrategyAdapter, :application
        MicroContainer::Scope[StrategyAdapter] = self
    end
    
    def active_transaction_for_copy; 
        MicroContainer::Scope[SessionTransactions].active_transaction_for_copy
    end
    
    def active_transaction_for_commit; 
        raise "Invalid usage, it should never be called!"
    end
    
    def after_commit; end
    
    def after_rollback; end
    
    def outdated_exception; end
end