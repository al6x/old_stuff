class SessionTransactions
	extend MicroContainer::Managed    
	#	scope :session
	
	attr_accessor :active_transaction
	
	class Pair
		attr_accessor :transaction, :nesting
		
		def initialize t, n
			@transaction, @nesting = t, n
		end
	end
	
	def initialize
		@transactions = {}
	end			
	
	def transaction mode, name
		case mode
			when :begin
			@transactions[name] = Pair.new CONFIG[:transaction].new, 0
			when :join_begin
			if @transactions.include? name
				@transactions[name].nesting += 1
			else
				transaction :begin, name
			end
			when :commit
			if pair = @transactions[name]
				strategy_adapter = MicroContainer::Scope[StrategyAdapter]
				strategy_adapter.engine.engine_commit pair.transaction
			end
			when :join_commit
			if pair = @transactions[name]
				if pair.nesting == 0
					strategy_adapter = MicroContainer::Scope[StrategyAdapter]
					strategy_adapter.engine.engine_commit pair.transaction
				else
					pair.nesting -= 1
				end
			end
			when :rollback
			@transactions.delete name
		else
			raise "Invalid transaction Mode '#{mode}'!"
		end
	end
	
	
	#	def transaction_begin name
	#		@transactions[name] = Pair.new CONFIG[:transaction].new, 0                    
	#	end
	#	
	#	def transaction_join_begin name
	#		if @transactions.include? name
	#			@transactions[name].nesting += 1
	#		else
	#			transaction_begin name
	#		end		
	#	end
	#	
	#	def transaction_commit name		
	#		if pair = @transactions[name]
	#			strategy_adapter = MicroContainer::Scope[StrategyAdapter]
	#			strategy_adapter.engine.engine_commit pair.transaction
	#		end
	#	end
	#	
	#	def transaction_join_commit name		
	#		if pair = @transactions[name]
	#			if pair.nesting == 0
	#				strategy_adapter = MicroContainer::Scope[StrategyAdapter]
	#				strategy_adapter.engine.engine_commit pair.transaction
	#			else
	#				pair.nesting -= 1
	#			end
	#		end
	#	end		
	#	
	#	def transaction_rollback name
	#		@transactions.delete name
	#	end
	
	def active_transaction_for_copy
		if active_transaction
			@transactions[active_transaction].transaction
		else
			raise "Transaction isn't started!"
		end            
	end
end