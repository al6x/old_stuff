module Transactional
	def _transactional_wrapper mode, name, method_name, *p, &b
		session_transactions = MicroContainer::Scope[
		OGCore::Transaction::MicroContainerDeclarativeStrategy::SessionTransactions
		]
		session_transactions.active_transaction = name 		
		begin             
			session_transactions.transaction mode, name if mode == :begin or mode == :join_begin
			result = send method_name, *p, &b
			
			# Need this if _transactional_wrapper will be nested
			session_transactions.active_transaction = name
			
			session_transactions.transaction mode, name if mode == :commit or mode == :join_commit
			return result
		rescue Exception => e
			session_transactions.transaction :rollback, name
			raise e
		ensure
			session_transactions.active_transaction = nil
		end
	end		
	
	module ClassMethods
		def transactional *methods
			methods.each do |method|				
				transaction :begin, method, :transactional_method
				transaction :commit, method, :transactional_method
			end
		end
		
		# mode = [:begin | :join_begin | :join_commit | :commit]
		def transaction mode, method, name = :default_name
			raise "Method name should be a Symbol!" unless method.is_a? Symbol
			raise "Transaction name should be a Symbol!" unless name.is_a? Symbol
			raise "Invalid Mode!" unless [:begin, :join_begin, :commit, :join_commit].include? mode
			
			old_method = :"transaction_#{mode}_for_#{method}"       
			
			script = %{\
def #{method} *p, &b
	_transactional_wrapper :#{mode}, :#{name}, :#{old_method}, *p, &b
end}                                                                     
			
			self.class_eval{alias_method old_method, :"#{method}"}
			self.class_eval script, __FILE__, __LINE__				
		end
	end
	
	class << self
		include Transactional
		extend ClassMethods
		def transaction &b; b.call end				
		transaction :join_begin, :transaction
		
		def commit;end				
		transaction :commit, :commit
	end					
end
