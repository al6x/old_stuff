class Transaction
	attr_reader :copies, :originals
	
	def initialize; @copies, @originals = {}, {} end
	
	def add copy, original
		if @copies.include? original
			raise "It's forbiden to have more than one copy of the same entity per transaction!" 
		end
		
		@copies[original] = copy
		@originals[original] = original
	end
	
	def new
		new_entities = []
		copies.each do |original, copy|
			AnEntity::Helper.each_entity copy do |e|
				if e.managed?
					false
				else
					new_entities << e
					true
				end
			end
		end
		return new_entities
	end
end