class OneTransactionPerThreadStrategy
    include MonitorMixin        
    
    def initialize engine; 
        super()
        @key = "#{self.class.name}_#{self.object_id}"
    end
    
    def active_transaction_for_copy; 
        synchronize do
            t = Thread.current[@key]
            unless t
                t = CONFIG[:transaction].new
                Thread.current[@key] = t
            end
            t
        end
    end
    
    def active_transaction_for_commit; 
        synchronize do
            Thread.current[@key]
        end
    end
    
    def after_commit
        synchronize do
            Thread.current[@key] = nil
        end
    end
    
    def after_rollback; 
        synchronize do
            Thread.current[@key] = nil
        end
    end
    
    def outdated_exception outdated
        synchronize do
            Thread.current[@key] = nil
        end
    end
end