class Repository < Hash    
	include Entity
	
#	def initialize params = nil		
#		super()		
#		return unless params # empty constructor to match Entity specification		
#		self.og_engine = Engine.new self, params						
#	end			
#	
#	def isolate &b; og_engine.isolate &b end								
#	def stream_metadata_put id, metadata; og_engine.metadata_put id, metadata end	
#	def stream_metadata_read id; og_engine.metadata_read id end	
#	def stream_size id; og_engine.stream_size id end	
#	def stream_put data = nil, &block; og_engine.stream_put data, &block end	
#	def stream_read id, &block; og_engine.stream_read id, &block end	
#	def stream_read_each id, &block; og_engine.stream_read_each id, &block end		
#	def self.delete name, path = CONFIG[:directory]; Engine.delete name, path end	
#	def close; og_engine.close end
end
