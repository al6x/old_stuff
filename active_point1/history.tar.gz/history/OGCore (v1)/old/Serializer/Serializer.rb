require 'yaml'

class Serializer
	SERIALIZER = eval(CONFIG[:serializer]) || YAML
	
	def initialize storage, object_graph; 
		@storage, @object_graph = storage, object_graph
		
		check_and_initialize @object_graph
		root = load_object 'root'
		copy_to_originals [root], {root.og_id => @object_graph}	
		@object_graph.object_graph = @object_graph
		
		@garbage_collector = GarbageCollector.new self, CONFIG[:garbage_collector_pause] || 3600		
	end
	
	def commit copies, originals
		to_save, processed, id_to_object = {}, [], {}
		copies.each do |copy| 
			save_object(to_save, copy, processed, id_to_object)
        end
		@storage.atomic_write to_save
		
		# Should restore links on copies and new objects
		restore_links(processed){|og_id| id_to_object[og_id]}
						
		copy_to_originals copies, originals		
    end		
	
	def collect_garbage		
		memory = Set.new
		ObjectSpace.each_object(PersistentMarker){|p| memory.add p.og_id}
		@storage.objects_ids.each do |id|
			@storage.delete id unless memory.include? id
        end
		
		memory = Set.new
		ObjectSpace.each_object(Stream){|s| memory.add s.stream_id}
		@storage.streams_ids.each do |id|
			@storage.delete_stream id unless memory.include? id
        end
    end		
	
	
		
	def close
		@garbage_collector.kill
    end
	
	protected
	def restore_links objects, processed = [], ids = nil, &id_to_object		
		objects.each_with_index do |o, index|
			if o.is_a? PersistentMarker
				ObjectHelper.each o, processed, [PersistentMarker] do |attribute, writer|
					writer.write id_to_object.call(attribute.og_id) if attribute.is_a? ID				
					writer.write @storage if attribute.class == Stream::StorageMarker
				end
				o.object_graph = @object_graph unless o.object_graph
				o.og_id = ids[index] unless o.og_id
            end
        end
    end
	
	# It also should find all references to 'copy' and changes it to references to 'original'
	def copy_to_originals copies, originals
		processed = []
		copies.each do |copy|
			original = originals[copy.og_id]
			ObjectHelper.each copy, processed, [PersistentMarker]  do |attribute, writer|											
				#				if attribute.is_a?(PersistentMarker) and originals.include?(attribute.og_id) # Change references from to_copy
				#					writer.write_to(original, originals[attribute.og_id]) # to to_original
				#				else
				writer.write_to(original, attribute)
				#				end
			end
        end
    end
	
	def check_and_initialize object_graph
		begin
			@storage['root']
        rescue NotFound		
			to_save = {}
			object_graph.og_id = 'root'
			object_graph.object_graph = object_graph
			save_object to_save, object_graph, [], {}				
			@storage.atomic_write to_save
		end
    end
	
	def load_object id, processed = []
		object = Serializer.load @storage[id]
		restore_links([object], processed, [id]){|og_id| load_object og_id, processed}    
		return object
    end
	
	def save_object to_save, object, processed, id_to_object		
		# Break links
		ObjectHelper.each object, processed, [PersistentMarker] do |attribute, writer|
			if attribute.is_a? PersistentMarker
				unless attribute.og_id
					attribute.og_id = @storage.generate_id 					
					save_object to_save, attribute, processed, id_to_object
                end
				id_to_object[attribute.og_id] = attribute				
				writer.write ID.new(attribute.og_id)				
            end
			
			if attribute.class == ObjectGraph::STORAGE_CLASS
				writer.write Stream::STORAGE_MARKER
			end
        end										
		to_save[object.og_id] = Serializer.dump object
    end
	
	# Because YAML doesn't save custom attributes on Array and Hash
	class CollectionWrapper
		include Persistent
		attr_accessor :collection
    end
	
	PRELOADED_TYPES = %w{object hash map array seq}
	def self.load_classes_for doc, processed = []
		return if !doc or processed.include?(doc)
		processed << doc
		
		return unless doc.type_id
			
		info = doc.type_id.split(':', 4) 
		type, klass = info[2], info[3]
		eval(klass, TOPLEVEL_BINDING) if PRELOADED_TYPES.include? type
		if doc.value.is_a? Hash			
			doc.value.each { |k,v|
				load_classes_for v, processed
			}
		elsif doc.value.is_a? Array
			doc.value.each { |v|
				load_classes_for v, processed
			}		
		else	
#			raise
		end		
	end
	

	
	def self.load data		
		doc = SERIALIZER.parse data
		load_classes_for doc
		o = doc.transform
		if o.is_a? CollectionWrapper
			new = o.collection
			new.og_id, new.object_graph = o.og_id, o.object_graph
			return new
        else
			return o
		end
    end
	
	def self.dump o		
		if o.is_a?(Array) or o.is_a?(Hash)
			new = CollectionWrapper.new
			new.collection = o
			new.og_id, new.object_graph = o.og_id, o.object_graph
			SERIALIZER.dump new
		else
			SERIALIZER.dump o
        end		
    end
end