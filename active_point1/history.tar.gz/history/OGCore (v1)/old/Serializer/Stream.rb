class Stream
	attr_reader :stream_id, :name, :extension, :size
	attr_writer :storage
		
	def initialize stream_id, name, extension, size
		@stream_id, @name, @extension, @size = stream_id, name, extension, size
	end
		
	def read &block
		return @storage.read(@stream_id, &block)
	end
	
	def each &block
		@storage.read_each(@stream_id, &block)
    end
end