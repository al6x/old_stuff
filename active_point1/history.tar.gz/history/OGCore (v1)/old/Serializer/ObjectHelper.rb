class ObjectHelper		
#	def initialize object, object_graph
#		@object, @object_graph = object, object_graph
#    end
#	
#	def restore_links processed, &block
#		ObjectHelper.each @object, processed  do |attribute, writer|							
#			writer.write block.call(attribute.og_id) if attribute.is_a? ID
#        end
#		@object.object_graph = @object_graph
#    end
#	
#	def copy_to original, processed
#		processed = ObjectHelper.each @object, processed  do |attribute, writer|							
#			writer.write_to(original, attribute)
#        end
#    end
		
	SIMPLE_TYPES = [Fixnum, Bignum, Date, Float, NilClass, String,	Symbol, FalseClass, TrueClass, Class, Proc].to_set		
	DO_NOT_CLONE = [Fixnum,Bignum,Float,NilClass,FalseClass, TrueClass, Symbol].to_set
	
	def self.each o, processed, pass_by = nil, first_call = true, &block						
		return if processed.include? o
		return if !first_call and pass_by and pass_by.any?{|klass| o.is_a? klass}
		return if SIMPLE_TYPES.include?(o.class)				
		
		processed << o
		
		if o.is_a?(Array)
			writer = CollectionWriter.new o
			o.each_with_index do |value, index|
				writer.index = index
				block.call value, writer
				each value, processed, pass_by, false, &block
            end
		elsif o.is_a?(Hash)
			writer = CollectionWriter.new o
			o.each do |key, value|
				writer.index = key
				block.call value, writer
				each value, processed, pass_by, false, &block
            end
		else # Object
			writer = ObjectWriter.new o
			o.instance_variables.each do |name|
				writer.attribute = name
				value = o.instance_variable_get(name)
				block.call value, writer
				each value, processed, pass_by, false, &block
            end
		end
		
		return processed
    end
	
	class CollectionWriter
		def initialize collection; @collection = collection end
		
		def index= index; @index = index end
		
		def write value; 
			@collection[@index] = value
        end
		
		def write_to collection, value; collection[@index] = value end
		
		def read_from collection; collection[@index] end
		
		def to_s; "[#{@index}]" end
    end
	
	class ObjectWriter
		def initialize object; @object = object end
		
		def attribute= attribute; @attribute = attribute end
		
		def write value; 
			@object.instance_variable_set(@attribute, value)
        end
		
		def write_to object, value; object.instance_variable_set(@attribute, value) end
		
		def read_from object; object.instance_variable_get(@attribute) end
		
		def to_s; "@#{@attribute}" end
    end
end