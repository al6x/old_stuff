class CopyManager
	attr_reader :originals
	
	def initialize
		@copies, @originals, @per_thread = {}, {}, {}
	end
	
	def has_copy? copy
		per_thread = @per_thread[Thread.current]
		return (per_thread and per_thread.include?(copy.og_id))
    end
		
	def delete for_delete
		for_delete.each do |d|
			@copies.delete d.og_id
			original = @originals.delete d.og_id
			original.og_copy, original.og_thread = nil, nil if original.is_a? EPersistent
			@per_thread[Thread.current].delete d.og_id
        end		
		@per_thread.delete Thread.current if @per_thread[Thread.current].empty?
    end
		
	def copy object					
		if @copies.include? object.og_id
			raise DuplicateCopy, "Object '#{object.og_id}' is already reserved for write!", caller(6)
		end
		
		copy = object.clone
		Serializer::ObjectHelper.each object, [], [Serializer::PersistentMarker] do |attribute, writer|
			unless Serializer::ObjectHelper::DO_NOT_CLONE.include? attribute.class 
				writer.write_to(copy, attribute.clone)
            end
		end		
		
		@copies[copy.og_id] = copy
		@originals[copy.og_id] = object
		
		@per_thread[Thread.current] ||= {}
		@per_thread[Thread.current][copy.og_id] = copy
				
		object.og_copy, object.og_thread = copy, Thread.current if object.is_a? EPersistent        
		
		return copy
    end	
	
	def copies_per_thread
		per_thread = @per_thread[Thread.current]
		return per_thread ? per_thread.values : nil
    end
end