class DuplicateCopy < RuntimeError
	
end