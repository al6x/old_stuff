require 'monitor'
module EPersistent
	include Serializer::PersistentMarker
	attr_accessor :og_id, :object_graph, :og_copy, :og_thread
	
	
	def copy
		raise RuntimeError, "Cannot copy Not Managed Object!", caller unless object_graph
		object_graph.copy_object self
	end
	
	def commit
		object_graph.commit @og_copy
	end
	
	def rollback
		object_graph.rollback @og_copy
	end				
	
	def after_commit
		
	end
	
	def to_yaml_properties; instance_variables - %w{@object_graph @og_copy @og_thread} end
	
	def self.included(klass) 
		klass.extend(ClassMethods)
	end
	
	module ClassMethods
		def transient *names
			raise "Transient properties cannot be empty" if names.size == 0
			transient = names.collect{|n| "@#{n}"}.join(' ')
			
			class_eval(%{\
def to_yaml_properties
	super - %w{#{transient}}
end}, __FILE__, __LINE__)	
		end		
		
		def attr_accessor *names
			raise "Names cannot be empty" if names.size == 0
			names.each do |name|
				class_eval(%{\
def get_#{name}; @#{name} end

def #{name}
	if @og_copy and @og_thread == Thread.current
		@og_copy.instance_variable_get "@#{name}"
	else
		@#{name}
	end
end		

def #{name}= value
	if @og_copy and @og_thread == Thread.current
		@og_copy.instance_variable_set "@#{name}", value 
	elsif !@object_graph
		@#{name} = value
	else 
		raise RuntimeError, "Can't directly modify managed object!", caller
	end
end}, __FILE__, __LINE__)
			end
		end
	end
end