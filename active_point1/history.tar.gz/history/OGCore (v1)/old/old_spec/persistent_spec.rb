require 'ObjectGraph/scripts/require'
require 'spec'

module ObjectGraph
	describe "Persistent" do
		it "Add ability to make Arrays and Hashes as Persistent objects" do
#			lambda do
				class PersistentArraySpec < Array
					include Persistent
#					persistent :a
				end
#			end.should raise_error(RuntimeError, /You cannot define attributes on persistent Hash or Array/)
		
#			lambda do
				class PersistentHashSpec < Hash
					include Persistent
#					persistent :a
				end
#			end.should raise_error(RuntimeError, /You cannot define attributes on persistent Hash or Array/)
		end
		
#		it "Should support full inheritance scheme" do
#			module FullOOSpecA
#				include Persistent
#				attr_accessor :a
#            end
#			
#			class FullOOSpecB
#				include Persistent
#				attr_accessor :b
#            end
#			
#			class FullOOSpecC < FullOOSpecB
#				include FullOOSpecA				
#            end
#			
#			FullOOSpecC.instance_variables.size.should == 2
#			
#			class FullOOSpecC
#				attr_accessor :c
#            end						
#			
#			FullOOSpecC.instance_variables.size.should == 3
#			
#			module FullOOSpecD
#				include Persistent
#				attr_accessor :d
#            end
#			
#			class FullOOSpecC
#				include FullOOSpecD				
#            end
#			
#			FullOOSpecC.instance_variables.size.should == 4
#			
#			module FullOOSpecA
#				attr_accessor :a2
#            end
#			
#			FullOOSpecC.instance_variables.size.should == 5
#        end
	
#		it "Should not define attributes" do
#			class DefineAttributesIfNotDefined
#				include Persistent			
#				persistent :a
#			end
#		
#			o = DefineAttributesIfNotDefined.new
#			o.respond_to?(:a).should be_false
#			o.respond_to?(:a=).should be_false
#			DefineAttributesIfNotDefined.persistent.size.should == 1
#		end								
		
		#	it "Should provide virtual 'open_<attr_with_binary_data_id> do end' method." do
		#		class VirtualMethodForBinaryData
		#			include Persistent
		#			persistent :film
		#        end
		#		
		#		o = VirtualMethodForBinaryData.new
		#		o.film = nil
		#		lambda do
		#			o.open_film do |film|
		#				
		#			end
		#		end.should raise_error(/The 'id' for the 'film' is not defined!/)
		#    end

		#		it "Equal & Hash should works correctly" do
		#			class EqualityAndHashSpec
		#				include Persistent
		#				attr_accessor :simple, :array, :hash, :reference
		#				
		#				persistent :simple, :array, :hash, :reference
		#			end
		#		
		#			io = EqualityAndHashSpec.new
		#		
		#			o = EqualityAndHashSpec.new
		#			o.simple, o.array, o.hash, o.reference = 'String', ['Array'], {:key => :value}, io
		#		
		#			o2 = EqualityAndHashSpec.new
		#			o2.simple, o2.array, o2.hash, o2.reference = 'String', ['Array'], {:key => :value}, io
		#		
		#			o.should == o2
		#			o.hash.should == o2.hash
		#		end			
	end
end
















