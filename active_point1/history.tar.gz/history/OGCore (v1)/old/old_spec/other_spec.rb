#		# Add it in the future
#		#	it "Shouldn't allow modify managed objects" do
#		#		lambda do
#		#			@om.value = 'value'
#		#		end.should raise_error(RuntimeError, /Can't modify managed object/)
#		#    end

it "Should correct copy references to copy in newly created objects" do
			copy = @om.copy			
			copy[:o] = SimplePersistent.new :o, copy
			@om.commit		
			
			o = @om[:o]			
			o.value.equal?(@om).should be_true
        end
		
		it "Should correct copy references to copy in managed objects" do
			copy = @om.copy			
			copy[:o] = SimplePersistent.new :o
			copy[:o2] = SimplePersistent.new :o2
			@om.commit		
			
			c1, c2 = @om[:o].copy, @om[:o2].copy
			c1.value = c2
			@om.commit
			
			o1, o2 = @om[:o], @om[:o2]
			o1.value.equal?(o2).should be_true
        end


	#	it "Should lock & release operations" do
		#		data = "Some binary data"
		#		stream = @storage.get_stream 'object_id', :stream
		#		stream.put_stream data
		#		
		#		r = mock("read_streamer")
		#		r.should_not_receive :finish
		#		Thread_stream.new do
		#			stream = @storage.get_stream 'object_id', :stream
		#			stream.read_stream do |s|
		#				s.read_stream(1)
		#				sleep 2
		#				r.finish
		#			end
		#		end
		#		
		#		w1 = mock("put_streamr")
		#		w1.should_not_receive :finish
		#		Thread_stream.new do
		#			stream = @storage.get_stream 'object_id', :stream
		#			stream.release # releses stream from all read_streamers (but not from put_streamrs). It internally throw an exception in
		#			# read_streamer's streams		
		#			stream.put_stream do |s|
		#				s.put_stream "New data"
		#				sleep 2
		#				w1.finish
		#            end
		#		end
		#		
		#		w2 = mock("put_streamr2")
		#		w2.should_receive :finish
		#		Thread_stream.new do
		#			stream = @storage.get_stream 'object_id', :stream
		#			stream.release! # strong form, releases from all		
		#			stream.put_stream do |s|
		#				s.put_stream "Super new data"
		#				w2.finish
		#            end
		#        end
		#		
		#		@storage.get_stream('object_id', :stream).should == "Super new data"
		#    end
		
		#	# There are 2 read_streamers and 2 put_streamrs, read_streamers should works in parallel, put_streamrs exclusivelly
		#    #                            
		#    #            4x5----8          put_streamr 2
		#    #      2x3---5                  put_streamr 1
		#    # 0-1                             read_streamer 2
		#    # 0-----3         7x8-9       read_streamer 1  
		#    # 0 1 2 3 4 5 6 7 8 9        timeline
		#	# 
		#	it "read_streamers should works in parralel put_streamrs exclusivelly" do
		#		@storage.get_stream('object_id', :stream).put_stream "Data"				
		#		
		#		timer = Timer.new
		#		
		#		r1 = mock("read_streamer 1")
		#		r1.should_receive(:created).with(0)
		#		r1.should_receive(:start).with(0)
		#		r1.should_receive(:finish).with(3)						
		#		Thread_stream.new do
		#			stream = @storage.get_stream 'object_id', :stream
		#			
		#			r1.created timer.time
		#			stream.read_stream do
		#				r1.start timer.time
		#				sleep 3
		#				r1.finish timer.time
		#			end
		#		end
		#
		#		r2 = mock("read_streamer 2")
		#		r2.should_receive(:created).with(0)
		#		r2.should_receive(:start).with(0)
		#		r2.should_receive(:finish).with(1)						
		#		Thread_stream.new do
		#			stream = @storage.get_stream 'object_id', :stream
		#			
		#			r2.created timer.time
		#			stream.read_stream do
		#				r2.start timer.time
		#				sleep 1
		#				r2.finish timer.time
		#			end
		#		end
		#
		#		sleep 2
		#
		#		w1 = mock("put_streamr 1")
		#		w1.should_receive(:created).with(2)
		#		w1.should_receive(:start).with(3)
		#		w1.should_receive(:finish).with(5)						
		#		Thread_stream.new do
		#			stream = @storage.get_stream 'object_id', :stream
		#			
		#			w1.created timer.time
		#			stream.put_stream do
		#				w1.start timer.time
		#				sleep 2
		#				w1.finish timer.time
		#			end
		#		end
		#
		#		sleep 2
		#
		#		w2 = mock("put_streamr 2")
		#		w2.should_receive(:created).with(4)
		#		w2.should_receive(:start).with(5)
		#		w2.should_receive(:finish).with(8)						
		#		Thread_stream.new do
		#			stream = @storage.get_stream 'object_id', :stream
		#			
		#			w2.created timer.time
		#			stream.put_stream do
		#				w2.start timer.time
		#				sleep 3
		#				w2.finish timer.time
		#			end
		#		end
		#
		#		sleep 3
		#
		#		r11 = mock("put_streamr 2")
		#		r11.should_receive(:created).with(7)
		#		r11.should_receive(:start).with(8)
		#		r11.should_receive(:finish).with(9)						
		#		Thread_stream.new do
		#			stream = @storage.get_stream 'object_id', :stream
		#			
		#			r11.created timer.time
		#			stream.read_stream do
		#				r11.start timer.time
		#				sleep 1
		#				r11.finish timer.time
		#			end
		#		end	
		#    end
	
		#	it "put_stream should be Atomic during exceptions" do
		#		@storage.get_stream('object_id', :stream).put_stream "Binary data"
		#		
		#		lambda do
		#			@storage.get_stream('object_id', :stream).put_stream do |s|
		#				s.put_stream "Other data"
		#				raise "Some error ..."
		#			end
		#		end.should raise_error(RuntimeError, /Some error .../)
		#		@storage.get_stream('object_id', :stream).read_stream.should == "Binary data"		
		#    end
	
		#	it "put_stream should be Atomic during system crash" do
		#		Storage.delete 'atomic', @dir
		#		
		#		s = Storage.new 'atomic', @dir
		#		s.get_stream('object_id', :stream).put_stream "Binary data"
		#		
		#		mock = mock("Should enter")
		#		mock.should_receive :enter
		#		t = Thread_stream.new do
		#			s = Storage.new 'atomic', @dir
		#			s.get_stream('object_id', :stream).put_stream do |s|
		#				mock.enter
		#				s.put_stream "Other data"				
		#				t.exit # System crashed		
		#			end
		#        end		
		#		
		#		s = Storage.new 'atomic', @dir
		#		s.get_stream('object_id', :stream).read_stream.shoud == "Binary data"
		#    end