require 'ObjectGraph/scripts/require'
require 'spec'

module ObjectGraph
	describe "ObjectHelper" do
		class AnObject
			include Persistent
			
			attr_accessor :a, :b
        end
		
		class AnArray < Array
			include Persistent
        end
		
		class AnHash < Hash
			include Persistent
        end
		
		it "break_links for Array" do
			
			ObjectHelper.new
        end
	end
end
