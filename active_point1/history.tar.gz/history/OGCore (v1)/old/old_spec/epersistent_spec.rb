require 'ObjectGraph/scripts/require'
require 'spec'
require "#{File.dirname(__FILE__)}/timer"

module ObjectGraph
	describe "EPersistent" do	
		class Sample
			include EPersistent
			attr_accessor :name, :value
		
			def initialize name = nil, value = nil
				super()
				self.name, self.value = name, value
			end
		end	
	
		before :each do
			Thread.abort_on_exception = true
			@dir = "#{File.dirname __FILE__}/data"
			ObjectGraph.delete :test, @dir
			@om = ObjectGraph.new :test, @dir

			copy = @om.copy							
			copy[:sample] = Sample.new :name, 'value'
			copy.commit
		end
	
		after :each do
			@om.close
			ObjectGraph.delete :test, @dir
		end		

		class AfterCommitMock
			def self.reset; @@after_commit = false end
			def self.get; @@after_commit end
			def self.after_commit; @@after_commit = true end
        end
		it "after_commit" do
			sample = @om[:sample]
						
			class << sample
				def after_commit
					AfterCommitMock.after_commit
                end
			end					
			sample.copy
			sample.value = 'new value'
			AfterCommitMock.reset
			sample.commit
			AfterCommitMock.get.should be_true
			
			sample.copy
			sample.value = 'new value'
			AfterCommitMock.reset
			@om.commit
			AfterCommitMock.get.should be_true
        end
			
		it "General test" do
			sample = @om[:sample]
			sample.copy
			sample.value = 'new value'
			sample.value.should == 'new value'
			Thread.new do
				@om[:sample].value.should == 'value'
            end
			@om.rollback
			@om.commit
			@om[:sample].value.should == 'value'
			@om[:sample].get_value.should == 'value'
		end			
		
		it "Attribute access" do
			s = Sample.new
			s.value = "new value"
			s.value.should == "new value"
			
			s = @om[:sample]
			lambda do
				s.value = "new value"
			end.should raise_error("Can't directly modify managed object!")			
        end
		
		it "General concurrency test" do
			c = @om.copy
			c[:from] = Sample.new :from, 5
			c[:to] = Sample.new :to, 0
			c.commit
						
			threads = []
			20.times do
				threads << Thread.new do					
					catch :done do
						while true do					
							@om.transaction do
								from, to = @om[:from], @om[:to]
								throw :done if from.value <= 0						
									
								sleep(rand(10) / 1000.0)								
								begin									
									from.copy; to.copy
								rescue DuplicateCopy
									next
								end															
								from.value -= 1
								to.value += 1																
								@om.commit							
							end					
						end					
					end
				end
			end
			threads.each{|t| t.join}
			
			@om[:from].value.should == 0
			@om[:to].value.should == 5
        end		
	end
end
























