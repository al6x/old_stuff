require 'ObjectGraph/scripts/require'
require 'spec'

module ObjectGraph
	describe "Stream" do
		#	it "Should provide handy methods" do
		#		class StreamSpec
		#			include Persistent
		#        end
		#		
		#		stream = mock("Stream")
		#		stream.should_receive(:read)
		#		stream.should_receive(:write)
		#		
		#		storage = mock("Storage")				
		#		storage.should_receive(:stream).and_return(stream)
		#		storage.should_receive(:stream).and_return(stream)
		#		
		#		wrapper = Stream.new(storage, StreamSpec.new, :attr)						
		#		wrapper.read
		#		wrapper.write
		#    end
	end
end