require 'ObjectGraph/scripts/require'
require 'spec'

module ObjectGraph
	define "Marshall" do
		class ShouldCorrectMarshal
			include Persistent
		
			def initialize value = nil; @value = value end
		
			persistent :value
		end
		
		it "Should correct marshal simple types" do
			o = ShouldCorrectMarshal.new "String"
		
			data = Marshall.dump o
			o1 = Marshal.load data
		
			o1.should == o
		end
	
		it "Should correct marshal object reference" do
			io = ShouldCorrectMarshal.new
			o = ShouldCorrectMarshal.new io
		
			data = Marshall.dump o
			o1 = Marshal.load data
		
			o1.value.should == ID.new(io)
		end
	
		it "Should correct marshal Arrays with simple types" do				
			o = ShouldCorrectMarshal.new ['String']
		
			data = Marshall.dump o
			o1 = Marshal.load data
		
			o1.should == o
		end
	
		it "Should correct marshal Arrays with Object References" do
			io = ShouldCorrectMarshal.new
			o = ShouldCorrectMarshal.new [io]
		
			data = Marshall.dump o
			o1 = Marshal.load data
				
			o1.value.should == ID.new(io)
		end
	
		it "Should correct marshal multidimensional Array" do
			io = ShouldCorrectMarshal.new
			o = ShouldCorrectMarshal.new ['String', [io]]
		
			data = Marshall.dump o
			o1 = Marshal.load data
		
			o1.value[0].should == 'String'
			o1.value[1][0].should == ID.new(io)
		end
	
		it "Should correct marshal Hash with simple types" do				
			o = ShouldCorrectMarshal.new('Key' => 'Value')
		
			data = Marshall.dump o
			o1 = Marshal.load data
		
			o1.should == o
		end
	
		it "Should correct marshal Hash with Object References" do
			io = ShouldCorrectMarshal.new
			o = ShouldCorrectMarshal.new( :key => io)
		
			data = Marshall.dump o
			o1 = Marshal.load data
				
			o1[:key].should == ID.new(io)
		end
	
		it "Should correct marshal multidimensional Hash" do
			io = ShouldCorrectMarshal.new
			o = ShouldCorrectMarshal.new(:k1 => 'Value', :k2 => {:k1 => io})
		
			data = Marshall.dump o
			o1 = Marshal.load data
		
			o1[:k1].should == 'String'
			o1[:k2][:k1].should == ID.new(io)
		end
		
		it "Marshalling should access attribute values directly, not via 'get/set' methods" do
			class WrapExistentAttributes
				include Persistent		
				attr_accessor :a
			
				def b; @b end			
				def b= b; @b = b end
			
				persistent :b
				
				def b; @b end			
				def b= b; @b = b end
			end
			
			o = WrapExistentAttributes.new
			o.b = 'value'
			o.a = 'a'
		
			o.should_not_receive :b
			o.should_not_receive :b=
		
			data = Serializer.dump o		
			o = Serializer.load data
			o.b.should == 'value'	
			o.a.should == nil
		end
		
		it "Should clone all Object's data but not references to other Persistent objects" do
			class CopySpec
				include Persistent
				attr_accessor :simple, :array, :multiarray, :hash, :multihash, :reference, :cycle_reference
				
				persistent :simple, :array, :multiarray, :hash, :multihash, :reference
			end
		
			class ManagerStub
				attr_accessor :objects_copies
				
				def initialize
					@objects_copies = [] # [[copy, original], ...]
                end
			end
		
			io1, io2, io3, io4, io5 = CopySpec.new, CopySpec.new, CopySpec.new, CopySpec.new, CopySpec.new
			manager = ManagerStub.new
		
			o = CopySpec.new
			o.simple, o.array, o.multiarray, o.hash, o.multihash, o.reference, o.cycle_reference = 
				"String", ['String', io1], [[io3]], {:key => :value, :key2 => io2}, {:key => {:key => io4}}, io5, o
			o.object_graph = manager
		
			o2 = o.copy
		
			manager.objects_copies[0][1].should.equal? o
			manager.objects_copies[0].should == [o2, o]
		
			#			o2.should == o2
			o2.array[1].should.equal? o.array[1]
			o2.multiarray[0][0].should.equal? o.multiarray[0][0]
			o2[:key].shuld.equal? o[:key]
			o2[:key][:key].shuld.equal? o[:key][:key]
			o2.reference.shoud.equal? o.reference				
		end
		
		it "Should copy Stream" do				
			io1 = CopySpec.new
			manager = ManagerStub.new
		
			o = CopySpec.new
			o.simple = Stream.new
			o.object_graph = manager
		
			o2 = o.copy
		
			o2.simple.should_not.equal? o.simple
		end
	end
end