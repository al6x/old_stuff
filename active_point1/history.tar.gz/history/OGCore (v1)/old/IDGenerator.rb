class IDGenerator
	include MonitorMixin
	
	def initialize dir, extension
		super()
		
		@dir, @extension = dir, extension
		list = Dir.glob(File.join(@dir, "*.#{@extension}"))
		if list.size > 0
			@last_id = File.basename(list[0]).sub(".#{@extension}", "").to_i
		else
			file = File.new(File.join(@dir, "0.#{@extension}"), "w")
			file.close
			@last_id = 0
        end
    end
	
	def generate		
		synchronize do
			File.rename(
				File.join(@dir, "#{@last_id}.#{@extension}"), File.join(@dir, "#{@last_id+1}.#{@extension}")
			)
			(@last_id += 1).to_s
		end
    end
	
	def reset
		synchronize do
			return if @last_id == 0
			File.rename File.join(@dir, "#{@last_id}.#{@extension}"), File.join(@dir, "#{0}.#{@extension}")
			@last_id = 0
		end
    end
end