# IDEA look at facets/SyncArray
# This kind of lock named as "read/write lock"
class Synchronizer
	def initialize
		@writer, @readers = nil, {}
		@monitor = Monitor.new
		@writer_condition, @readers_condition = @monitor.new_cond, @monitor.new_cond
    end			
	
	def synchronize mode, &block
		if mode == :EX
			begin
				write_start
				block.call
			ensure
				write_stop
            end
		elsif mode == :SH
			begin
				read_start
				block.call
			ensure
				read_stop
            end			
		else
			raise "Unknown mode!"
        end
    end
	
	def readers
		@monitor.synchronize do
			@readers
        end
    end
	
	def writer
		@monitor.synchronize do
			@writer
        end
    end
	
	protected	
	def read_start
		@monitor.synchronize do
			@writer_condition.wait_while{@writer}
			@readers[Thread.current] ||= 0
			@readers[Thread.current] += 1
		end
    end
	
	def read_stop					
		@monitor.synchronize do			
			if @readers[Thread.current] 
				if @readers[Thread.current] > 1
					@readers[Thread.current] -= 1
				else
					@readers.delete Thread.current
					@readers_condition.signal
				end				
            end
			@writer_condition.signal # This one is really needed, becouse 'signal' isn't broadcast
		end
    end
	
	def write_start				
		@monitor.synchronize do
			@readers.delete Thread.current if @readers.include?(Thread.current)
			@readers_condition.signal
			
			@writer_condition.wait_while{@writer}
			@writer = Thread.current			
			
			@readers_condition.wait_until{@readers.empty?}			
		end
    end
	
	def write_stop			
		@monitor.synchronize do
			@writer = nil
			@writer_condition.signal
			@readers_condition.signal # This one is really needed, becouse 'signal' isn't broadcast
		end
    end
end