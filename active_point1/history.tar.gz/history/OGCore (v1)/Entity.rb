module Entity
	attr_accessor :og_id, :og_version, :og_engine
	
	def initialize
		super
		@og_id = object_id
	end
	
	def copy user_transaction = nil
		#		raise RuntimeError, "Cannot copy Not Managed Object!", caller unless managed?
		return self unless managed?
		og_engine.copy_entity self, user_transaction
	end
	
	def original user_transaction = nil
		return self unless managed?
		return og_engine.original(self, user_transaction)
	end
	
	def original? user_transaction = nil
		return true unless managed?
		return og_engine.original?(self, user_transaction)
	end
	
	def managed?
		og_engine != nil
	end
	
	def commit user_transaction = nil
		raise RuntimeError, "Entity isn't Managed!", caller unless managed?
		og_engine.engine_commit user_transaction
	end
	
	def rollback
		og_engine.engine_rollback
	end
	
	def == other
		return false unless other.respond_to? :og_id
		og_id == other.og_id
	end
	
	def eql? other
		return false unless self.class == other.class
		og_id == other.og_id
	end
	
	def hash
		return og_id
	end		
	
	def to_s; 
		"#<#{self.class.name.split("::").last}: #{object_id}>" 
	end
	
	def inspect
		to_s
	end	
	
	module ClassMethods
		def transient_get 
			transient = Set.new
			if @transient
				transient += @transient
			else
				transient.add "@og_engine"
			end
			ancestors.each do |anc|
				next if anc == self
				transient += anc.transient_get if anc.respond_to?(:transient_get) and anc.transient_get
			end		
			return transient
		end
		
		def transient *names
			raise "The list of transient properties cannot be empty!" if names.size == 0
			@transient = ["@og_engine"].to_set
			names.each do |n|
				n = n.to_s
				unless n =~ /@.+/
					raise_without_self \
            "Invalid format of instance variable specification ':#{n}', should be ':@<name>'!"
				end
				@transient.add n.to_s
			end
		end
	end
end