class Array
	alias_method :at_get, :[]
	alias_method :at_set, :[]=
end