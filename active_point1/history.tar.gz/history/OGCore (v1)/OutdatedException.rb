class OutdatedException < RuntimeError
    attr_reader :outdated_elements
    
    def initialize outdated_elements
        @outdated_elements = outdated_elements
    end    
end