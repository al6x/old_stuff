require 'RubyExt/require'
require 'HashStorage/require'
require 'StreamStorage/require'

require 'sync'

require 'ruby2ruby'
require 'parse_tree'
require 'parse_tree_extensions'

# Extension
require 'OGCore/Extensions/array.rb'

# Config
module OGCore
	CONFIG = {
    :directory => ".",
    :garbage_collector_pause => 3600 * 24,
    :buffer_size => 8192,
    :transaction_strategy => Transaction::OneTransactionPerThreadStrategy,
    :transaction => Transaction::Transaction
  }
  
  Cashe.cashed Entity::ClassMethods, :transient_get
end