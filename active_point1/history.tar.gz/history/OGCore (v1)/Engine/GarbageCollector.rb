class GarbageCollector
	def initialize engine, pause
		@thread = Thread.new do
			sleep pause
			engine.collect_garbage
		end
		@thread.priority = -1
	end	
	
	def kill
		@thread.kill
	end        		
end