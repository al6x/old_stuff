class StreamID
	attr_reader :sid
	def initialize id = nil
		@sid = id
	end
end

class ::StreamStorage::Storage
	def strip_id id
		id.sid
	end
end