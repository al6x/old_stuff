require 'rexml/document'
require 'net/http'
require 'monitor'
require 'tools/log'
	
module DataBase			
	def db
		@db ||= ExistDriver.new
		@db
	end
		
	class ExistDriver		
		include REXML, MonitorMixin, Log
		@@simple_classes = [Bignum, Fixnum, Float, Integer, NilClass, String, Symbol, FalseClass, TrueClass]
		
		class Counter
			def initialize 
				@counter = 1
			end
		
			def get() @counter.to_s end
		
			def increase() @counter+=1 end
		end
	
		class ObjectLink; end
		
		def initialize
			super
			@http ||= Net::HTTP.new('localhost',8080)
        end
		
		def get( id, path="")
			id = id.to_s
			synchronize do
				#				info("Getting:'"+path+id+"'")
				@http.start do |http|
					req = Net::HTTP::Get.new("/exist/rest/db#{path}/#{id}")  
					resp, data =  http.request(req)
					#					raise Exception.new("Can't get element '#{path}#{id}' (#{resp.message})") if resp.message != 'OK'
					return nil if resp.message != 'OK'
					xml = REXML::Document.new(data).root
					return ExistDriver.to_obj(xml)
				end
			end
        end
		
		def put(obj, path = "")
			synchronize do
				@http.start do |http|
					req = Net::HTTP::Put.new("/exist/rest/db#{path}/#{obj.id}")  
                    #   req.basic_auth 'admin', ''
					req['Content-Type'] =  'text/xml'
					xml = ExistDriver.to_xml(obj.id.to_s, obj)
					req['Content-Length'] = xml.size
					req.body = xml.to_s

					resp =  http.request(req)
					raise Exception.new("Can't create element '#{path}#{obj.id}' (#{resp.message})") if resp.message != 'Created'
				end
			end
        end
		
		def search(query, path = "")
			synchronize do
				@http.start do |http|
					req = Net::HTTP::Post.new("/exist/rest/db#{path}")  
					req['Content-Type'] =  'text/xml'
					xml = %{<?xml version="1.0" encoding="UTF-8"?>
<query xmlns="http://exist.sourceforge.net/NS/exist">
    <text>#{query}</text>
    <properties>
        <property name="indent" value="yes"/>
    </properties>
</query>}
					req['Content-Length'] = xml.size
					req.body = xml

					resp, data =  http.request(req)
					raise Exception.new("Can't execute query '#{query}' on path '#{path}'(#{resp.message})") if resp.message != 'OK'
				
                    # Converting XML to list of objects
					xml = REXML::Document.new(data).root
					list = Array.new
					xml.elements.each do |e|
						list << ExistDriver.to_obj(e)
					end		
				
					return list
				end	
			end
        end
		
		def delete(id, path="")
			id = id.to_s
			synchronize do
				@http.start do |http|
					req = Net::HTTP::Delete.new("/exist/rest/db#{path}/#{id}")  
					resp =  http.request(req)
					raise Exception.new("Can't delete element '#{path}/#{id}' '(#{resp.message})'") if resp.message != 'OK'
				end
			end
        end
				
		def self.to_xml(name, obj, trace = Hash.new, counter = Counter.new, parent = true)
			if simple?(obj.class)
				if parent
					e = Element.new('object')
					e.attributes['path'] = name
				else
					e = Element.new(name)
                end				
				e.attributes['class'] = obj.class.to_s
				e.text = obj.to_s
				return e
			else
				if parent
					element = Element.new('object')
					element.attributes['path'] = name
				else
					element  = Element.new(name)
                end				
				element.attributes['class'] = obj.class.to_s
				element.attributes['counter'] = counter.get
				trace[obj]=counter.get
				counter.increase
				
				obj.instance_variables.each do | n |
					v = obj.instance_variable_get(n)
					n = clear_name(n)
					if simple?(v.class)
						element.add(to_xml(n, v, trace, counter, false))
					elsif v.kind_of?(Array)
						array = Element.new(n)
						array.attributes['class'] = v.class.to_s
						element.add(array)
						
						v.each do |a_v| 
							array.add(to_xml_complex_object('item', a_v, trace, counter))
						end
					elsif v.kind_of?(Hash)
						hash = Element.new(n)
						hash.attributes['class'] = v.class.to_s
						element.add(hash)
						
						v.each do |h_k, h_v| 
							item = Element.new('item')														
							item.add(to_xml_complex_object('key', h_k, trace, counter))								
							item.add(to_xml_complex_object('value', h_v, trace, counter))
							hash.add(item)
						end						
					else
						element.add(to_xml_complex_object(n, v, trace, counter))
					end				
				end			
				return element
			end
        end
		
		def self.to_obj(element, trace = Hash.new)
			a_class = eval(element.attributes['class'])	
			if simple?(a_class)
				return instantiate_simple_classes(a_class, element.text)
			else						
				obj = a_class.new
				trace[element.attributes['counter']] = obj
			
				element.elements.each do |e|
					e_class = eval(e.attributes['class'])
					if e_class == Array
						array = Array.new
						obj.instance_variable_set("@"+e.name, array)
						e.elements.each do |item| 							
							array << to_obj(item, trace)
						end
					elsif e_class == ObjectLink
						obj.instance_variable_set("@"+e.name, trace[e.attributes['link']])
					elsif e_class == Hash
						h = Hash.new
						obj.instance_variable_set("@"+e.name, h)
						
						e.elements.each do |item|
							key = to_obj(item.elements['key'], trace)
							value = to_obj(item.elements['value'], trace)
							h[key] = value
                        end
					else
						obj.instance_variable_set("@"+e.name, to_obj(e, trace))
					end
				end		
				return obj
			end
        end
		
		private
		
		def self.clear_name(prefixed_name)
			return prefixed_name[1..prefixed_name.size] if prefixed_name && prefixed_name.size>1
        end
		
		def self.instantiate_simple_classes(a_class, value)
			if [Bignum, Fixnum, Float, Integer, FalseClass, TrueClass].include?(a_class)
				return eval(value)
			elsif NilClass == a_class
				return nil
			elsif Symbol == a_class
				return eval(":#{value}")
			elsif String == a_class
				return a_class.new(value ? value : '')
			else
				raise Exception.new("Uncnown class '#{a_class}'")
            end			
        end		
		
		def self.to_xml_complex_object(name, obj, trace, counter)
			if trace.include?(obj)
				e = Element.new(name)
				e.attributes['class'] = ObjectLink.to_s
				e.attributes['link'] = trace[obj]
				return e
			else	
				return to_xml(name,obj, trace, counter, false) 		
			end
        end		
		
		def self.simple?(obj_class)
			@@simple_classes.include?(obj_class)
        end
				
    end
end