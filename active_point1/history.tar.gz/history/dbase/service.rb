require 'cmanager/managed_component'
require 'dbase/data_base'

module DataBase
	class Service < ExistDriver
		include Manageable
		register :DB, :service
    end
end