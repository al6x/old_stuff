class Sample
	inherit Entity
	build_dmeta do |m|
		m.attribute :reference, :entity
		m.attribute :child, :entity
		m.attribute :value, :string
		m.children :child
		
		m.operation :test, :edit_child, "Title", :name => "value"
		
		m.operation :update_properties, :edit_properties, 'Title', :attributes => [:value]
	end
end