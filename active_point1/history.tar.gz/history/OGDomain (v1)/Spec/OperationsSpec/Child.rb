class Child < Parent
	
	build_dmeta do |m|
		m.operation :edit_properties, :edit_properties, "Edit Properties", :attributes => [:child]
	end
end