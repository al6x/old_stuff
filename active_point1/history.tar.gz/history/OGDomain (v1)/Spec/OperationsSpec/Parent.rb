class Parent
	inherit Entity
	
	build_dmeta do |m|
		m.operation :edit_properties, :edit_properties, "Edit Properties", :attributes => [:parent]
	end
end