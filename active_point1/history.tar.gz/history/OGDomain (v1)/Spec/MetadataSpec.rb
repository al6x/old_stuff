require 'OGDomain/require'
require 'spec'

module OGDomain
	module Spec
		module DMetaSpec
			describe "DMeta" do
				it "Custom Inheritance" do						
					ESample.transient_get.to_set.should == ["@og_engine", "@events_enabled"].to_set
					ESample.new.og_id.should_not be_nil
					
					ESample.attributes[:name][:title].should == "Name"
					ESample.attributes[:name][:type].should == :string
					ESample.attributes[:array][:type].should == :entity
					ESample.attributes[:array][:container].should == :array
					ESample.entity_name.should == ""
					ESample.new.should respond_to(:name)
				end								
			end
		end
	end
end