require 'OGDomain/require'
require 'spec'

module OGDomain
	module Spec
		module OperationsSpec
			describe "Operations" do
				it "DMeta" do
					Sample.operations[:test].to_hash.should == {:name => :test, :class => Operations::EditChild, 
						:title => "Title", :parameters => {:name => "value"}}
				end			
				
				it "Child" do										
					# Update
					o = Operations::EditChild.new
					child = Sample.new
					o.set :attribute => :child, :entity => @r, :child => child, :mode => :update
					o.validate; o.execute
					@r.commit
					@r.child.should == child
					
					# Delete
					o = Operations::EditChild.new
					o.set :attribute => :child, :entity => @r, :mode => :delete
					o.validate; o.execute
					@r.commit
					@r.child.should == nil
				end								
				
				it "Reference" do
					s = Sample.new
					c = @r.copy
					c.child = s
					
					# Update
					o = Operations::EditReference.new
					o.set :attribute => :reference, :entity => @r, :reference => s, :mode => :update
					o.validate; o.execute
					@r.commit
					@r.reference.should == s
					
					# Delete
					o = Operations::EditReference.new
					o.set :attribute => :reference, :entity => @r, :mode => :delete
					o.validate; o.execute
					@r.commit
					@r.reference.should == nil
				end
				
				it "BReference" do
					s = Sample.new
					c = @r.copy
					c.child = s
					
					# Update
					o = Operations::EditBReference.new
					o.set(:attribute => :reference, :entity => @r, :reference => s, :mode => :update,
								:reference_attribute => :reference)
					o.build; o.validate; o.execute
					@r.commit
					@r.reference.should == s
					s.reference.should == @r
					
					# Delete
					o = Operations::EditBReference.new
					o.set(:attribute => :reference, :entity => @r, :mode => :delete,
								:reference_attribute => :reference, :reference => s)					
					o.build; o.validate; o.execute
					@r.commit
					@r.reference.should == nil
					s.reference.should == nil
				end
				
				it "Properties" do
					c = @r.copy
					c.child = Sample.new
					c.commit
					
					# Update
					o = Operations::EditProperties.new.set :entity => @r.child, :attributes => [:value]
					o.properties = {:value => "value"}					
					o.validate; o.execute
					@r.commit
					@r.child.value.should == "value"					
				end
				
				it "DMeta Inheritance" do
					Parent.operations[:edit_properties].to_hash.should == {
						:name => :edit_properties, :class => Operations::EditProperties, 
						:title => "Edit Properties", 
						:parameters => {:attributes => [:parent]}
					}
					Child.operations[:edit_properties].to_hash.should == {
						:name => :edit_properties, :class => Operations::EditProperties, 
						:title => "Edit Properties", 
						:parameters => {:attributes => [:parent, :child]}
					} 
				end
				
				it "Operation Processor" do
					c = @r.copy
					c.child = Sample.new
					c.commit
					
					# Update					
					@r.og_engine.operation_processor.execute @r.child.class, :update_properties, 
					:entity => @r.child, :properties => {:value => "value"}
					
					@r.commit
					@r.child.value.should == "value"					
				end
				
				before :each do
					OGCore::CONFIG[:directory] = "#{File.dirname __FILE__}/data"
					
					Engine.delete :test									
					@r = Engine.new(:test, Root).root
				end
				
				after :each do
					@r.og_engine.close
					@r = nil
					Engine.delete :test
				end
			end
		end
	end
end