class BacklinkEntity 
	inherit Entity, OpenConstructor
	
	build_dmeta do |m|
		m.attribute :value, :entity
	end
end