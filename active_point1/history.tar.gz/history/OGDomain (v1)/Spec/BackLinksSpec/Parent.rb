class Parent
	inherit Entity
	
	build_dmeta do |m|
		m.attribute :child, :entity
		m.children :child
	end
end