require 'OGDomain/require'
require 'spec'

module OGDomain
	module Spec
		module ManageParentSpec
			describe "ExtendedSpec" do		
				
				before :each do
					OGCore::CONFIG[:directory] = "#{File.dirname __FILE__}/data"
					
					Engine.delete :test									
					@r = Engine.new(:test, Root).root
				end
				
				after :each do
					@r.og_engine.close
					@r = nil
					Engine.delete :test
				end
				
				it "Should setup parent" do
					c = @r.copy
					child = Child.new
					c.child = child
					c.commit
					child.parent.should equal(@r)
				end
				
#				it "OUTDATED Any entity should be Child in some Parent" do
#					c = @r.copy
#					child = Child.new
#					c.reference = child
#					lambda{c.commit}.should raise_error(/Parent/)
#					c.child = child
#					c.commit
#				end									
#				
#				it "OUTDATED There can be only one parent for any Entity" do
#					c = @r.copy
#					child = Child.new
#					parent = Parent.new
#					parent.child = child
#					c.child = child
#					c.child2 = parent
#					lambda{c.commit}.should raise_error(/Parents/)
#				end			
#				
#				it "OUTDATED Parent can't have the same Entity as child twice or more times" do
#					c = @r.copy
#					child = Child.new					
#					c.child = child
#					c.child2 = child
#					lambda{c.commit}.should raise_error(/Parents/)
#					c.child2 = Child.new
#					c.commit					
#				end
				
				it "Parent reassigning" do
					c = @r.copy
					child = Child.new					
					c.child = child
					c.commit
					child.parent.should equal(@r)
					
					c = @r.copy
					parent = Parent.new
					c.child = parent
					parent.child = child
					c.commit					
					child.parent.should equal(parent)
				end
			end
		end
	end
end