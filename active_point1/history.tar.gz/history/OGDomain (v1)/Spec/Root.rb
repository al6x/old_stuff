class Root 
	inherit Entity
	
	String

	build_dmeta do |m|
		m.entity_name "Root"
		m.attribute :value, :string
		m.attribute :references, :entity, "References", :container => :array
		m.attribute :reference, :entity
		m.attribute :child, :entity
		m.attribute :child2, :entity
		m.attribute :children, :entity, "Children", :container => :array
		m.children :child, :child2, :children
	end
end