class NED 
	inherit Entity

	build_dmeta do |m|
		m.attribute :child, :entity
		m.attribute :reference, :entity
		m.children :child
	end
end