class OnReferenceDelete 
	inherit Entity
	
	build_dmeta do |m|
		m.attribute :reference, :entity
		m.attribute :child, :entity		
		m.children :child
		
		m.on_reference_delete{self.on_reference_delete}
	end
	
	attr_accessor :notified	
	def on_reference_delete
		@notified = true
	end
end