class Group
	inherit OGDomain::Entity
	
	build_dmeta do |m|
		
		m.attribute :users, :entity, "Users"		  
	end
end