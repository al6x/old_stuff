class Core
  inherit OGDomain::Entity
  
  build_dmeta do |m|
		m.attribute :users, :entity, "Users"  
        
    m.attribute :groups, :entity, "Groups" 
    
    m.children :users, :groups
  end
end