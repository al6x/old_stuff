class User
  inherit OGDomain::Entity
  
  build_dmeta do |m|  
  end
end