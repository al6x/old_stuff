class CustomEntityType < Entity
	
	build_dmeta do |m|
		m.attribute :entity, :entity, :entity_type => Simple
	end	
end