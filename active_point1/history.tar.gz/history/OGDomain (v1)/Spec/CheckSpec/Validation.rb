class Validation < Entity
	build_dmeta do |m|
		m.attribute :string, :string, :validate => lambda{|s| s == "valid"}
	end
end