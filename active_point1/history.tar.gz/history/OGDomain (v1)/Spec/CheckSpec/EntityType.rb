class EntityType
	
	build_dmeta do |m|
		m.attribute :entity, :entity		
	end
end