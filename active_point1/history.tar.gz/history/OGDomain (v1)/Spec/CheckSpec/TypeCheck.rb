class TypeCheck < Entity
	build_dmeta do |m|
		m.attribute :string, :string
	end
end