class Simple < Entity
	build_dmeta do |m|
		m.attribute :name, :string
		m.attribute :value, :string
	end	
end