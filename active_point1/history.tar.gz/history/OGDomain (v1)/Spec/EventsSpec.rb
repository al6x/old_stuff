require 'OGDomain/require'
require 'spec'

module OGDomain
	module Spec
		module EventsSpec
			describe "Events" do						
				before :each do
					OGCore::CONFIG[:directory] = "#{File.dirname __FILE__}/data"
					
					Engine.delete :test									
					@r = Engine.new(:test, Root).root
				end
				
				after :each do
					@r.og_engine.close
					@r = nil
					Engine.delete :test
				end
				
				class TestListener
					attr_accessor :before_commit_new, :before_commit_updated, :before_commit_deleted
					
					def initialize
						self.before_commit_new, self.before_commit_updated, self.before_commit_deleted = 
						[], [], []
					end
					
					def before_commit_recursive *p; end
					
					def before_commit_final new, updated, deleted
						self.before_commit_new += new.to_a
						self.before_commit_updated += updated.to_a
						self.before_commit_deleted += deleted.to_a
					end
					
					def before_processing *args; end
				end								
				
				it "Classify modified entities as New, Updated, Deleted" do
					c = @r.copy										
					e = NED.new
					e2 = NED.new
					e3 = NED.new		
					e.child = e2
					e2.child = e3
					
					c.child = e
					c.references = [e, e]
					
					listener = TestListener.new
					@r.og_engine.listener = listener										
					
					c.commit
					(listener.before_commit_new.to_set == [e, e2, e3].to_set).should be_true
					(listener.before_commit_updated.to_set == [@r].to_set).should be_true
					(listener.before_commit_deleted.to_set == [].to_set).should be_true
					
					c = @r.copy
					c.child = nil
					
					listener = TestListener.new
					@r.og_engine.listener = listener
					
					c.commit
					(listener.before_commit_new.to_set == [].to_set).should be_true
					(listener.before_commit_updated.to_set == [@r].to_set).should be_true
					(listener.before_commit_deleted.to_set == [e, e2, e3].to_set).should be_true
				end
				
				it "<< KNOWN ERROR >> Move entity shouldn't cause :delete event (or shoud it cause :delete/:new or :move ?) (from error)" do
					c = @r.copy
					child = NED.new
					c.child = child
					c.commit
					
					listener = TestListener.new
					@r.og_engine.listener = listener
					
					c = @r.copy
					c.child = NED.new.set(:child => child)
					c.commit
					
					listener.before_commit_deleted.should == []
				end
				
				it "Cascade delete, automatically delete ALL references from ANY Entities to Child when Child is deleted" do
					c = @r.copy										
					e = NED.new
					c.child = e
					
					c.references = [e, e]
					c.commit
					
					# Delete reference
					c = @r.copy
					c.references.delete_at 1
					c.commit
					
					@r.child.should == e
					@r.references.should == [e]
					
					# Delete child					
					c = @r.copy
					c.child = nil
					c.commit
					
					@r.child.should == nil
					@r.references.should == []
				end																
				
				it "Call :on_reference_delete when deleting reference" do					
					e = OnReferenceDelete.new
					e2 = OnReferenceDelete.new
					e.set :child => e2, :reference => e2
					c = @r.copy
					c.child = e					
					c.commit
					
					c = e.copy
					c.child = nil
					c.commit
					
					e.reference.should == nil
					e.notified.should be_true
				end
				
				it "Call :on_reference_delete on deleted Entity" do
					e = OnReferenceDelete.new
					e.reference = e
					c = @r.copy
					c.child = e					
					c.commit
					
					c = @r.copy
					c.child = nil
					c.commit
					
					e.reference.should == nil
					e.notified.should be_true
				end
				
				it "on :new, :update, :delete events" do
					c = @r.copy
					e = NewUpdateDelete.new
					c.child = e 
					c.commit
					e.events.to_set.should == [:new].to_set
					
					c = e.copy
					c.commit					
					e.events.to_set.should == [:new, :update].to_set
					
					c = @r.copy
					c.child = nil
					c.commit
					e.events.to_set.should == [:new, :update, :delete].to_set
				end
				
				it "<< KNOWN ERROR >> should fire :new and :delete on all descendants" do					
					c = @r.copy
					e1 = NewUpdateDelete.new.set(:name => "parent")
					e2 = NewUpdateDelete.new.set(:name => "child")
					
					c.child = e1
					e1.child = e2
					
					c.commit
					e1.events.to_set.should == [:new].to_set
					e2.events.to_set.should == [:new].to_set
					
					c = @r.copy
					c.child = nil
					c.commit

					# Error because after deleteing [e1 and e2] CascadeDelete deletes e1.child.
					# But before it will make copy of it, so :on_delete result will be rewrited
					# later by copy.
					e1.events.to_set.should == [:new, :delete].to_set # << problem here
					e2.events.to_set.should == [:new, :delete].to_set
				end
				
				it "Transaction should be rollbacked if any exception will be thrown in event" do
					c = @r.copy
					c.child = Rollback.new
					c.commit
					
					@r.child.should_not be_nil
					
					c.copy
					c.value = "some value"
					c.child.copy # on_update on this copy will cause error 
					lambda{c.commit}.should raise_error /Rollback error/
					
					@r.value.should be_nil
				end
				
				it "Recursive Event, change another Entity (that also causes event) during Event" do																				
					r1 = Recursive1.new
					r2 = Recursive2.new
					
					c = @r.copy
					c.child = r1
					r1.child = r2
					c.commit
					
					r2.from_update.should == ""
					r2.from_parent.should == ""
					
					r1.copy.commit
					r2.from_update.should == "from_update"
					r2.from_parent.should == "from_parent"
				end								
			end
		end
	end
end