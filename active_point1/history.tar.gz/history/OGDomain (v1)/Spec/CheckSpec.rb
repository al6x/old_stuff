require 'OGDomain/require'
require 'spec'

module OGDomain
	module Spec
		module CheckSpec
			describe "CheckSpec" do								
				it "Parent should be defined" do
					c = @r.copy
					c.child = Simple.new
					lambda{c.commit}.should raise_error(/arent/)
				end
				
				it "Type Check" do
					c = @r.copy
					e = TypeCheck.new
					e.string = 1
					c.child = e
					lambda{c.commit}.should raise_error(/ype/)
				end															
								
				it "Validation check before Update" do
					c = @r.copy
					c.child = Validation.new
					c.child.string = "invalid"
					lambda{c.commit}.should raise_error(/parent/)
					c.child.string = "valid"
					c.commit
				end
				
				it "Explicit validation" do
					c = @r.copy
					c.child = Validation.new
					c.child.string = "invalid"
					c.child.dmeta.validate.should be_false
					c.child.string = "valid"
					c.child.dmeta.validate.should be_true
				end
				
				it "Entity Type check" do
					c = @r.copy
					c.child = EntityType.new
					c.child.entity = OGCore::Entity
					lambda{c.commit}.should raise_error(/ype/)
				end
				
				it "Custom Type check" do
					c = @r.copy
					e = CustomEntityType.new
					c.child = e
					e.entity = Entity.new
					lambda{c.commit}.should raise_error(/ype/)
					e.entity = Simple.new
					c.commit
				end								
				
				before :each do
					OGCore::CONFIG[:directory] = "#{File.dirname __FILE__}/data"
					
					Engine.delete :test									
					@r = Engine.new(:test, Root).root
				end
				
				after :each do
					@r.og_engine.close
					@r = nil
					Engine.delete :test
				end	
			end
		end
	end
end