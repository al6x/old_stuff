class SimpleEntity < Entity
	build_dmeta do |m|
		m.attribute :value, :string
	end	
end