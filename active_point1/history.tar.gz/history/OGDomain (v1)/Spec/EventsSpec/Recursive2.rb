class Recursive2 < Entity
	
	build_dmeta do |m|
		m.attribute :from_update, :string
		m.attribute :from_parent, :string
		m.on :update, :on_update
	end
	def on_update
		self.from_update = "from_update"
	end
end