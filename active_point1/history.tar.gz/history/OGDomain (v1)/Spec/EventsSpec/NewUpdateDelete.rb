class NewUpdateDelete < Entity

	build_dmeta do |m| 
		m.attribute :events, :array
		m.attribute :child, :entity
		m.children :child
		
		m.on :new, :on_new
		m.on :update, :on_update
		m.on :delete, :on_delete								
	end
	
	def on_new; self.events << :new end
	def on_update; self.events << :update end
	def on_delete; self.events << :delete end
end	