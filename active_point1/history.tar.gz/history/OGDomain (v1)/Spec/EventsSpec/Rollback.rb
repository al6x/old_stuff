class Rollback < Entity
	build_dmeta do |m|
		m.on :update, :on_update
	end
	
	def on_update
		raise "Rollback error"
	end
end