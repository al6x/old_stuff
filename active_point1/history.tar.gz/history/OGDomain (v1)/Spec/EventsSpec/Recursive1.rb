class Recursive1 < Entity
	
	build_dmeta do |m|
		m.attribute :child, :entity
		m.children :child
		m.on :update, :on_update
	end
	def on_update
		child.copy.from_parent = "from_parent"
	end
end