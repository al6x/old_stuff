class Child
	inherit Entity
	
	build_dmeta do |m|
#		attribute :
	end	
end