require 'OGDomain/require'
require 'spec'

module OGDomain
	module Spec
		module BasicSpec
			describe "BasicSpec" do
				class ESample
					inherit Entity
					build_dmeta do |m|
						m.attribute :array, :entity, "Array", :container => :array
					end
				end
				
				it "Entity" do						
					ESample.transient_get.to_set.should == ["@_recorded_events", "@og_engine", "@events_enabled"].to_set
					ESample.new.og_id.should_not be_nil
					
					ESample.attributes[:name].title.should == "Name"
					ESample.attributes[:name].type.should == :string
					ESample.attributes[:array].type.should == :entity
					ESample.attributes[:array].container.should == :array
					ESample.entity_name.should == ""
					ESample.new.should respond_to(:name)
				end
				
				it "Attributes" do
					meta = Attributes.attributes[:attribute]
					meta.to_hash.should == {:name => :attribute, :title => "attribute", 
						:type => :string, :parameters => {:value => "sample"}, :container => :single}
					Attributes.new.should respond_to(:attribute)
					
					Attributes.mandatory.should == [:attribute, :name]
					Attributes.children.should == [:child]					
				end
				
				it "Base Types, Initialization and Custom Initialization" do
					e = BaseTypes.new
					[e.string, e.number, e.boolean, e.array, e.entity, e.object, e.date, e.data].should == 
					["", 0, false, ["custom_initialization"], nil, "custom_initialization", nil, nil]
				end
				
				it "Validate Attribute and Validate Entity" do 
					raise "Not implemented"					
					e = Validate.new.set(:events_enabled => false)
					e.string = "invalid"
					lambda{Entity::Helper.validate e}.should raise_error
					e.string = "invalid2"
					lambda{Entity::Helper.validate e}.should raise_error
					e.string = "valid"
					AnEntity::Helper.validate e
				end
				
				it "Validation, should raise exception if not all mandatory attributes are filled" do
					raise "Not implemented"
					e = ESample.new.set(:events_enabled => false)
					AnEntity::Helper.validate e
					e.name = nil
					lambda{Entity::Helper.validate e}.should raise_error
				end
				
				it "Inherited parent methods" do
					p = UpParent.new
					c = UpChild.new
					
					c.up(:up_child, "Some param").should == :up_child
					lambda{c.up(:up_parent, "Some param")}.should raise_error(NoMethodError)
					c._parent = p
					c.up(:up_parent, "Some param").should == :up_parent										
				end								
				
				it "Should search in inherited parent methods untill found not-nil value (from error)" do
					p = UpNotNil.new
					p.value = "Value"
					c = UpNotNil.new
					c.up(:value).should == nil
					c._parent = p
					c.up(:value).should == "Value"										
				end
				
				it "Should not raise 'Not found' if parent hasn such method" do
					p = UpParent.new # Hasn't :value method
					c = UpNotNil.new					
					c._parent = p
					c.up(:value).should == nil
				end
				
				it "DMeta inheritance" do
					Descendant.attributes.keys.sort.should == [:base_class_method, :descendant_method, :name]
					Descendant.new # Check for proper initialization
				end
				
				it "each_child" do
					e = EachChildren.new.set(:events_enabled => false)
					e.child = ESample.new.set(:events_enabled => false).set(:name => "1")
					e.array << ESample.new.set(:events_enabled => false).set(:name => "2")
					e.array << ESample.new.set(:events_enabled => false).set(:name => "3")
					list = []
					e.each(:children){|c| list << c.name}
					list.to_set.should == ["1", "2", "3"].to_set
				end					
				
				it "iterator" do
					e = EachChildren.new.set(:events_enabled => false)
					e.child = ESample.new.set(:events_enabled => false).set(:name => "1")
					e.array << ESample.new.set(:events_enabled => false).set(:name => "2")
					e.array << ESample.new.set(:events_enabled => false).set(:name => "3")

					list = []
					update = ESample.new.set(:events_enabled => false).set(:name => "update")
					e.iterate(:children) do |i| list << i.value.name end
					list.to_set.should == ["1", "2", "3"].to_set
					
					e.iterate(:children) do |i| 
						i.value = update if i.value.name == "2"
						i.delete if i.value.name == "3"
					end
					e.array[0].name.should == "update"
					e.array.size.should == 1
				end
			end
		end
	end
end