require 'OGDomain/require'
require 'MicroContainer/require'
require 'spec'

module OGDomain
	module Spec
		module TransactionSpec			
			describe "Transactions" do
				Transactional = OGCore::Transaction::MicroContainerDeclarativeStrategy::Transactional
				
				before :each do            
					OGCore::CONFIG[:directory] = "#{File.dirname __FILE__}/data"
					OGCore::CONFIG[:transaction_strategy] = OGCore::Transaction::MicroContainerDeclarativeStrategy::StrategyAdapter
					Engine.delete :test
					OGCore::Transaction::MicroContainerDeclarativeStrategy::SessionTransactions.scope :session
					@r = Engine.new(:test, Root).root										                        
				end
				
				after :each do
					@r.og_engine.close
					@r = nil
					Engine.delete :test
				end
								
				it "Static Transactional method" do				
					MicroContainer::ScopeManager.activate_thread :session_id do                                
						Transactional.transaction{@r.copy.value = "value"}
						Transactional.commit
					end            
					@r.value.should == "value"		    					
				end
				
			end
		end
	end
end