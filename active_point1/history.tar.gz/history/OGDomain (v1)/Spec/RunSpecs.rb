SPEC_DIR = File.dirname __FILE__
require 'OGDomain/require'

require "#{SPEC_DIR}/AspectSpec"
require "#{SPEC_DIR}/BackLinksSpec"
require "#{SPEC_DIR}/BasicSpec"
require "#{SPEC_DIR}/CascadeDeleteSpec"
#require "#{SPEC_DIR}/CheckSpec"
#require "#{SPEC_DIR}/EventsSpec"
require "#{SPEC_DIR}/ExtendedSpec"
require "#{SPEC_DIR}/ManageParentSpec"
require "#{SPEC_DIR}/OperationsSpec"
require "#{SPEC_DIR}/TransactionSpec"