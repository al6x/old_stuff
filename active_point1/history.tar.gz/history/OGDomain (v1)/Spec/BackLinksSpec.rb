require 'OGDomain/require'
require 'spec'

module OGDomain
	module Spec
		module BackLinksSpec
			describe "BackLinks" do										
				before :each do
					OGCore::CONFIG[:directory] = "#{File.dirname __FILE__}/data"
					
					Engine.delete :test									
					@r = Engine.new(:test, Root).root
				end
				
				after :each do
					@r.og_engine.close
					@r = nil
					Engine.delete :test
				end		
				
				it "Build list of backlinks" do					
					@r.og_engine.backlinks.size.should == 0
					c = @r.copy
					c.child = BacklinkEntity.new
					c.commit
					@r.og_engine.backlinks.size.should == 0
					
					c = @r.child.copy
					c.value = @r
					c.commit
					@r.og_engine.backlinks.size.should == 1
					@r.og_engine.backlinks[@r].should == [@r.child]			
					
					c = @r.child.copy
					c.value = nil
					c.commit
					@r.og_engine.backlinks.size.should == 0
				end				
				
				it "Link in new element" do
					@r.og_engine.backlinks.size.should == 0
					c = @r.copy
					c.child = BacklinkEntity.new
					c.child.value = @r
					c.commit
					@r.og_engine.backlinks.size.should == 1
				end
				
				it "Links to self" do
					@r.og_engine.backlinks.size.should == 0
					c = @r.copy
					c.reference = @r
					c.commit
					@r.og_engine.backlinks.size.should == 1			
					@r.og_engine.backlinks[@r].should == [@r]
				end
				
				it "Should correct load backlinks" do
					Engine.delete :test2
					r = Engine.new(:test2, Root).root
					
					c = r.copy
					c.child = BacklinkEntity.new
					c.commit			
					c = r.child.copy
					c.value = r
					c.commit									
					
					r.og_engine.close
					
					r = Engine.new(:test2, Root).root
					r.og_engine.backlinks.size.should == 1
					r.og_engine.backlinks[r].should == [r.child]
					r.og_engine.close
					Engine.delete :test2
				end				
				
				it "Should correct delete backlinks (from error)" do			
					e1 = Parent.new
					e2 = BacklinkEntity.new
					
					c = @r.copy
					c.child = e1
					e1.child = e2
					e2.value = e1
					
					c.commit
					@r.og_engine.backlinks.size.should == 1
					
					c = @r.copy
					c.child = nil
					c.commit
					@r.og_engine.backlinks.size.should == 0
				end
			end
		end
	end
end