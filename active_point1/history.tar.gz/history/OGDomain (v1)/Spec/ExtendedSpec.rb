require 'OGDomain/require'
require 'spec'

module OGDomain
	module Spec
		module ExtendedSpec
			describe "ExtendedSpec" do		
				
				before :each do
					OGCore::CONFIG[:directory] = "#{File.dirname __FILE__}/data"
					
					Engine.delete :test									
					@r = Engine.new(:test, Root).root
				end
				
				after :each do
					@r.og_engine.close
					@r = nil
					Engine.delete :test
				end									
				
				it "EventArray" do
					@r.references.entity.should equal(@r)
					c = @r.copy
					c.references.entity.should equal(c)					
				end
				
				it "Delete one Child causes deletion of All Childs on the Parent (from error)" do										
					# Update					
					c1, c2 = Root.new, Root.new
					c = @r.copy
					c.children << c1
					c.children << c2
					@r.commit					
					@r.children.size.should == 2
					
					# Delete
					c = @r.copy
					c.children.delete_at 1
					c.commit
					@r.children.size.should == 1
				end
				
				it "EventArray should not fire events during loading" do
					class A
						inherit Entity
						
						build_dmeta{}
					end
					
					Engine.delete :test2									
					r = Engine.new(:test2, Root).root
					
					a = A.new
					c = r.copy
					c.child = a
					c.references << a
					c.commit
					
					r.og_engine.close					
					r = Engine.new(:test2, Root).root
					
					r.references.should == [a] 
					
					r.og_engine.close					
					Engine.delete :test
				end
				
				it "Root attributes initialization (from error)" do					
					@r.name.should_not be_nil				
				end
			end
		end
	end
end