require 'OGDomain/require'
require 'spec'

module OGDomain
	module Spec
		module AspectSpec
			describe "AspectSpec" do
				class BaseClass
					inherit Entity
					build_dmeta do |m|
						m.attribute :base, :string
					end
				end
				
				module AspectClass
					inherit Entity
					build_dmeta do |m|
						m.attribute :aspect, :string
					end
				end
				
				
				class DomainClass < BaseClass
					include AspectClass
					
					build_dmeta do |m|
						m.attribute :domain, :string
					end
				end
				
				it "Aspect" do								
					DomainClass.attributes.keys.to_set.should == [:aspect, :domain, :name].to_set
				end
				
				it "Should be properly initialized" do
					DomainClass.new.aspect.should == ""
				end
			end
		end
	end
end