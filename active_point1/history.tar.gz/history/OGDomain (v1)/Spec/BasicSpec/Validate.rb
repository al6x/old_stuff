class Validate
	inherit Entity
	build_dmeta do |m|
		m.attribute :string, :string, ":string", {:validate => lambda{|s| s != "invalid" }}
		m.validate {string != "invalid2"}
	end
end