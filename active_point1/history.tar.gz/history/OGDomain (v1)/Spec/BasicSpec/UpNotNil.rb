class UpNotNil
	inherit Entity
	
	attr_accessor :value
	
	build_dmeta{}
end