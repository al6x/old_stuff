class BaseTypes
	inherit Entity
	
	build_dmeta do |m|
		m.attribute :string, :string
		m.attribute :number, :number
		m.attribute :boolean, :boolean
		m.attribute :array, :array, "array", {:initialize => ["custom_initialization"]}
		m.attribute :entity, :entity
		m.attribute :object, :object
		m.attribute :date, :date
		m.attribute :data, :data
		m.initialize do			
			self.object = "custom_initialization"
		end
	end
end