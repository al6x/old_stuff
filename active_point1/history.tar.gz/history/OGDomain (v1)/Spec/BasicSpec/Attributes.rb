class Attributes 
	inherit Entity						
	
	build_dmeta do |m|
		m.attribute :attribute, :string, "attribute", :parameters => {
			:value => "sample"
		}
		m.attribute :child, :entity
		
		m.mandatory :attribute
		m.children :child
	end
end