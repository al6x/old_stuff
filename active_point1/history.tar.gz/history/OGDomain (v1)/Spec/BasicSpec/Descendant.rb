class Descendant < BaseClass
	build_dmeta do |m|
		m.attribute :descendant_method, :string
		m.initialize do 
			raise "Superclass should be initialized first!" unless self.base_class_method == "base"
		end
	end			
end