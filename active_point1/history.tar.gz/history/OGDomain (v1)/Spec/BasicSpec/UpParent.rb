class UpParent
	inherit Entity
	
	def up_parent params
		:up_parent
	end
	
	build_dmeta{}
end