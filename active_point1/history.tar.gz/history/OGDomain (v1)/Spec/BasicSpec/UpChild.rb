class UpChild
	inherit Entity
	def up_child params
		:up_child
	end
	
	build_dmeta{}
end