class BaseClass
	inherit Entity
	build_dmeta do |m|
		m.attribute :base_class_method, :string
		m.initialize{self.base_class_method = "base"}
	end		
end