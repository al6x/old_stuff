class EachChildren
	inherit Entity
	build_dmeta do |m|
		m.attribute :child, :entity
		m.attribute :array, :entity, "Array", :container => :array
		m.children :child, :array
	end
end