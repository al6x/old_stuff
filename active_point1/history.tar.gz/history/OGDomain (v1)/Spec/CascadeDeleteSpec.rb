require 'OGDomain/require'
require 'spec'

module OGDomain
	module Spec
		module CascadeDelete
			describe "Events" do						
				before :each do
					OGCore::CONFIG[:directory] = "#{File.dirname __FILE__}/data"
					
					Engine.delete :test									
					@r = Engine.new(:test, Root).root
				end
				
				after :each do
					@r.og_engine.close
					@r = nil
					Engine.delete :test
				end								
				
				it "Entity Copy (From error)" do
					@r.references.entity.should equal(@r)
					c = @r.copy										
					c.references.entity.should equal(c)
					c.commit
					@r.references.entity.should equal(@r) # << Problem Here
					c = @r.copy
					c.references.entity.should equal(c)					
				end
				
				it "Cascade delete, automatically delete ALL references from ANY Entities to Child when Child is deleted" do
					c = @r.copy										
					e = NED.new
					c.child = e
					c.references << e
					c.references << e
					c.commit
					@r.og_engine.backlinks.size.should == 1
					@r.og_engine.backlinks[e].size.should == 2
					
					# Delete reference
					c = @r.copy					
					c.references.delete_at 1
					
					c.commit
					
					@r.child.should == e
					@r.og_engine.backlinks.size.should == 1
					@r.references.should == [e]
					
					# Delete child					
					c = @r.copy
					c.child = nil
					c.commit
					
					@r.child.should == nil
					@r.og_engine.backlinks.size.should == 0
					@r.references.should == []					
				end																
				
				it "Call :on_reference_delete when deleting reference" do															
					c = @r.copy
					e = OnReferenceDelete.new
					c.child = e					
					e2 = OnReferenceDelete.new
					e.set :child => e2, :reference => e2
					c.commit
					
					c = e.copy
					c.child = nil
					c.commit
					
					e.reference.should == nil
					e.notified.should be_true
				end
				
				it "Call :on_reference_delete on deleted Entity" do
					c = @r.copy
					e = OnReferenceDelete.new										
					c.child = e					
					e.reference = e
					c.commit
					
					c = @r.copy
					c.child = nil
					c.commit
					
					e.reference.should == nil
					e.notified.should be_true
				end			
				
				it "Don't deletes references to deleted User from Group (from error)" do					
					c = @r.copy
					c.child = core = Error::Core.new
					core.groups = $group = Error::Group.new							
					c.commit # Do not unit commits in one, error will be lost! 
					
					user = Error::User.new
					c = core.copy
					c.users = user
					c.commit # Do not unit commits in one, error will be lost!
					
					c = $group.copy
					c.users = user
					c.commit # Do not unit commits in one, error will be lost!
					
					c = core.copy
					c.users = nil
					t = @r.og_engine.transaction
					c.commit # Do not unit commits in one, error will be lost!
					
					core.users.should == nil
					$group.users.should == nil					
				end
			end
		end
	end
end












