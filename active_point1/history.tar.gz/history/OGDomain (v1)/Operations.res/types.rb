{
	:edit_breference => EditBReference,
	:edit_child => EditChild,
	:edit_properties => EditProperties,
	:edit_reference => EditReference,
}