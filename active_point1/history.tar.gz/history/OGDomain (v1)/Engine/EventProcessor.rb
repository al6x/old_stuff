class EventProcessor
	
	def initialize engine
		@engine = engine
	end
	
	def on_reference_delete copy, reference
		copy.class.dmeta.on_reference_delete.each do |b|
			copy.instance_eval &b
		end
	end
	
	#	def on_event type, copies		
	#		copies.each do |e|			
	#			events = e.class.dmeta[:on]
	#			next unless events
	#			method_name = events[type]
	#			next unless method_name
	#			e.send method_name
	#		end
	#	end
	
	def process_events 		
		# Collect events		
		not_sorted_events = {} 
		@engine.transaction.copies.each do |original, copy|
			not_sorted_events.merge! collect_events copy
		end
		events = not_sorted_events.values
		events.sort_by_weight! not_sorted_events.keys		
		
		return if events.empty?		
		
		# Classify Events 		
		attribute_events, child_events, parent_events = classify_events events
		
		# Manage Entities and update Transaction
		manage_entities events, child_events
		
		# Fire Events
		fire_events attribute_events, child_events, parent_events
		
		# Post Processing			
		child_events.each do |type, *p|
			next unless type == :delete
			entity = p[0]
			delete_all_descendants entity
		end	
		
		process_events
	end
	
	def collect_events copy
		events = {}				
		if copy._recorded_events and !copy._recorded_events.empty?
			copy_events = copy._recorded_events 
			copy._recorded_events = nil
			events.merge! copy_events
			
			copy_events.each do |version, event|
				entity, name, new, old = event
				events.merge! collect_events new if new and new.is_a? Entity
				events.merge! collect_events old if old and old.is_a? Entity
			end
		end
		events
	end
	
	def delete_all_descendants entity		
		copy = entity.copy		
		copy.iterate(:children) do |i|
			next unless i.value
			delete_all_descendants i.value
			i.delete
		end
	end
	
	@event_number, @event_number_sync = 0, Monitor.new
	class << self
		def event_number
			@event_number_sync.synchronize{@event_number += 1}
		end
	end	
	
	protected
	def classify_events events
		attribute_events, child_events, parent_events = [], [], []
		
		events.each do |entity, name, new_value, old_value|
			if entity.class.children.include? name
				parent_events << [:update, entity, name, new_value, old_value]
				parent_events << [:new, entity, name, new_value] if new_value != nil and old_value == nil 				
				parent_events << [:delete, entity, name, old_value] if new_value == nil and old_value != nil
				
				
				child_events << [:new, new_value, entity] if new_value != nil
				child_events << [:delete, old_value, entity] if old_value != nil
			end
			
			# Attribute Events
			attribute_events << [:update, entity, name, new_value, old_value]
			attribute_events << [:new, entity, name, new_value] if new_value!= nil and old_value == nil
			attribute_events << [:delete, entity, name, old_value] if new_value == nil and old_value != nil
		end
		
		# Classify moved childs
		# Find :delete event, and then find right next :new event for the same child, 
		# then we remove these two events, create one move and replace last :new with it.
		i, to_delete = 0, []		
		while i < child_events.size
			type1, child1, parent1 = child_events[i] 
			if type1 == :delete
				j = i + 1
				while j < child_events.size
					type2, child2, parent2 = child_events[j]
					if type2 == :new and child1 == child2
						to_delete << i
						child_events[j] = [:move, child1, parent2, parent1]
					end
					j += 1
				end
			end			
			i += 1 
		end
		to_delete.reverse.each{|i| child_events.delete_at(i)}
		
		return attribute_events, child_events, parent_events
	end
	
	def manage_entities events, child_events				
		events.each do |entity, name, new_value, old_value|			
			if entity.class.references.include? name # Reference															
				@engine.transaction.backlinks_record << [:add_reference, entity.original, new_value] if new_value
				
				if old_value
					@engine.transaction.backlinks_record << [:delete_reference, entity, old_value]
				end
			end
		end
				
		child_events.each do |type, *p|
			t, e = @engine.transaction, p[0]
			if type == :new
				t.new << e
				parent = p[1]
				@engine.entity_management.manage_parent parent, e
			elsif type == :delete
				t.deleted << e
				@engine.entity_management.delete_references_to e
#				@engine.transaction.backlinks_record << [:delete_entity, e]
			elsif type == :move
				t.moved << e
				parent = p[1]
				@engine.entity_management.manage_parent parent, e
			end
		end				
	end
	
	def fire_events attribute_events, child_events, parent_events		
	end
end