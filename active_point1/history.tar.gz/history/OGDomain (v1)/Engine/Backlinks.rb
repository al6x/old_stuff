class Backlinks < Hash
	def add_entity entity
		entity.each(:references){|ref| add_reference entity, ref}
	end		
	
#	def deleted_entities deleted
#		deleted.each do |entity|
#			entity.each_reference{|ref| delete_ref entity, ref}
#		end
#	end
#	
#	def old_update_entities new, updated, deleted, originals
#		# Deleting
#		(deleted + originals).each do |entity|
#			OGCore::Helper.each_entity entity, ["@parent"] do |ref| 
#				delete_ref entity, ref
#				false
#			end
#		end
#		
#		# Adding
#		(new + updated).each do |entity|
#			OGCore::Helper.each_entity entity, ["@parent"] do |ref| 
#				add_ref entity, ref
#				false
#			end
#		end
#	end
#	
#	protected

#	def delete_entity entity
#		self.delete entity
#	end
	
	def add_reference entity, ref		
# TODO STUB, Enable it!		
#		raise "Entity and Reference should be originals!" \
#		if $debug and (!entity.original? or !ref.original?) 

			
		list = self[ref]
		unless list
			list = []
			self[ref] = list
		end			
		list << entity
	end	
	
	def delete_reference entity, ref
		list = self[ref]
#		return unless list
		list.delete_at list.index(entity) 
		self.delete ref if list.empty? 
	end
end