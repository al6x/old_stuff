class Listener
	attr_accessor :listener
	
	def initialize engine
		@engine = engine
	end
	
	def update mode, *p
		case mode
			when :before_commit then before_commit_isolated
			when :before_processing then before_processing_exclusive
		end
	end
	
	protected
	def before_commit_isolated
		@engine.event_processor.process_events				
	end
	
	def before_processing_exclusive
		@engine.transaction.backlinks_record.each do |method, *params|		
			@engine.backlinks.send method, *params
		end		 		 				
	end		
	
	#	def old_before_commit_isolated transaction
	#		processed_new, processed_updated, processed_deleted = Set.new, Set.new, Set.new
	#		new, updated, deleted = classify_entities transaction, processed_new, processed_updated, processed_deleted
	#		until new.empty? and updated.empty? and deleted.empty?		
	#			@engine.listener.before_commit_recursive new, updated, deleted							 
	#			new, updated, deleted = classify_entities(transaction, 
	#																								processed_new, 
	#																								processed_updated,
	#																								processed_deleted
	#			)
	#		end
	#		
	#		# STUB here is small problem 'processed_deleted' returns deleted ORIGINALS but processed 
	#		# were really their COPIES!
	#		@engine.listener.before_commit_final processed_new, processed_updated, processed_deleted 
	#	end
	#	
	#	def old_before_processing_exclusive originals, copies, new
	#		# We can remember it because in before_commit_isolated we are in :SH mode. 
	#		deleted = find_deleted_entities originals, copies, Set.new
	#		@engine.listener.before_processing new, copies, deleted, originals				
	#	end
	#	
	#	def old_find_deleted_entities originals, copies, processed_updated
	#		deleted_entities = Set.new
	#		originals.each_with_index do |o, i|
	#			next if processed_updated.include? o
	#			original_children, copy_children = Set.new, Set.new
	#			Entity.each_child(o){|c| original_children << c}
	#			Entity.each_child(copies[i]){|c| copy_children << c}
	#			deleted = original_children - copy_children
	#			deleted_entities.merge(deleted)
	#			# And all descendants for deleted entity
	#			deleted.each do |de|				
	#				Entity.each_descendant(de){|c| deleted_entities.add c}
	#			end
	#		end
	#		return deleted_entities
	#	end
	#	
	#	def old_classify_entities transaction, processed_new, processed_updated, processed_deleted
	#		new = transaction.new.to_set
	#		updated = transaction.copies.values.to_set
	#		deleted = find_deleted_entities(transaction.originals.values, transaction.copies.values, processed_updated).to_set
	#		
	#		new -= processed_new; 
	#		# processed_updated+processed_deleted - becouse before deleted will be processed with event they all
	#		# will be copied.
	#		updated -= processed_updated + processed_deleted; 
	#		deleted -= processed_deleted
	#		
	#		processed_new.merge(new); processed_updated.merge(updated); processed_deleted.merge(deleted)
	#		return new, updated, deleted
	#	end		
end