class EntityManagement
	def initialize engine
		@engine = engine
	end
	
	def delete_references_to entity
		list = @engine.backlinks[entity]
		return unless list
		list.each do |ref_e|
			copy = ref_e.copy
			
			copy.iterate :references do |i|
				if i.value == entity
					@engine.event_processor.on_reference_delete copy, i.value
					i.delete 
				end
			end
		end
	end
			
	def manage_parent parent, child		
#		if parent.managed?
#			parent = @engine.transaction.originals[parent] unless parent.original?
#		end
		child._parent = parent.original
	end
end