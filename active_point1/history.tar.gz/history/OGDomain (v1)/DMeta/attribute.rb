class OGDomain::DMeta
	class Attributes < Hash
		def copy
			c = Attributes.new
			each{|n, m| c[n] = m.copy}
			return c
		end
		
		def inherit parent
			parent.copy.merge copy
		end
	end
	
	class Attribute
		include OpenConstructor
		
		attr_accessor :name, :title, :type, :container, :initialize, :parameters
		public :initialize
		
		def copy; clone end
	end
	
	class AttributesDefinition		
		class << self
			def initial_value; Attributes.new end
			
			def copy attributes; attributes.copy end
			
			def inherit pvalue, cvalue;  
				cvalue.inherit pvalue
			end
			
			def after klass, meta
				OGDomain::AnEntity::Helper.define_attribute klass, meta
				#			klass.class_eval{attr_accessor meta[:name]}
				
				#			type = meta[:type]
				#			meta[:type] = DMeta["types.rb"][type] || [type]
				meta
			end
		end
	end
	
	definition[:attributes] = AttributesDefinition
		
	attr_accessor :attributes
	
	class Helper
		def attribute name, type, title = name.to_s, other = {}
			values = {:name => name, :title => title, :type => type, :container => :single}.merge(other)
			attr = Attribute.new.set_with_check values
			AttributesDefinition.after klass, attr
			dmeta.attributes[name] = attr
		end
	end
end