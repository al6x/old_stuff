class OGDomain::DMeta
	class InitializeEntityDefinition
		class << self
			def initial_value; [] end
			
			def copy value; value.clone end
			
			def inherit pvalue, cvalue; 
				pvalue + cvalue 
			end			
		end
	end
	
	definition[:initialize] = InitializeEntityDefinition
	
	alias_method :initialize_real, :initialize	
	attr_accessor :initialize
	alias_method :initialize_metadata, :initialize	
	def initialize *p, &b
		if p.size == 0 and b == nil
			initialize_metadata
		else
			initialize_real *p, &b
		end
	end
	public :initialize
	
	
	class Helper
		alias_method :initialize_real, :initialize			
		def initialize &b
			dmeta.initialize = [b]
		end
		
		alias_method :initialize_metadata, :initialize	
		def initialize *p, &b
			if p.size == 0
				initialize_metadata &b
			else
				initialize_real *p, &b
			end
		end
		public :initialize
	end
end