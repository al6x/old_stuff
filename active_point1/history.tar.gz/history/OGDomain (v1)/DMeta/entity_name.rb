class OGDomain::DMeta
class EntityNameDefinition
	class << self
		def initial_value; "" end
		
		def copy value; value.clone end
			
		def inherit pvalue, cvalue; cvalue end
	end
end

definition[:entity_name] = EntityNameDefinition

attr_accessor :entity_name

class Helper
	def entity_name name
		dmeta.entity_name = name
	end
end
end