class OGDomain::DMeta
class OnReferenceDeleteDefinition
	class << self
		def initial_value; [] end
		
		def copy value; value.clone end
		
		def inherit pvalue, cvalue; 
			pvalue + cvalue 
		end			
	end
end

definition[:on_reference_delete] = OnReferenceDeleteDefinition

attr_accessor :on_reference_delete

class Helper
	def on_reference_delete &b
		dmeta.on_reference_delete = [b]
	end
end
end