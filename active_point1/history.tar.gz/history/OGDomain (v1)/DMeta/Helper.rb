class Helper
	attr_accessor :dmeta, :klass
	def initialize klass, &block
		@klass = klass
		@dmeta = DMeta.new klass
		block.call self
	end
end