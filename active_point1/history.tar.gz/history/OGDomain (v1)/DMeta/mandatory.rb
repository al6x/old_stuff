class OGDomain::DMeta
class MandatoryDefinition
	class << self
		def initial_value; [] end
		
		def copy value; value.clone end
		
		def inherit pvalue, cvalue; 
			(pvalue + cvalue).sort 
		end			
	end
end

definition[:mandatory] = MandatoryDefinition

attr_accessor :mandatory

class Helper
	def mandatory *names
		dmeta.mandatory = names
	end
end
end