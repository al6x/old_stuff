class OGDomain::DMeta
	class ChildrenDefinition
		class << self
			def initial_value; [] end
			
			def copy value; value.clone end
			
			def inherit pvalue, cvalue 
				(pvalue + cvalue).sort 
			end			
		end
	end
	
	definition[:children] = ChildrenDefinition
	
	attr_accessor :children
	
	class Helper
		def children *names
			dmeta.children = names
		end
	end
end