{
	:single => AnEntity::SingleContainer,
	:array => AnEntity::ArrayContainer
}