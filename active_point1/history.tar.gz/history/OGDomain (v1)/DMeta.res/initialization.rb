{
	:string => "",
	:number => 0,
	:boolean => false,
	:entity => nil,
	:object => nil,
	:date => nil,
	:data => nil
}