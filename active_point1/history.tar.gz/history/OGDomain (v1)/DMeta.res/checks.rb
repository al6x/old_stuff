{
	:entity => [
	# Check for all entities are OGDomain::Entity
	lambda{|e| raise "Object '#{e}' isn't OGDomain::Entity!" unless e.is_a? Entity},
	
	# check for :parent
	lambda{|e| raise "Parent isn't defined for '#{e}' Entity!" unless e.parent or e.respond_to(:root?)}
	],
	
	:attribute => [
	# type check
	lambda do |e, name, meta|
		type = DMeta["types_classes.rb"][meta[:type]]
		unless type.any?{|t| e.send(name).is_a? t}
			raise "Invalid Type for '#{name}' Attribute of '#{e}' (Should be '#{type}' but is '#{e.send(name).class}')!"
		end
	end
	]
}