{
	:string => [String], 
	:number => [Numeric], 
	:boolean => [TrueClass, FalseClass],  
	:entity => [Entity, NilClass], 
	:object => [Object, NilClass], 
	:date => [Date, NilClass], 
	:data => [Object, NilClass]
}