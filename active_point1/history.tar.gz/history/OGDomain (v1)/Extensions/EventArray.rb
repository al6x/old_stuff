class EventArray < Array
	MUTABLE = %w{<< []= clear collect! compact! concat
      delete delete_at delete_if fill flatten insert map! pop push
      reject! replace reverse! shift slice! sort! transpose uniq!
      unshift}.collect{|n| n.to_sym}
	
	MUTABLE.each do |m|
		protected m
		new_name = case m 
			when :[]= then :set_at
#			when :<< then :add
		else "old_#{m}"
		end
		alias_method new_name, m
		protected new_name
	end
	
	attr_accessor :entity, :attribute_name
	
	def << value		
		before value, self[size]
		set_at size, value
	end
	
	def []= index, value		
		before value, self[index]
		set_at index, value
	end
	
	def clear
		delete_if{true}
	end
	
	def collect! &b
		old_collect! do |v|
			new = b.call v
			before new, v
			new
		end
	end
	
	def delete object
		delete_if{|o| o == object}
	end
	
	def delete_at index
		before nil, self[index]
		old_delete_at index
	end
	
	def delete_if &b
		old_delete_if do |v|			
			if b.call v
				before nil, v
				true
			else
				false
			end
		end
	end
	
	protected
	def before new, old
		@entity._before_attribute_write @attribute_name, new, old
	end
end