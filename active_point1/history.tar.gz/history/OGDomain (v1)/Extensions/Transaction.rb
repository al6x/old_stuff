class Transaction < OGCore::Transaction::Transaction
	attr_reader :new, :deleted, :moved
	attr_reader :backlinks_record
	attr_accessor :deleted_record
	
	def initialize
		super
		@deleted, @moved, @new = [], [], []
		@backlinks_record = []
	end
end