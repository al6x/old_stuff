class ValidationError < RuntimeError
	attr_accessor :errors
	
	def initialize errors = []
		super()
		@errors = errors
	end
end