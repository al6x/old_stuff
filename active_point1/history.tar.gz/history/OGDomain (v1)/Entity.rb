module Entity
	inherit OGCore::Entity
	include OpenConstructor, Log			
	
	def initialize				
		super
		@events_enabled = false
		AnEntity::Helper.initialize_entity self
		@events_enabled = true
	end	
	
	def up method_name, *p, &b					
		if respond_to? method_name
			value = send(method_name, *p, &b) 
			if value != nil
				return value
			elsif parent and parent.respond_to? method_name
				parent.up method_name, *p, &b
			else
				return value
			end
		else
			return parent.up method_name, *p, &b if parent
			raise NoMethodError, "Undefined method '#{method_name}' for '#{self.class.name}' and for it's parents!", caller
		end		
	end			
	
	def parents
		list = []
		current = self
		while current
			list << current
			current = current.parent
		end
		return list
	end
	
	attr_reader :parent
	def _parent= parent; @parent = parent end
	
	def to_s; 
		"#<#{self.class.name.split("::").last}: #{(name and !name.empty? ) ? name : object_id}>" 
	end
	
	def inspect
		to_s
	end			
	
	# Event processing
	transient :@events_enabled, :@_recorded_events
	attr_accessor :events_enabled, :_recorded_events
	def _before_attribute_write name, new, old
		return unless @events_enabled		
		raise "It's forbiden to modify Original (#{self})!" if managed? and original? 
		
		@_recorded_events ||= {}
		@_recorded_events[Engine::EventProcessor.event_number] = [self, name, new, old] 		
	end
	
	# DMeta methods	
	def iterate method_name, &b
		self.class.iterate self, method_name, &b
	end
	
	def each method_name, &b		
		self.class.each self, method_name, &b
	end		
	
	module ClassMethods
		attr_accessor :self_dmeta						
		
		def entity_name; dmeta.entity_name end		
		def attributes; dmeta.attributes end		
		def operations; dmeta.operations end		
		def mandatory; dmeta.mandatory end		
		def children; dmeta.children end		
		def type attribute; attributes[attribute].type end		
		def container attribute; attributes[attribute].container end		
		def attributes_names; attributes.keys.sort end
		
		def references;
			entities = []
			attributes.each do |name, meta|
				entities << name if meta.type == :entity
			end
			return (entities - children).sort
		end
		
		def build_dmeta &b;		
			h = DMeta::Helper.new(self, &b)
			self.self_dmeta = h.dmeta
		end		
		
		def dmeta
			parent = ancestors.find{|a| a.respond_to(:dmeta) and a != self}
			result = if parent
				self_dmeta.inherit parent.dmeta
			else
				self_dmeta
			end
			return result
		end
		
		def iterate entity, method_name, &b
			attributes = self.send method_name
			i_single = AnEntity::SingleIterator.new entity 
			attributes.each do |name|			
				case entity.class.container name
					when :single then
					i_single.accessor = name
					b.call i_single
					when :array then
					array = entity.send name
					i_array = AnEntity::ArrayIterator.new array
					array.each_index do |i|
						i_array.accessor = i
						b.call i_array
					end
					i_array._deleted.each{|i| array.delete_at i}
				else
					raise "Invalid Container Type '#{entity.class.container name}'!"
				end
			end
		end
		
		def each entity, method_name, &b
			attributes = self.send method_name
			attributes.each do |name|
				v = entity.send name.to_sym
				next if v == nil
				if v.is_a?(Entity)
					b.call v
				elsif v.is_a?(Array)
					v.each{|c| b.call c}
				else raise "The '#{name}' child attribute for '#{entity.class.name}' Entity isn't Child nor Array (it's '#{v.class.name}')!"
				end
			end
		end				
	end
	
	extend ClassMethods
	build_dmeta do |m|
		m.attribute :name, :string, "Name"
		m.mandatory :name
	end
end