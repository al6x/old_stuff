class ParentManagement

	
#	def manage_parent new, updated, deleted, originals
#		# Setting
#		new.each do |parent|
#			parent.meta_each_child do |child|
#				child._parent = parent
#			end
#		end
#		updated.each_with_index do |parent, i|
#			parent.meta_each_child do |child|
#				child._parent = originals[i]
#			end
#		end
#				
#		# Any Entity should be child somewhere
#		(new + updated).each do |parent|
#			@engine.helper.each_entity parent, ["@parent"] do |child|
##				warn 'reimplement using :each_reference'
#				raise "Entity '#{child}' haven't Parent!" unless child.parent or child.class.respond_to :root?
#				false
#			end
#		end
#		
#		# Multiple parents
#		multiple_parents = Set.new
#		(new + updated).each do |parent|
#			parent.meta_each_child do |child|
#				raise "Entity '#{child}' has Multiple Parents!" if multiple_parents.include? child
#				multiple_parents.add child
#			end
#		end
#	end		
end