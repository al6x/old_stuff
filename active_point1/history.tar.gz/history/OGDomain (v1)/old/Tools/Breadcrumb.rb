class Breadcrumb < WComponent
	extend Managed
    scope :entity	
    inject :repository => Model::Repository,
        :entity => Model::Entity
    
    childs :@path
	
	def initialize        
		path = repository.path_to entity
        @path = []
		@path << WLabel.new(path.last_name) unless path.empty?
		path = path.previous		
		while path
			@path << WLink.new(path.last_name, path) unless path.empty?
			path = path.previous
        end 				
		
		@path.reverse!
	end
end