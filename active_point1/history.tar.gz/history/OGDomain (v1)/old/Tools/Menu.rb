class Menu < WComponent
    extend Managed
    scope :entity	
    inject :repository => Model::Repository,
        :entity => Model::Entity
    
    childs :@menu
    
    # If there is parent and grandparent
    #   - it lists all parents,  and then all siblings
    #           
    # If there is parent only
    #   - it lists all siblings
    #   
    # If there isn't parent
    #   - it lists all childs
    #
	def initialize				
        entity, @menu, @menu2, @current = self.entity, [], [], nil
        
        counter = -1
		if parent = entity.parent			            
            if parent2 = parent.parent
				Model::Entity::Helper.each_child parent2 do |e|
                    counter += 1
					if e == parent
						@menu << WLink.new(e.name, repository.path_to(e))
                        
                        Model::Entity::Helper.each_child parent do |e|
                            @menu2 << (counter += 1)
                            if e == entity
                                @menu << WLabel.new(e.name)
                                @current = counter
                            else
                                @menu << WLink.new(e.name, repository.path_to(e))
                            end                    
                        end                        
					else                        
						@menu << WLink.new(e.name, repository.path_to(e))
					end
				end
			else
                counter += 1
                @menu << WLink.new(parent.name, repository.path_to(parent))
                
				Model::Entity::Helper.each_child parent do |e|
                    @menu2 << (counter += 1)
                    if e == entity
                        @menu << WLabel.new(e.name)
                        @current = counter
                    else
                        @menu << WLink.new(e.name, repository.path_to(e))
                    end                    
                end									
            end                        			
		else			
			Model::Entity::Helper.each_child entity do |e|				
                @menu2 << (counter += 1)
				@menu << WLink.new(e.name, repository.path_to(e))                
			end
		end
	end
end