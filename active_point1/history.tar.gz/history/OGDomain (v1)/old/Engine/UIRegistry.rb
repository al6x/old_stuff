class UIRegistry
    SYNCHRONIZER = Monitor.new
    REGISTRY = {}
    
    def self.register model, view
        SYNCHRONIZER.synchronize do
            REGISTRY[model] = view
        end
    end
    
    def self.view_for model
        SYNCHRONIZER.synchronize do
            REGISTRY[model]
        end
    end
end