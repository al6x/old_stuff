# Delegates calls from UI to others system
class Window < WComponent
	include WPortlet
	extend Managed
	scope :session
	
	inject :wgui_window => WGUI::Engine::Window,
        :repository => Model::Repository,
        :entity => Model::Entity,
        :view => IView,
        :breadcrumb => Tools::Breadcrumb,
        :menu => Tools::Menu
	
	childs :view, :breadcrumb, :menu
    
    def initialize
        super
        self.component_id = :path
    end
	
	def update_state              		                                        
		wgui_window.skin = "default" # TODO stub
    end
    
    def state= state
        Scope.begin :entity
        Scope.begin :view
        @state = state
        @state = repository.path_to entity
    end
	
	def self.state_conversion_strategy; WGUI::Engine::State::AbsolutePathStateConversionStrategy end		
end		

Scope.register Model::Entity, :entity do
    window = Scope[Window]
    repository = Scope[Model::Repository]
    repository[window.state]
end