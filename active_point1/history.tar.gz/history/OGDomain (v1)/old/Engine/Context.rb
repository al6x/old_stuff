class Context
	extend Managed
	scope :entity

	inject :window => Window, 
        :repository => Model::Repository
        
    def go_to entity
        window.state = repository.path_to entity
    end
end