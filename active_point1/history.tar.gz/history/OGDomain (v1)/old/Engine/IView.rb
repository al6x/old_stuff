class IView
end

Scope.register IView, :entity do
    model = Scope[Model::Entity].class
    view = UIRegistry.view_for model
    if view
        view
    else
        view = WGUI::Core::WContinuation.new
        view.original = UI::Views::WContinuationAdapter.new
    end
end
