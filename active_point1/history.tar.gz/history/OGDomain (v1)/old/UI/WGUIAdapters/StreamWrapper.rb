class StreamWrapper			
	def initialize repository, id; @repository, @repository_id = repository, id end
		
	def each &block
        @repository.stream_read_each @repository_id, &block
	end				
end