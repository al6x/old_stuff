class Message < WComponent
    childs :@close, :@message
    def initialize
        @close = WButton.new "Close" do
            self.visible = false
            refresh
        end
        @message = WLabel.new ""
        self.visible = false
    end
    
    def warn message
        @mode = :warn
        @message.text = message
        self.visible = true
        refresh
    end
    
    def info message
        @mode = :info
        @message.text = message
        self.visible = true
        refresh
    end
end