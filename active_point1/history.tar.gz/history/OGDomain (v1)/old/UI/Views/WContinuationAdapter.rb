class WContinuationAdapter < WComponent
    extend Injectable
    inject :_view => Views::View
    
    childs :view    
    
    # Becouse it should be refreshed when new view created.
    def view        
        view = _view
        unless @last_view == view.object_id
            refresh             
            @last_view = view.object_id
        end        
        view
    end
end