class View < WComponent        
	attr_accessor :labels, :editors, :operations
    
    childs :labels, :editors, :operations, :@message
    
    def initialize
        @message = Message.new
    end    	
    
    def warn message
        @message.warn message
    end
    
    def info message
        @message.info message
    end
    
    def labels= labels
        @labels = labels
        refresh
    end
    
    def editors= editors
        @editors = editors
        refresh
    end
    
    def operations= operations
        @operations = operations
        refresh
    end
end

Scope.register View, :view do
    mode = Scope[Controller].mode
    if mode == :view
        view = View.new
        entity = Scope[Model::Entity]
        view.labels, view.editors = Builder.build_properties entity.metadata.properties
        view.operations = Builder.build_operation_visuals entity.metadata.operations, view        
        Builder.fill_editors entity, view.editors
        view.editors.each{|e| e.build}
        view
    elsif mode == :operation
        View.new
    else
        raise "Invalid mode '#{mode}'!"
    end
end