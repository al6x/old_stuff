class Dialog < WComponent
    include Managed
    scope :operation
    
    attr_accessor :controls, :properties
    childs :controls, :properties
    
    def controls= controls
        @controls = controls
        refresh
    end
    
    def properties= properties
        @properties = properties
        refresh
    end
end