class ManageProperties < Dialog
    def run editor_parameters, label_parameters
        simplest = {}
        entity.metadata.simple.each{|name| simplest[name] = entity.metadata.properties[name]}
        
        view.labels, view.editors = Builder.build_properties simplest, :edit
        Builder.fill_editors entity, view.editors
        view.editors.each{|e| e.build}
        
        save = WButton.new "Save", view do
            new_properties = {}
            view.editors.each do |editor|
                new_properties[editor.name] = editor.value
            end
            
            operation = controller.operations[name]
            operation.update entity, new_properties            
            controller.operation_end
        end
        cancel = WButton.new "Cancel" do
            controller.operation_end
        end
        
        view.operations = save, cancel        
    end        
end