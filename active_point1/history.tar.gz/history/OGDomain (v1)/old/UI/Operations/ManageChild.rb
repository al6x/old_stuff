class ManageChild < Dialog
    attr_accessor :end_location, :not_selected, :select_label, :select_labels, :success

    inject :context => Engine::Context
    
    def run editor_parameters, label_parameters
        is_array = entity.metadata.arrays.include? property
        operation = controller.operations[name]        
        question is_array, editor_parameters, operation.select do |answer|
            case answer[:answer]
            when :update
                new_entity = answer[:class].new
                fill_mandatory_properties new_entity do |answer|
                    case answer[:answer]
                    when :update                            
                        new_entity.set answer[:properties]
                        operation.update entity, new_entity            
                        controller.operation_end                         
                        context.go_to new_entity if end_location == :child
                        view.info success || "Entity has been added!"
                    when :cancel
                        controller.operation_end
                    end
                end
            when :delete
                operation.delete entity, answer[:selected]
                controller.operation_end
            when :cancel
                controller.operation_end
            end                                            
        end        
    end
    
    protected
    def question is_array, selected_for_delete, child_select, &result        
        view.labels = [Builder.build_property_label(:title => select_label)]
        pselect = Properties::ESelect.new.set(
            :select => child_select, :mode => :edit, :select_labels => select_labels
        )
        pselect.build
        view.editors = [pselect]
        
        if is_array
            if selected_for_delete and !selected_for_delete.empty?
                delete = WButton.new "Delete" do
                    result.call :answer => :delete, :selected => selected_for_delete
                end
            end
        else
            if entity.send :"#{property}"
                delete = WButton.new "Delete" do
                    result.call :answer => :delete, :selected => nil
                end
            end
        end
        
        update = WButton.new "Update", view do
            if pselect.value
                result.call :answer => :update, :class => pselect.value                                
            else
                view.warn not_selected || "Entity isn't selected!"
            end
        end
        
        cancel = WButton.new "Cancel" do
            result.call :answer => :cancel
        end
        
        view.operations = delete ? [update, delete, cancel] : [update, cancel]    
    end
    
    def fill_mandatory_properties new_entity, &answer
        mandatory_properties = {}
        new_entity.metadata.mandatory.each do |name| 
            mandatory_properties[name] = new_entity.metadata.properties[name]
        end
        view.labels, view.editors = Builder.build_properties mandatory_properties, :edit
        Builder.fill_editors new_entity, view.editors
        view.editors.each{|e| e.build}
        
        save = WButton.new "Update", view do
            new_properties = {}
            view.editors.each do |editor|
                new_properties[editor.name] = editor.value
            end
            answer.call :answer => :update, :properties => new_properties
        end
        cancel = WButton.new "Cancel" do
            answer.call :answer => :cancel
        end
        
        view.operations = save, cancel
    end
end