class Label < WComponent
    include OpenConstructor
    extend Injectable
    inject :controller => Controller
    
    attr_accessor :property
    
    def initialize dialog, editor
        @dialog, @editor = dialog, editor
    end
    
    protected
    def execute label_params
        editor_params = @editor ? @editor.parameters : nil
        controller.operation_begin @dialog.visual?
        @dialog.run editor_params, label_params
    end
end