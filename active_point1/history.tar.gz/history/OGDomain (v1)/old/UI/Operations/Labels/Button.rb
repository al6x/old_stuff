class Button < Label    
    attr_accessor :title
    
    childs :@button
    
    def initialize *args
        super
        @button = WButton.new "" do
            execute nil
        end
        
        @button.inputs = @editor if @editor
    end
    
    def title= title; @button.text = title end
    
    def title; @button.text end
end