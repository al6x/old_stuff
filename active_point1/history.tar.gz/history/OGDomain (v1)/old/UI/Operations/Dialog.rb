class Dialog
    include OpenConstructor
    extend Injectable
    inject :controller => Controller, 
        :view => Views::View,
        :entity => Model::Entity
    
    attr_accessor :name, :property
    
    def run editor_parameters, label_parameters; raise :override! end
    
    def visual?; true end        
end