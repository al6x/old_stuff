class Builder
	include Log
	
	class << self
        #        def build_view_and_controller entity
        #            root_view = WContinuation.new
        #            controller = Controller.new entity, root_view
        #            
        #            view = build_view entity, controller
        #        
        #            root_view.original = view
        #            return root_view, controller
        #        end
        
        #        def build_view entity, controller
        #            view = Views::GeneralView.new		
        #                
        #            # Operations
        #            controller.operations, view.operations = build_operations entity, controller                        
        #            
        #            # Properties
        #            view.properties = build_properties entity
        #            read_properties entity, view.properties
        #            
        #            return view
        #        end
    
        def build_operations operations_metadata
            operations = {}
            operations_metadata.each do |name, meta|                
                operations[name] = build_operation meta           
            end        
            return operations
        end
        
        def build_operation_visuals operations_metadata, view
            labels = []
            operations_metadata.each do |name, meta|                
                labels << build_operation_visual(meta, view)
            end        
            return labels
        end
        
        def build_operation meta
            o_class = meta[:class]                
            raise "There is no Operation Class for '#{meta[:name]}' operation!" unless o_class
                
            o_class.new.set meta            
        end
       
        def build_operation_visual meta, view
            dialog_class = meta[:dialog]
            raise "There is no Editor for '#{meta[:name]}' operation!" unless dialog_class
                
            dialog = dialog_class.new.set meta
            
            label_class = meta[:label] || Operations::Labels::Button
            raise "There is no Label Class for '#{name}' operation!" unless label_class
            
            editor = nil
            if property = meta[:property]
                view.editors.each do |e|
                    editor = e if e.name == property
                end
            end
            
            label = label_class.new dialog, editor
            label.set meta            
            return label
        end
    
        def build_properties properties_metadata, mode = :view
            labels, editors = [], []
            properties_metadata.each do |name, meta|			                
                labels <<  build_property_label(meta)
                editors << build_property_editor(meta, mode)                
            end        
            return labels, editors
        end	
	
        def build_property_editor meta, mode = :view
            klass = meta[:editor]            
            raise "There is no Property Editor Class for '#{meta[:name]}' property!" unless klass
            e = klass.new.set meta
            e.mode = mode            
            return e
        end
	
        def build_property_label meta
            Properties::Labels::Label.new.set meta
        end
    
        def fill_editors entity, editors
            editors.each do |editor|
                editor.value = entity.send editor.name
            end
        end
	
        #        def write_properties entity, properties
        #            new_properties = {}
        #            properties.each do |label, editor|
        #                entity.send :"#{editor.name}=", editor.value
        #            end
        #        end
    end
end