class ENumber < Editor    
    childs :@editor
    
	def build
		case mode
        when :view : @editor = WLabel.new(@value || "")
        when :edit : @editor = WTextField.new(@value || "")
		end
        refresh
    end
	
	def value
		return @editor.text
    end
end