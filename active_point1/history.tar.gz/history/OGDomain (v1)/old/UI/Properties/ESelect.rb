class ESelect < Editor
    attr_accessor :select, :select_labels
    
    childs :@editor    
    
    def build
        @values =  select ? select.call : []
        @string_values = @values.collect{|v| string_value v}
        @string_value = string_value @value
        
        if @value and !@values.include?(@value)
            @values << @value
            @string_values << @string_value
        end
        
        case mode
        when :view : @editor = WLabel.new(@string_value	|| "")
        when :edit : 
            unless @values.empty?
                @editor = WSelect.new(@string_values, @string_value || @string_values.first)
            else
                @editor = WLabel.new(@string_value	|| "")
            end
        end
        refresh
    end
	
    def value
        if @values
            case mode
            when :view : convert_back @editor.text
            when :edit 
                unless @values.empty?
                    convert_back @editor.selected
                else
                    convert_back @editor.text
                end
            end
        else
            return nil
        end
    end
    
    protected
    def convert_back string_value
        @string_values.each_with_index do |v, i|
            return @values[i] if v == string_value
        end
        return nil
    end
    
    def string_value o
        return o unless o
        select_labels ? select_labels.call(o) : o.to_s
    end
end