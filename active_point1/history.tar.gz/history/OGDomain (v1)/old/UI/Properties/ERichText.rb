class ERichText < Editor    
    childs :@editor
    
	def build
		case mode
        when :view : @editor = WLabel.new(@value || "")
        when :edit : @editor = WRichEditor.new(@value || "")
		end
        refresh
    end
	
	def value
		return @editor.text
    end
end