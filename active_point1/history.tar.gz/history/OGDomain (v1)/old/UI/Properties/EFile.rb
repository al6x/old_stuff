class EFile < Editor 
    extend Injectable
    inject :repository => Model::Repository
    
    childs :@editor
    
	def build
		case mode
        when :view : 
            if @value
                sw = WGUIAdapters::StreamWrapper.new repository, value
                metadata = repository.stream_metadata_read value
                rd = WResourceData.new metadata[:resource_id], sw, metadata[:size], metadata[:extension]
                @editor = WResource.new rd
                @editor.component_id = rd.resource_id
            else
                @editor = WLabel.new("")
            end
        when :edit : 
            @editor = WFileUpload.new            
		end
        refresh
    end
	
	def value
        return @value unless @editor
        
        if @editor.empty?
            @value
        else
            id = repository.stream_put do |out|                
                @editor.file.each{|part| out.write part}                                                
            end
            
            repository.stream_metadata_put(id, {
                    :resource_id => @editor.resource_id, 
                    :size => repository.stream_size(id), 
                    :extension => @editor.extension                
                })
            
            self.value = id
            return id
        end
    end
end