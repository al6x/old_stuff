class ETable < Editor
    attr_accessor :columns
    childs :@head, :@rows, :@checkboxes        
    
    def parameters
        return [] unless @checkboxes
        selected = []
        @checkboxes.each_with_index do |cb, i|
            selected << i if cb.selected
        end
        return selected
    end
    
    def build        
        @head, @rows, @checkboxes = nil, nil, nil
        return unless @columns and @value and !@value.empty?
        
        template = @value.first
        @head = @columns.collect do |name| 
            title = template.metadata.properties[name][:title]        
            WLabel.new(title)
        end
        
        @rows, @checkboxes = [], []
        @value.each do |entity|
            @checkboxes << WCheckbox.new(false)
            row = []
            @columns.each do |name|
                row << WLabel.new(entity.send(name))
            end
            @rows << row
        end                
    end    
end