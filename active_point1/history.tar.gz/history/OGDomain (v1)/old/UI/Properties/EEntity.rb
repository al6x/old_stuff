class EEntity < Editor
    extend Injectable
    inject :repository => Model::Repository
    
    childs :@link    
    
    
    def build
        if value
            @link = WLink.new(value.name, repository.path_to(@value))
            refresh
        end
    end
end