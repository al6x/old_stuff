class Label < WComponent    
    def initialize
        @label = WLabel.new
    end
    
    def title= title; @label.text = title end
    
    def title; @label.text end
end