class Editor < WComponent
    include OpenConstructor
    
	attr_accessor :name, :mode, :value
    
    def parameters; nil end
    
    def build; end
end