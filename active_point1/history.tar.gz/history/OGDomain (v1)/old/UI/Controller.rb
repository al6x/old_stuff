class Controller	    
    include Transactional
    
    attr_accessor :operations, :mode
    
    def operation_begin visual
        @mode = :operation
        
        @visual = visual
        Scope.begin :view if @visual
    end    
    transaction :begin, :operation_begin
    
    def operation_end     
        @mode = :view
        
        Scope.begin :view if @visual           
    end         
    transaction :commit, :operation_end    
end

Scope.register Controller, :entity do
    c = Controller.new
    c.operations = Builder.build_operations Scope[Model::Entity].metadata.operations
    c.mode = :view
    c
end