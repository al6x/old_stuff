class Listener
	def initialize engine
		@engine = engine
	end
	
	# This method can be called many times during one commit!
	def before_commit_recursive new, updated, deleted		
		
#		# Cascade delete
#		CascadeDelete.delete_references_to(deleted, @engine)		
#		
#		@engine.event_processor.on_event :new, new unless new.empty?
#		@engine.event_processor.on_event :update, updated unless updated.empty?
#		@engine.event_processor.on_event :delete, deleted unless deleted.empty?
#		# Events
#		
#		#		# Checks
#		
	end
	
	def before_commit_final new, updated, deleted
		
	end
	
	def before_processing new, updated, deleted, originals		
		# Backlinks
		@engine.backlinks.update_entities new, updated, deleted, originals
		# Parent management
		@engine.parent_management.manage_parent new, updated, deleted, originals
	end
	
	def events
		#	(copies + new).each do |entity|
		#			# validate
		#			OGCore::Helper.validate entity
		#		end
		#		
		#		(copies + new).each do |entity|
		#			# on_update
		#			if on_update = entity.class.metadata[:on_update]
		#				on_update.each{|ou| entity.instance_eval &ou}
		#			end
		#		end
		#		
		#		copies.each do |entity|
		#			
		#		end
		#		
		#		new.each do |entity|
		#			# on_create
		#			if on_create = entity.class.metadata[:on_create]
		#				on_create.each{|oc| entity.instance_eval &oc}
		#			end
		#		end
	end
	
	def checks copies, new				
		#		
		#		(copies + new).each do |e|
		#			OGCore::Metadata["checks.rb"][:entity].each{|check| check.call(e)}
		#			
		#			e.class.attributes.each do |name, meta|
		#				OGCore::Metadata["checks.rb"][:attribute].each{|check| check.call(e, name, meta)}
		#			end
		#		end				
	end
end