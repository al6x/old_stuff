class EditReference < Operation
	attr_accessor :attribute, :entity, :index, :reference, :mode    
	
	def execute
		case mode
			when :update then update
			when :delete then delete
		end
	end
	
	def validate
		validate_both
		case mode
			when :update then validate_update
			when :delete then validate_delete
		end
	end
	
	protected
	def validate_both
		raise "Attribute isn't specified" unless attribute
		raise "Entity isn't specified!" unless entity
		type = entity.class.type attribute
		raise "Attribute Type isn't Entity (it's #{type})!" unless type == :entity		
		raise "Attribute isn't Reference!" if entity.class.children.include? attribute
	end
	
	def validate_update
		raise "Reference isn't defined!" unless reference		
	end
	
	def validate_delete
		
	end
	
	def update        		
		copy = entity.copy        
		case entity.class.container attribute
			when :single
			copy.send attribute.to_writer, reference
			when :array
			array = copy.send attribute.to_reader
			if index				
				array[index] = reference
			else
				array << reference
			end
		else
			raise "Invalid Type '#{type}' of the Property '#{property}'!"
		end
	end
	
	def delete
		copy = entity.copy
		case entity.class.container attribute
			when :single
			copy.send attribute.to_writer, nil            
			when :array 
			array = copy.send attribute.to_reader
			if index				
				array.delete_at index
			else
				array.delete_at array.index(reference)
			end
		else
			raise "Invalid Type '#{type}' of the Property '#{property}'!"
		end
	end
end