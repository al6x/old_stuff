class EditBReference < Operation
	attr_accessor :attribute, :reference_attribute, :entity, :reference, :mode  
	
	def build 
		@entity_reference = EditReference.new.set self
		case mode
			when :update							
			when :delete
			raise "Entity isn't defined!" unless entity
			raise "Attribute isn't defined!" unless attribute
			#			self.reference = entity.send reference_attribute			
		end
		
		@reference_reference = EditReference.new.set(self).set({:attribute => reference_attribute, 
			:entity => reference, :reference => entity})
	end
	
	def execute
		@entity_reference.execute
		@reference_reference.execute	
	end
	
	def validate
		@entity_reference.validate
		@reference_reference.validate
	end
end