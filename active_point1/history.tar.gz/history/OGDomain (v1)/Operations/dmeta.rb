class OGDomain::DMeta
	class Operations < Hash	
		def copy
			c = Operations.new
			each{|n, m| c[n] = m.copy}
			return c
		end
		
		def inherit parent
			result = self.merge(parent){|key, cmeta, pmeta|					
				operation_class = cmeta.class
				custom_inheritor = operation_class.respond_to :inheritor					
				if custom_inheritor
					custom_inheritor.call pmeta, cmeta
				else
					cmeta
				end
			}				
			result
		end
	end
	
	class Operation
		include OpenConstructor
		
		attr_accessor :name, :title, :class, :parameters
		
		def copy; clone end
	end
	
	class OperationsDefinition		
		class << self
			def initial_value; Operations.new end
			
			def copy operations; operations.copy end
			
			def inherit pvalue, cvalue;  						
				cvalue.inherit pvalue
			end				
		end
	end
	
	definition[:operations] = OperationsDefinition
	
	attr_accessor :operations
	
	class Helper
		def operation name, klass, title, parameters = nil
			klass = OGDomain::Operations::TYPES[klass] || klass
			
			o = Operation.new
			o.name, o.title, o.class = name, title, klass
			o.parameters = parameters if parameters
			
			dmeta.operations[name] = o
		end
	end
end

OGDomain::Operations::TYPES = OGDomain::Operations["types.rb"]