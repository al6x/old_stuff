class Operation
	include OpenConstructor
	
	attr_accessor :name		
	
	def execute; end		
end