class OperationProcessor
	def execute klass, name, runtime_parameters
		om = klass.dmeta.operations[name]
		
		o = om.class.new rescue raise("Can't initialize Operation '#{name}' for '#{klass}' Entity (#{om})!")		
		
		o.name = name
		o.set om.parameters if om.parameters
		o.set runtime_parameters if runtime_parameters
				
		o.respond_to :build
		o.respond_to :validate 		
		o.execute
	end	
end