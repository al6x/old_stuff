class EditProperties < Operation
	attr_accessor :entity, :attributes, :properties
	
	def validate
		raise "Attributes isn't defined!" unless attributes
		raise "Properties isn't defined!" unless properties
		extra = properties.keys.sort - attributes.sort
		unless extra.empty?
			raise "There are Extra properties to Update! (#{extra})"
		end
	end
	
	def execute		
		copy = entity.copy
		copy.set properties, attributes        
	end    
	
	class << self
		def inheritor
			@inheritor = lambda{|parent, child|
				child.parameters = {
						:attributes => parent.parameters[:attributes] + child.parameters[:attributes] 
					}
				child
			}
		end
	end
end