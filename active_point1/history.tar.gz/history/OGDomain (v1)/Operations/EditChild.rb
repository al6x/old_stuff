class EditChild < Operation    
  attr_accessor :attribute, :entity, :child, :index, :mode	
  
  def validate
    validate_both
    case mode
      when :update then validate_update
      when :delete then validate_delete
    end		
  end
  
  def execute
    case mode
      when :update then execute_update
      when :delete then execute_delete
    else 
      raise "Invalid Mode (#{mode})!"
    end		
  end
  
  protected			
  def validate_both
    raise "Attribute isn't specified" unless attribute
    raise "Entity isn't specified!" unless entity
    type = entity.class.type attribute
    raise "Attribute Type isn't Entity (it's '#{type}')!" unless type == :entity		
    raise "Attribute isn't Child!" unless entity.class.children.include? attribute
  end
  
  def validate_update				
    raise "Child isn't specified!" unless child		
  end
  
  def execute_update
    copy = entity.copy
    case entity.class.container attribute
      when :single 
      copy.send attribute.to_writer, child
      when :array 
      array = copy.send attribute.to_reader
      array << child			
    end
  end
  
  def validate_delete
    type = entity.class.type attribute
    raise "Not Child nor Index aren't specified!" unless child or index or (type != :array)
  end
  
  def execute_delete
    copy = entity.copy
    case entity.class.container attribute
      when :single 
      copy.send attribute.to_writer, nil
      when :array
      array = copy.send attribute.to_reader
      if index
        array.delete_at index
      else
        array.delete child				
      end			
    end
  end		
end