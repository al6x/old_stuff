class Engine < OGCore::Engine
	include Log	
	attr_reader :event_processor, :backlinks, :entity_management, :operation_processor
	
	#	:strategy => OGCore::Transaction::MicroContainerDeclarativeStrategy::StrategyAdapter
	def initialize name, root_class, collect_garbage_on_start = true		
		mark_as_root(root_class)
		super(name, :root_class => root_class)
		
		add_observer Listener.new(self)
		@event_processor = EventProcessor.new(self)		
		
		@backlinks = Backlinks.new
		@backlinks.add_entity root
		root.each(:children){|c| @backlinks.add_entity c}
		
		@entity_management = EntityManagement.new self
		
		collect_garbage if collect_garbage_on_start
		
		@operation_processor = Operations::OperationProcessor.new
	end				
	
	protected
	def mark_as_root o		
		o.class.class_eval "def root?; true end", __FILE__, __LINE__
	end		
end