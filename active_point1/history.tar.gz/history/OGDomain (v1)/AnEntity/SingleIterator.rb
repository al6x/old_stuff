class SingleIterator
	attr_accessor :accessor
	
	def initialize target; @target = target end
	
	def container; :single end
	
	def value
		@target.send @accessor
	end
	
	def value= value
		@target.send @accessor.to_writer, value
	end
	
	def delete
		@target.send @accessor.to_writer, nil
	end
end	