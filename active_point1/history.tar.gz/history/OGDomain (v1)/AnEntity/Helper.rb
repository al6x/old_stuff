class Helper
	class << self
		def initialize_entity entity
			entity.class.attributes.each do |name, meta|
				
				value = meta.initialize || DMeta::INITIALIZATION[meta.type]
				
				container = DMeta::CONTAINERS[meta.container]
				container.initialize_attribute name, value, entity								
			end
			entity.class.dmeta.initialize.each{|init| entity.instance_eval &init} 
		end				
		
		def validate entity
			errors = []
			# Attributes Validation
			entity.class.attributes.each do |name, meta|
				if validate = meta[:validate] 				
					unless validate.call entity.send(name)
						errors << "Invalid value for '#{meta[:title]}' attribute!"
					end
				end
			end
			# Entity Validation
			if validate = entity.class.dmeta[:validate]
				validate.each do |val|
					unless entity.instance_eval &val
						errors << "Invalid entity value!"
					end
				end
			end
			# MandatoryAttributes validation
			entity.class.mandatory.each do |name|
				if entity.send(name) == nil
					errors << "Mandatory attribute '#{entity.class.attributes[name][:title]}' isn't filled!"
				end
			end
			raise ValidationError.new(errors) unless errors.empty?				
		end
		
		def define_attribute klass, attr
			container = DMeta::CONTAINERS[attr.container]
			container.define_attribute klass, attr			
		end
	end
end