class ArrayIterator
	attr_accessor :accessor
	attr_reader :_deleted
	
	def container; :array end
	
	def initialize target; @target, @_deleted = target, [] end				
	
	def value
		@target[@accessor]	
	end
	
	def value= value
		@target[@accessor] = value
	end
	
	def delete
		@_deleted << @accessor
	end
end