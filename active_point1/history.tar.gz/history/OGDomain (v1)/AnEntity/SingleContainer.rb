class SingleContainer
	class << self
		def initialize_attribute name, value, entity	
			entity.send name.to_writer, value
		end
		
		def define_attribute klass, attr
			name = attr.name
			script = %{\
def #{name}= value	
	_before_attribute_write :#{name}, value, @#{name}
	@#{name} = value	 
end}
			
			klass.class_eval script, __FILE__, __LINE__
			klass.class_eval{attr_reader name}
		end
	end
end