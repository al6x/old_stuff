class ArrayContainer
	class << self
		def initialize_attribute name, value, entity
			array = Extensions::EventArray.new
			array.entity, array.attribute_name = entity, name
			entity.send :"_#{name}=", array
		end
		
		def define_attribute klass, attr
			name = attr.name
			klass.class_eval{attr_reader name}
			script = %{\
def _#{name}= value
	@#{name} = value
end}
			klass.class_eval script, __FILE__, __LINE__
		end
	end
end