class DMeta 
	CONTAINERS = DMeta["containers.rb"]
	INITIALIZATION = DMeta["initialization.rb"]
	
	@definition = {}
	class << self	
		attr_accessor :definition
	end
	
	attr_accessor :klass
	
	def initialize klass
		super()
		@klass = klass
		DMeta.definition.each do |name, defn|
			send name.to_writer, defn.initial_value
		end
	end															
	
	def inherit parent
#		if parent
			new = DMeta.new klass
			DMeta.definition.each do |name, defn|
				pmeta = parent.send name
				cmeta = self.send name
				new.send name.to_writer, defn.inherit(pmeta, cmeta)
			end
			return new
#		else			
#			return self.copy
#		end				
	end		
end

DMeta::Helper # Require before we alter it.

require 'OGDomain/DMeta/attribute'
require 'OGDomain/DMeta/children'
require 'OGDomain/DMeta/entity_name'
require 'OGDomain/DMeta/initialize'
require 'OGDomain/DMeta/mandatory'
require 'OGDomain/DMeta/on_reference_delete'

require 'OGDomain/Operations/dmeta'
