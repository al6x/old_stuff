require 'OGCore/require'

require 'RubyExt/debug'

module OGDomain	
#	OGEntity = OGCore::Entity

	OGCore::CONFIG[:transaction] = Extensions::Transaction 
#	Transaction = OGCore::Transaction    
#	Transactional = OGCore::Transaction::MicroContainerDeclarativeStrategy::Transactional            
end

# Config
#module OGDomain
#	CONFIG = OGDomain["config.yaml"]
#end

# Cashe
module OGDomain
	Cashe.cashed Entity::ClassMethods, :dmeta, :references, :attributes_names
end