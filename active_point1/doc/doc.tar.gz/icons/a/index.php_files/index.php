/* generated javascript */
var skin = 'monobook';
var stylepath = '/skins';

/* MediaWiki:Common.js */
/* Any JavaScript here will be loaded for all users on every page load. */

/* MediaWiki:Monobook.js (deprecated; migrate to Common.js!) */
/* Deprecated; use [[MediaWiki:common.js]] */