document.write('<!-- no doubleclick ad to serve -->');
